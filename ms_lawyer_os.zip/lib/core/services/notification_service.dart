import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // معالجة الإشعارات الواردة والتطبيق في الخلفية أو مغلق
}

/// خدمة الإشعارات: تهيئة Firebase Cloud Messaging والإشعارات المحلية،
/// وطلب الأذونات، وعرض الإشعارات الواردة أثناء فتح التطبيق.
class NotificationService {
  NotificationService._internal();
  static final NotificationService instance = NotificationService._internal();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    await _messaging.requestPermission(alert: true, badge: true, sound: true);

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _localNotifications.initialize(initSettings);

    const channel = AndroidNotificationChannel(
      'ms_lawyer_high_importance',
      'إشعارات مكتب المحاماة',
      description: 'إشعارات الجلسات والمهام والتنبيهات الهامة',
      importance: Importance.high,
    );
    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    FirebaseMessaging.onMessage.listen((message) {
      final notification = message.notification;
      if (notification != null) {
        _localNotifications.show(
          notification.hashCode,
          notification.title,
          notification.body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'ms_lawyer_high_importance',
              'إشعارات مكتب المحاماة',
              importance: Importance.high,
              priority: Priority.high,
            ),
          ),
        );
      }
    });
  }

  Future<String?> getDeviceToken() => _messaging.getToken();

  Future<void> subscribeToOfficeTopic(String officeId) {
    return _messaging.subscribeToTopic('office_$officeId');
  }

  /// جدولة إشعار محلي فوري (تُستخدم لاحقًا في موديول الجلسات والمهام
  /// لإرسال تذكيرات بموعد الجلسة القادمة)
  Future<void> showLocalNotification({required int id, required String title, required String body}) {
    return _localNotifications.show(
      id,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails('ms_lawyer_high_importance', 'إشعارات مكتب المحاماة', importance: Importance.high),
      ),
    );
  }
}
