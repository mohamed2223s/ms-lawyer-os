# MS Lawyer OS

نظام إدارة مكتب محاماة مصري - تطبيق Flutter (أندرويد) بالعربية RTL.

## حالة المشروع الحالية (المرحلة 1)

تم بناء الأساس الكامل + موديول العملاء بالكامل وبشكل فعلي وقابل للتشغيل:

- ✅ بنية Clean Architecture (domain / data / presentation) + Repository Pattern
- ✅ Firebase Auth (تسجيل دخول + إنشاء حساب مكتب جديد)
- ✅ Firestore مع عزل بيانات كل مكتب عبر `offices/{officeId}/...`
- ✅ تخزين محلي مشفّر (Hive + AES-256 عبر Android Keystore)
- ✅ مزامنة تلقائية Offline-First مع طابور عمليات معلّقة
- ✅ قفل PIN (6 أرقام) + بصمة/وجه + قفل تلقائي بعد 3 دقائق خمول
- ✅ ثيم Material 3 أسود/ذهبي/أبيض بالكامل + دعم RTL كامل
- ✅ إشعارات Push عبر Firebase Cloud Messaging
- ✅ موديول العملاء كاملًا: إضافة، تعديل، حذف، بحث فوري، مرفقات غير محدودة
- ✅ لوحة تحكم تعرض بيانات حقيقية (لا بيانات وهمية)
- ✅ قواعد أمان Firestore (`firestore.rules`)

**الموديولات المتبقية (القضايا، الجلسات، المستندات + OCR، المهام، المالية،
التقارير) تُبنى في مراحل قادمة بنفس المعمارية ونفس مستوى الجودة** - لم تُدرج
كشاشات فارغة أو placeholder، بل ستُضاف فعليًا حين اكتمالها.

## خطوات التشغيل (مطلوبة قبل أول Build)

### 🌐 الطريقة الأونلاين بالكامل (بدون تثبيت أي برنامج)

**1) إنشاء مشروع Firebase (من المتصفح فقط)**
- ادخل [console.firebase.google.com](https://console.firebase.google.com) → "إنشاء مشروع"
- من القائمة الجانبية فعّلوا:
  - **Authentication** → Sign-in method → فعّلوا Email/Password
  - **Firestore Database** → إنشاء قاعدة بيانات (وضع Production)
  - **Storage** → البدء
  - **Cloud Messaging** (مفعّل تلقائيًا)

**2) تسجيل تطبيق أندرويد والحصول على google-services.json**
- من إعدادات المشروع (⚙️) → "إضافة تطبيق" → أندرويد
- Package name: `com.mslawyeros.app`
- حمّلوا ملف `google-services.json` وضعوه داخل `android/app/google-services.json`

**3) تعبئة firebase_options.dart يدويًا**
افتحوا `google-services.json` وانسخوا القيم إلى `lib/firebase_options.dart`:
| في firebase_options.dart | من google-services.json |
|---|---|
| `apiKey` | `client[0].api_key[0].current_key` |
| `appId` | `client[0].client_info.mobilesdk_app_id` |
| `projectId` | `project_info.project_id` |
| `messagingSenderId` | `project_info.project_number` |
| `storageBucket` | `project_info.storage_bucket` |

**4) رفع قواعد الأمان (من المتصفح)**
- من Firebase Console → Firestore Database → Rules
- الصقوا محتوى ملف `firestore.rules` الموجود في المشروع واضغطوا Publish

**5) رفع المشروع على GitHub**
- أنشئوا حساب GitHub ومستودع (Repository) جديد
- ارفعوا كل ملفات المشروع (اسحبوا المجلد بالكامل في صفحة "Add file → Upload files")

**6) بناء الـ APK تلقائيًا عبر Codemagic (مجاني)**
- سجّلوا في [codemagic.io](https://codemagic.io) بحساب GitHub
- اربطوا المستودع الذي رفعتموه (Codemagic سيكتشف ملف `codemagic.yaml` الموجود بالمشروع تلقائيًا)
- ابدأوا Build → بعد الانتهاء (5-10 دقائق) حمّلوا ملف الـ APK من صفحة الـ Build مباشرة على موبايلكم
- ثبّتوا الملف على أندرويد (فعّلوا "السماح بالتثبيت من مصادر غير معروفة" إذا طُلب ذلك)

> ملاحظة: بدون إضافة مفتاح توقيع حقيقي، الـ APK سيُوقّع تلقائيًا بمفتاح Debug القياسي - يعمل بشكل كامل للتثبيت والتجربة على جهازكم، لكنه غير صالح للنشر على متجر Google Play مستقبلًا.

---

### 💻 الطريقة المحلية (لمن يملك جهاز كمبيوتر)

**1) إنشاء مشروع Firebase حقيقي**
هذه الخطوة **لا يمكن لأي جهة القيام بها نيابة عنكم** لأنها تتطلب حساب Google
الخاص بمكتبكم:

```bash
npm install -g firebase-tools
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
```

سيولّد هذا الأمر تلقائيًا:
- `lib/firebase_options.dart` (يستبدل الملف النائب الموجود حاليًا)
- `android/app/google-services.json`

فعّلوا في Firebase Console: **Authentication (Email/Password)**،
**Cloud Firestore**، **Cloud Storage**، **Cloud Messaging**.

### 2) رفع قواعد الأمان
```bash
firebase deploy --only firestore:rules
```

### 3) تثبيت الحزم
```bash
flutter pub get
```

### 4) تشغيل التطبيق
```bash
flutter run
```

### 5) بناء APK للإصدار
```bash
flutter build apk --release
```
ثم انقلوا ملف `build/app/outputs/flutter-apk/app-release.apk` لموبايلكم عبر
الكابل أو Google Drive وثبّتوه مباشرة.

⚠️ قبل نشر التطبيق فعليًا على متجر Google Play: أنشئوا مفتاح توقيع حقيقي
وضعوه في `android/key.properties` (راجعوا `android/key.properties.example`) -
بمجرد وجود هذا الملف سيستخدمه `build.gradle` تلقائيًا بدل مفتاح Debug.

## البنية

```
lib/
  core/           # ثيم، ألوان، أمان، خدمات مشتركة (مزامنة، اتصال، إشعارات)
  data/           # نماذج البيانات والمستودعات (Repository Pattern)
  domain/         # الكيانات النطاقية الصِرفة
  presentation/   # الشاشات والودجات
```

## ملاحظة حول OCR العربي
موديول المستندات (قيد البناء) سيستخدم `google_mlkit_text_recognition` وهو
مدرج بالفعل في `pubspec.yaml`. دقة التعرف على النصوص العربية المخطوطة بخط
اليد أقل من النصوص المطبوعة - سيُوثّق هذا بوضوح عند تسليم ذلك الموديول.
