import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/connectivity_service.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/case.dart';
import '../models/case_model.dart';
import 'hearing_repository.dart';

class CaseRepository {
  CaseRepository({required this.officeId, HearingRepository? hearingRepository}) : _hearingRepository = hearingRepository {
    _hearingRepository?.onHearingChangedForCase = refreshNextHearingForCase;
  }

  final String officeId;
  final HearingRepository? _hearingRepository;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection => _firestore.collection(FirestorePaths.casesCol(officeId));

  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        _mergeIntoLocal(CaseModel.fromFirestore(change.doc));
      }
    }, onError: (_) {});
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  void _mergeIntoLocal(CaseModel remote) {
    final box = CaseHiveBox.box;
    final localRaw = box.get(remote.id);
    if (localRaw != null) {
      final local = CaseModel.fromHiveMap(localRaw as Map);
      if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) return;
    }
    box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
  }

  List<LawCase> getAllLocal() {
    final box = CaseHiveBox.box;
    return box.values
        .map((raw) => CaseModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  Stream<List<LawCase>> watchAll() async* {
    yield getAllLocal();
    yield* CaseHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  List<LawCase> getByClient(String clientId) => getAllLocal().where((c) => c.clientId == clientId).toList();

  List<LawCase> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return getAllLocal();
    return getAllLocal().where((c) {
      return c.clientName.toLowerCase().contains(q) ||
          c.caseNumber.contains(q) ||
          c.court.toLowerCase().contains(q) ||
          c.opponentName.toLowerCase().contains(q) ||
          c.caseType.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _persist(LawCase entity) async {
    final model = CaseModel.fromEntity(entity);
    await CaseHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.casesCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<LawCase> addCase({
    required String clientId,
    required String clientName,
    required String court,
    required String circuit,
    required String caseNumber,
    required String year,
    required String caseType,
    required CaseDegree degree,
    required String opponentName,
    required String opponentLawyer,
    required CaseStatus status,
    DateTime? nextHearingDate,
  }) async {
    final now = DateTime.now();
    final entity = LawCase(
      id: _uuid.v4(),
      officeId: officeId,
      clientId: clientId,
      clientName: clientName,
      court: court,
      circuit: circuit,
      caseNumber: caseNumber,
      year: year,
      caseType: caseType,
      degree: degree,
      opponentName: opponentName,
      opponentLawyer: opponentLawyer,
      status: status,
      nextHearingDate: nextHearingDate,
      notes: const [],
      timeline: [CaseTimelineEntry(id: _uuid.v4(), title: 'تم فتح القضية', description: '', date: now)],
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await _persist(entity);
    return entity;
  }

  Future<LawCase> updateCase(LawCase entity) async {
    final oldRaw = CaseHiveBox.box.get(entity.id);
    final old = oldRaw != null ? CaseModel.fromHiveMap(oldRaw as Map).toEntity() : null;
    final updated = entity.copyWith(updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    if (old != null && (old.title != updated.title || old.clientName != updated.clientName)) {
      await _hearingRepository?.renameForCase(updated.id, caseTitle: updated.title, clientName: updated.clientName);
    }
    return updated;
  }

  /// يحدّث اسم العميل في كل قضاياه (ويتسلسل تلقائيًا لتحديث الجلسات المرتبطة بيها)
  Future<void> renameClientEverywhere(String clientId, String newClientName) async {
    for (final c in getByClient(clientId)) {
      if (c.clientName == newClientName) continue;
      await updateCase(c.copyWith(clientName: newClientName));
    }
  }

  /// يعيد حساب "الجلسة القادمة" لقضية معينة من واقع جلساتها الفعلية
  /// (أقرب جلسة غير محذوفة في المستقبل)، ويستدعَى تلقائيًا من مستودع
  /// الجلسات بمجرد أي إضافة/تعديل/تأجيل/حذف لجلسة مرتبطة بالقضية.
  Future<void> refreshNextHearingForCase(String caseId) async {
    final hearingRepo = _hearingRepository;
    if (hearingRepo == null) return;
    final raw = CaseHiveBox.box.get(caseId);
    if (raw == null) return;
    final current = CaseModel.fromHiveMap(raw as Map).toEntity();

    final now = DateTime.now();
    final upcoming = hearingRepo.getHearingsForCase(caseId).where((h) => !h.date.isBefore(now)).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    final nextDate = upcoming.isNotEmpty ? upcoming.first.date : null;

    if (current.nextHearingDate == nextDate) return;
    final updated = current.copyWith(
      nextHearingDate: nextDate,
      clearNextHearing: nextDate == null,
      updatedAt: DateTime.now(),
      isSynced: false,
    );
    await _persist(updated);
  }

  Future<LawCase> addNote(LawCase entity, String text) async {
    final note = CaseNote(id: _uuid.v4(), text: text, createdAt: DateTime.now());
    final updated = entity.copyWith(notes: [...entity.notes, note], updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  Future<LawCase> addTimelineEntry(LawCase entity, String title, String description, DateTime date) async {
    final entry = CaseTimelineEntry(id: _uuid.v4(), title: title, description: description, date: date);
    final updated = entity.copyWith(timeline: [...entity.timeline, entry], updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  Future<LawCase> addAttachments(LawCase entity, List<String> paths) async {
    final updated = entity.copyWith(attachmentPaths: [...entity.attachmentPaths, ...paths], updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  Future<void> deleteCase(String id) async {
    final raw = CaseHiveBox.box.get(id);
    if (raw == null) return;
    final model = CaseModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await CaseHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.casesCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }

  Future<bool> isOnline() => ConnectivityService.instance.isOnline();
}
