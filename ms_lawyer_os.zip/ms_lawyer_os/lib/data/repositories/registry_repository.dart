import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/registry.dart';
import '../models/registry_model.dart';

class OpponentRepository {
  OpponentRepository({required this.officeId});
  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection(FirestorePaths.opponentsCol(officeId));

  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final remote = OpponentModel.fromFirestore(change.doc);
        final box = OpponentHiveBox.box;
        final localRaw = box.get(remote.id);
        if (localRaw != null) {
          final local = OpponentModel.fromHiveMap(localRaw as Map);
          if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) continue;
        }
        box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
      }
    }, onError: (_) {});
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  List<Opponent> getAllLocal() {
    final box = OpponentHiveBox.box;
    return box.values
        .map((raw) => OpponentModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  Stream<List<Opponent>> watchAll() async* {
    yield getAllLocal();
    yield* OpponentHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  Future<void> _persist(Opponent entity) async {
    final model = OpponentModel.fromEntity(entity);
    await OpponentHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.opponentsCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<Opponent> addOpponent({
    required String name,
    String address = '',
    String nationalId = '',
    String lawyerName = '',
    String lawyerPhone = '',
    String notes = '',
  }) async {
    final now = DateTime.now();
    final entity = Opponent(
      id: _uuid.v4(),
      officeId: officeId,
      name: name,
      address: address,
      nationalId: nationalId,
      lawyerName: lawyerName,
      lawyerPhone: lawyerPhone,
      notes: notes,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await _persist(entity);
    return entity;
  }

  Future<Opponent> updateOpponent(Opponent entity) async {
    final updated = entity.copyWith(updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  Future<void> deleteOpponent(String id) async {
    final raw = OpponentHiveBox.box.get(id);
    if (raw == null) return;
    final model = OpponentModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await OpponentHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.opponentsCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }
}

class LibraryRepository {
  LibraryRepository({required this.officeId});
  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection(FirestorePaths.documentsCol(officeId));

  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final remote = LibraryDocumentModel.fromFirestore(change.doc);
        final box = LibraryHiveBox.box;
        final localRaw = box.get(remote.id);
        if (localRaw != null) {
          final local = LibraryDocumentModel.fromHiveMap(localRaw as Map);
          if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) continue;
        }
        box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
      }
    }, onError: (_) {});
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  List<LibraryDocument> getAllLocal() {
    final box = LibraryHiveBox.box;
    return box.values
        .map((raw) => LibraryDocumentModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Stream<List<LibraryDocument>> watchAll() async* {
    yield getAllLocal();
    yield* LibraryHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  Future<void> _persist(LibraryDocument entity) async {
    final model = LibraryDocumentModel.fromEntity(entity);
    await LibraryHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.documentsCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<LibraryDocument> addDocument({
    required String title,
    required LibraryDocCategory category,
    required PracticeArea practiceArea,
    required String filePath,
    String notes = '',
  }) async {
    final now = DateTime.now();
    final entity = LibraryDocument(
      id: _uuid.v4(),
      officeId: officeId,
      title: title,
      category: category,
      practiceArea: practiceArea,
      filePath: filePath,
      notes: notes,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await _persist(entity);
    return entity;
  }

  Future<void> deleteDocument(String id) async {
    final raw = LibraryHiveBox.box.get(id);
    if (raw == null) return;
    final model =
        LibraryDocumentModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await LibraryHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.documentsCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }
}

class VaultRepository {
  VaultRepository({required this.officeId});
  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection(FirestorePaths.vaultCol(officeId));

  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final remote = VaultItemModel.fromFirestore(change.doc);
        final box = VaultHiveBox.box;
        final localRaw = box.get(remote.id);
        if (localRaw != null) {
          final local = VaultItemModel.fromHiveMap(localRaw as Map);
          if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) continue;
        }
        box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
      }
    }, onError: (_) {});
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  List<VaultItem> getAllLocal() {
    final box = VaultHiveBox.box;
    return box.values
        .map((raw) => VaultItemModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => b.receivedDate.compareTo(a.receivedDate));
  }

  Stream<List<VaultItem>> watchAll() async* {
    yield getAllLocal();
    yield* VaultHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  Future<void> _persist(VaultItem entity) async {
    final model = VaultItemModel.fromEntity(entity);
    await VaultHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.vaultCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<VaultItem> addItem({
    required String clientName,
    required String description,
    required DateTime receivedDate,
    String physicalLocation = '',
  }) async {
    final now = DateTime.now();
    final entity = VaultItem(
      id: _uuid.v4(),
      officeId: officeId,
      clientName: clientName,
      description: description,
      receivedDate: receivedDate,
      physicalLocation: physicalLocation,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await _persist(entity);
    return entity;
  }

  Future<VaultItem> markReturned(VaultItem item, {String returnNote = ''}) async {
    final updated = item.copyWith(returnedDate: DateTime.now(), returnNote: returnNote, updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  Future<void> deleteItem(String id) async {
    final raw = VaultHiveBox.box.get(id);
    if (raw == null) return;
    final model = VaultItemModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await VaultHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.vaultCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }
}
