import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/connectivity_service.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/hearing.dart';
import '../models/hearing_model.dart';

class HearingRepository {
  HearingRepository({required this.officeId});

  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection(FirestorePaths.hearingsCol(officeId));

  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        _mergeIntoLocal(HearingModel.fromFirestore(change.doc));
      }
    }, onError: (_) {});
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  void _mergeIntoLocal(HearingModel remote) {
    final box = HearingHiveBox.box;
    final localRaw = box.get(remote.id);
    if (localRaw != null) {
      final local = HearingModel.fromHiveMap(localRaw as Map);
      if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) return;
    }
    box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
  }

  List<Hearing> getAllLocal() {
    final box = HearingHiveBox.box;
    return box.values
        .map((raw) => HearingModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  Stream<List<Hearing>> watchAll() async* {
    yield getAllLocal();
    yield* HearingHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  List<Hearing> getForDay(DateTime day) {
    return getAllLocal()
        .where((h) => h.date.year == day.year && h.date.month == day.month && h.date.day == day.day)
        .toList();
  }

  Map<DateTime, List<Hearing>> getGroupedByDay() {
    final map = <DateTime, List<Hearing>>{};
    for (final h in getAllLocal()) {
      final key = DateTime(h.date.year, h.date.month, h.date.day);
      map.putIfAbsent(key, () => []).add(h);
    }
    return map;
  }

  List<Hearing> getUpcoming({int limit = 5}) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return getAllLocal().where((h) => !h.date.isBefore(today)).take(limit).toList();
  }

  Future<Hearing> addHearing({
    String? caseId,
    required String caseTitle,
    required String clientName,
    required String court,
    required String location,
    required DateTime date,
    String notes = '',
  }) async {
    final now = DateTime.now();
    final entity = Hearing(
      id: _uuid.v4(),
      officeId: officeId,
      caseId: caseId,
      caseTitle: caseTitle,
      clientName: clientName,
      court: court,
      location: location,
      date: date,
      notes: notes,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await _persist(entity);
    return entity;
  }

  Future<void> _persist(Hearing entity) async {
    final model = HearingModel.fromEntity(entity);
    await HearingHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.hearingsCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<Hearing> updateHearing(Hearing entity) async {
    final updated = entity.copyWith(updatedAt: DateTime.now(), isSynced: false);
    await _persist(updated);
    return updated;
  }

  /// تأجيل الجلسة إلى تاريخ جديد، مع حفظ التاريخ القديم والسبب في سجل التسلسل
  Future<Hearing> postponeHearing({
    required Hearing hearing,
    required DateTime newDate,
    required String reason,
  }) async {
    final record = PostponementRecord(
      id: _uuid.v4(),
      previousDate: hearing.date,
      reason: reason,
      recordedAt: DateTime.now(),
    );
    final updated = hearing.copyWith(
      date: newDate,
      postponementHistory: [...hearing.postponementHistory, record],
      updatedAt: DateTime.now(),
      isSynced: false,
    );
    await _persist(updated);
    return updated;
  }

  Future<void> deleteHearing(String id) async {
    final raw = HearingHiveBox.box.get(id);
    if (raw == null) return;
    final model = HearingModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await HearingHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.hearingsCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }

  Future<bool> isOnline() => ConnectivityService.instance.isOnline();
}
