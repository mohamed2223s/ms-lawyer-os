import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/connectivity_service.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/client.dart';
import '../models/client_model.dart';

/// مستودع العملاء - يطبّق نمط Offline-First:
/// كل عملية تُكتب فورًا في Hive المحلي (استجابة فورية للواجهة)
/// ثم تُضاف إلى طابور المزامنة لتُرفع إلى Firestore عند توفر الاتصال.
/// عند توفر الاتصال، يستمع المستودع أيضًا لتغييرات Firestore ويحدّث
/// النسخة المحلية (Last-Write-Wins حسب updatedAt).
class ClientRepository {
  ClientRepository({required this.officeId});

  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _remoteSub;

  CollectionReference<Map<String, dynamic>> get _collection =>
      _firestore.collection(FirestorePaths.clientsCol(officeId));

  /// بدء الاستماع للتغييرات البعيدة ودمجها محليًا (يُستدعى مرة عند فتح شاشة العملاء)
  void startRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = _collection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final model = ClientModel.fromFirestore(change.doc);
        _mergeIntoLocal(model);
      }
    }, onError: (_) {
      // بدون اتصال أو خطأ مؤقت - يستمر التطبيق بالعمل من النسخة المحلية
    });
  }

  void stopRemoteSync() {
    _remoteSub?.cancel();
    _remoteSub = null;
  }

  void _mergeIntoLocal(ClientModel remote) {
    final box = ClientHiveBox.box;
    final localRaw = box.get(remote.id);
    if (localRaw != null) {
      final local = ClientModel.fromHiveMap(localRaw as Map);
      // لا نستبدل تعديلًا محليًا غير مُزامن أحدث من نسخة السيرفر
      if (!local.isSynced && local.updatedAt.isAfter(remote.updatedAt)) {
        return;
      }
    }
    box.put(remote.id, remote.copyWith(isSynced: true).toHiveMap());
  }

  /// قائمة العملاء الحاليين (غير المحذوفين) من التخزين المحلي، بترتيب أبجدي
  List<Client> getAllLocal() {
    final box = ClientHiveBox.box;
    return box.values
        .map((raw) => ClientModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => a.fullName.compareTo(b.fullName));
  }

  /// بث مباشر لأي تغيير في صندوق Hive الخاص بالعملاء (لتحديث الواجهة تلقائيًا)
  Stream<List<Client>> watchAll() async* {
    yield getAllLocal();
    yield* ClientHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  Client? getById(String id) {
    final raw = ClientHiveBox.box.get(id);
    if (raw == null) return null;
    return ClientModel.fromHiveMap(raw as Map).toEntity();
  }

  List<Client> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return getAllLocal();
    return getAllLocal().where((c) {
      return c.fullName.toLowerCase().contains(q) ||
          c.nationalId.contains(q) ||
          c.phone.contains(q) ||
          c.whatsapp.contains(q);
    }).toList();
  }

  Future<Client> addClient({
    required String fullName,
    required String nationalId,
    required String phone,
    required String whatsapp,
    required String address,
    required String notes,
    List<String> attachmentPaths = const [],
    double totalFees = 0,
    String poaNumber = '',
    DateTime? poaDate,
    PoaType poaType = PoaType.general,
    NotarizationType notarization = NotarizationType.customary,
  }) async {
    final now = DateTime.now();
    final model = ClientModel(
      id: _uuid.v4(),
      officeId: officeId,
      fullName: fullName,
      nationalId: nationalId,
      phone: phone,
      whatsapp: whatsapp,
      address: address,
      notes: notes,
      attachmentPaths: attachmentPaths,
      totalFees: totalFees,
      poaNumber: poaNumber,
      poaDate: poaDate,
      poaType: poaType,
      notarization: notarization,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await ClientHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.clientsCol(officeId),
      docId: model.id,
      operation: SyncOperation.create,
      payload: model.toFirestore(),
    );
    return model.toEntity();
  }

  Future<Client> updateClient(Client client) async {
    final model = ClientModel.fromEntity(client.copyWith(updatedAt: DateTime.now(), isSynced: false));
    await ClientHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.clientsCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
    return model.toEntity();
  }

  Future<void> deleteClient(String id) async {
    final raw = ClientHiveBox.box.get(id);
    if (raw == null) return;
    final model = ClientModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await ClientHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.clientsCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }

  Future<bool> isOnline() => ConnectivityService.instance.isOnline();
}
