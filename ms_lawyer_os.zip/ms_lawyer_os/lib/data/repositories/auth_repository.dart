import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/constants/firestore_paths.dart';

/// معلومات جلسة المستخدم بعد تسجيل الدخول (يشمل معرّف المكتب officeId
/// الذي يعزل بيانات كل مكتب محاماة عن الآخر).
class OfficeSession {
  final String uid;
  final String email;
  final String officeId;
  final String displayName;
  final String role; // admin | lawyer | secretary

  OfficeSession({
    required this.uid,
    required this.email,
    required this.officeId,
    required this.displayName,
    required this.role,
  });
}

class AuthRepository {
  AuthRepository._internal();
  static final AuthRepository instance = AuthRepository._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  Future<UserCredential> signIn({required String email, required String password}) {
    return _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  }

  /// إنشاء حساب مكتب جديد لأول مرة: ينشئ مستخدم Firebase Auth + مستند
  /// المكتب في Firestore + مستند المستخدم المرتبط به كـ admin.
  Future<OfficeSession> registerNewOffice({
    required String officeName,
    required String adminName,
    required String email,
    required String password,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    final uid = credential.user!.uid;

    final officeRef = _firestore.collection(FirestorePaths.offices).doc();
    await officeRef.set({
      'officeName': officeName,
      'createdAt': Timestamp.now(),
      'ownerUid': uid,
    });

    await _firestore.collection(FirestorePaths.users).doc(uid).set({
      'email': email.trim(),
      'displayName': adminName,
      'officeId': officeRef.id,
      'role': 'admin',
      'createdAt': Timestamp.now(),
    });

    await credential.user!.updateDisplayName(adminName);

    return OfficeSession(
      uid: uid,
      email: email.trim(),
      officeId: officeRef.id,
      displayName: adminName,
      role: 'admin',
    );
  }

  Future<OfficeSession?> loadSession(String uid) async {
    final doc = await _firestore.collection(FirestorePaths.users).doc(uid).get();
    if (!doc.exists) return null;
    final data = doc.data()!;
    return OfficeSession(
      uid: uid,
      email: data['email'] as String? ?? '',
      officeId: data['officeId'] as String,
      displayName: data['displayName'] as String? ?? '',
      role: data['role'] as String? ?? 'lawyer',
    );
  }

  Future<void> sendPasswordReset(String email) {
    return _auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<void> signOut() => _auth.signOut();
}
