import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/finance.dart';
import '../models/finance_model.dart';

/// مستودع الحسابات المالية - دفعات العملاء (أتعاب) ومصاريف القضايا.
/// نفس نمط Offline-First المتّبع في باقي المستودعات.
class FinanceRepository {
  FinanceRepository({required this.officeId});

  final String officeId;
  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _paymentsSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _expensesSub;

  CollectionReference<Map<String, dynamic>> get _paymentsCollection =>
      _firestore.collection(FirestorePaths.financePaymentsCol(officeId));
  CollectionReference<Map<String, dynamic>> get _expensesCollection =>
      _firestore.collection(FirestorePaths.financeExpensesCol(officeId));

  // ---------------- دفعات العميل (أتعاب) ----------------

  void startPaymentsRemoteSync() {
    _paymentsSub?.cancel();
    _paymentsSub = _paymentsCollection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final model = FinancePaymentModel.fromFirestore(change.doc);
        final box = FinancePaymentHiveBox.box;
        final localRaw = box.get(model.id);
        if (localRaw != null) {
          final local = FinancePaymentModel.fromHiveMap(localRaw as Map);
          if (!local.isSynced && local.updatedAt.isAfter(model.updatedAt)) continue;
        }
        box.put(model.id, model.copyWith(isSynced: true).toHiveMap());
      }
    }, onError: (_) {});
  }

  void stopPaymentsRemoteSync() {
    _paymentsSub?.cancel();
    _paymentsSub = null;
  }

  List<FinancePayment> getPaymentsForClient(String clientId) {
    final box = FinancePaymentHiveBox.box;
    return box.values
        .map((raw) => FinancePaymentModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted && m.clientId == clientId)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  double totalPaidByClient(String clientId) =>
      getPaymentsForClient(clientId).fold(0.0, (sum, p) => sum + p.amount);

  Future<FinancePayment> addPayment({
    required String clientId,
    required double amount,
    required DateTime date,
    required PaymentMethod method,
    required String note,
  }) async {
    final now = DateTime.now();
    final model = FinancePaymentModel(
      id: _uuid.v4(),
      officeId: officeId,
      clientId: clientId,
      amount: amount,
      date: date,
      method: method,
      note: note,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await FinancePaymentHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.financePaymentsCol(officeId),
      docId: model.id,
      operation: SyncOperation.create,
      payload: model.toFirestore(),
    );
    return model.toEntity();
  }

  Future<void> deletePayment(String id) async {
    final raw = FinancePaymentHiveBox.box.get(id);
    if (raw == null) return;
    final model = FinancePaymentModel.fromHiveMap(raw as Map)
        .copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await FinancePaymentHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.financePaymentsCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }

  // ---------------- مصاريف القضية ----------------

  void startExpensesRemoteSync() {
    _expensesSub?.cancel();
    _expensesSub = _expensesCollection.snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final model = CaseExpenseModel.fromFirestore(change.doc);
        final box = CaseExpenseHiveBox.box;
        final localRaw = box.get(model.id);
        if (localRaw != null) {
          final local = CaseExpenseModel.fromHiveMap(localRaw as Map);
          if (!local.isSynced && local.updatedAt.isAfter(model.updatedAt)) continue;
        }
        box.put(model.id, model.copyWith(isSynced: true).toHiveMap());
      }
    }, onError: (_) {});
  }

  void stopExpensesRemoteSync() {
    _expensesSub?.cancel();
    _expensesSub = null;
  }

  List<CaseExpense> getExpensesForCase(String caseId) {
    final box = CaseExpenseHiveBox.box;
    return box.values
        .map((raw) => CaseExpenseModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted && m.caseId == caseId)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  double totalExpensesForCase(String caseId) =>
      getExpensesForCase(caseId).fold(0.0, (sum, e) => sum + e.amount);

  Future<CaseExpense> addExpense({
    required String caseId,
    required double amount,
    required DateTime date,
    required String expenseType,
    required String note,
  }) async {
    final now = DateTime.now();
    final model = CaseExpenseModel(
      id: _uuid.v4(),
      officeId: officeId,
      caseId: caseId,
      amount: amount,
      date: date,
      expenseType: expenseType,
      note: note,
      createdAt: now,
      updatedAt: now,
      isSynced: false,
    );
    await CaseExpenseHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.financeExpensesCol(officeId),
      docId: model.id,
      operation: SyncOperation.create,
      payload: model.toFirestore(),
    );
    return model.toEntity();
  }

  Future<void> deleteExpense(String id) async {
    final raw = CaseExpenseHiveBox.box.get(id);
    if (raw == null) return;
    final model = CaseExpenseModel.fromHiveMap(raw as Map)
        .copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await CaseExpenseHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.financeExpensesCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }
}
