import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/services/sync_queue_service.dart';
import '../../domain/entities/quick_task.dart';
import '../models/quick_task_model.dart';

class QuickTaskRepository {
  QuickTaskRepository({required this.officeId});
  final String officeId;
  final _uuid = const Uuid();

  List<QuickTask> getAllLocal() {
    final box = QuickTaskHiveBox.box;
    return box.values
        .map((raw) => QuickTaskModel.fromHiveMap(raw as Map))
        .where((m) => !m.isDeleted)
        .map((m) => m.toEntity())
        .toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  }

  Stream<List<QuickTask>> watchAll() async* {
    yield getAllLocal();
    yield* QuickTaskHiveBox.box.watch().asyncMap((_) => getAllLocal());
  }

  Future<void> _persist(QuickTask entity) async {
    final model = QuickTaskModel.fromEntity(entity);
    await QuickTaskHiveBox.box.put(model.id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.tasksCol(officeId),
      docId: model.id,
      operation: SyncOperation.update,
      payload: model.toFirestore(),
    );
  }

  Future<QuickTask> addTask(String title) async {
    final now = DateTime.now();
    final entity = QuickTask(id: _uuid.v4(), officeId: officeId, title: title, createdAt: now, updatedAt: now, isSynced: false);
    await _persist(entity);
    return entity;
  }

  Future<void> toggleDone(QuickTask task) async {
    await _persist(task.copyWith(isDone: !task.isDone, updatedAt: DateTime.now(), isSynced: false));
  }

  Future<void> deleteTask(String id) async {
    final raw = QuickTaskHiveBox.box.get(id);
    if (raw == null) return;
    final model = QuickTaskModel.fromHiveMap(raw as Map).copyWith(isDeleted: true, updatedAt: DateTime.now(), isSynced: false);
    await QuickTaskHiveBox.box.put(id, model.toHiveMap());
    await SyncQueueService.instance.enqueue(
      collectionPath: FirestorePaths.tasksCol(officeId),
      docId: id,
      operation: SyncOperation.delete,
      payload: {'isDeleted': true, 'updatedAt': Timestamp.now()},
    );
  }
}
