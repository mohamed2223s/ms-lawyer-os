import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/registry.dart';
import '../local/hive_setup.dart';

class OpponentModel {
  final String id;
  final String officeId;
  final String? clientId;
  final String name;
  final String address;
  final String nationalId;
  final String lawyerName;
  final String lawyerPhone;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  OpponentModel({
    required this.id,
    required this.officeId,
    this.clientId,
    required this.name,
    this.address = '',
    this.nationalId = '',
    this.lawyerName = '',
    this.lawyerPhone = '',
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory OpponentModel.fromEntity(Opponent o) => OpponentModel(
        id: o.id,
        officeId: o.officeId,
        clientId: o.clientId,
        name: o.name,
        address: o.address,
        nationalId: o.nationalId,
        lawyerName: o.lawyerName,
        lawyerPhone: o.lawyerPhone,
        notes: o.notes,
        createdAt: o.createdAt,
        updatedAt: o.updatedAt,
        isSynced: o.isSynced,
        isDeleted: o.isDeleted,
      );

  Opponent toEntity() => Opponent(
        id: id,
        officeId: officeId,
        clientId: clientId,
        name: name,
        address: address,
        nationalId: nationalId,
        lawyerName: lawyerName,
        lawyerPhone: lawyerPhone,
        notes: notes,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory OpponentModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return OpponentModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      clientId: data['clientId'] as String?,
      name: data['name'] as String? ?? '',
      address: data['address'] as String? ?? '',
      nationalId: data['nationalId'] as String? ?? '',
      lawyerName: data['lawyerName'] as String? ?? '',
      lawyerPhone: data['lawyerPhone'] as String? ?? '',
      notes: data['notes'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'clientId': clientId,
        'name': name,
        'address': address,
        'nationalId': nationalId,
        'lawyerName': lawyerName,
        'lawyerPhone': lawyerPhone,
        'notes': notes,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'clientId': clientId,
        'name': name,
        'address': address,
        'nationalId': nationalId,
        'lawyerName': lawyerName,
        'lawyerPhone': lawyerPhone,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory OpponentModel.fromHiveMap(Map<dynamic, dynamic> map) => OpponentModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        clientId: map['clientId'] as String?,
        name: map['name'] as String? ?? '',
        address: map['address'] as String? ?? '',
        nationalId: map['nationalId'] as String? ?? '',
        lawyerName: map['lawyerName'] as String? ?? '',
        lawyerPhone: map['lawyerPhone'] as String? ?? '',
        notes: map['notes'] as String? ?? '',
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  OpponentModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => OpponentModel(
        id: id,
        officeId: officeId,
        clientId: clientId,
        name: name,
        address: address,
        nationalId: nationalId,
        lawyerName: lawyerName,
        lawyerPhone: lawyerPhone,
        notes: notes,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class OpponentHiveBox {
  static Box get box => Hive.box(HiveBoxes.opponents);
}

class LibraryDocumentModel {
  final String id;
  final String officeId;
  final String title;
  final LibraryDocCategory category;
  final PracticeArea practiceArea;
  final String filePath;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  LibraryDocumentModel({
    required this.id,
    required this.officeId,
    required this.title,
    required this.category,
    required this.practiceArea,
    required this.filePath,
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory LibraryDocumentModel.fromEntity(LibraryDocument d) => LibraryDocumentModel(
        id: d.id,
        officeId: d.officeId,
        title: d.title,
        category: d.category,
        practiceArea: d.practiceArea,
        filePath: d.filePath,
        notes: d.notes,
        createdAt: d.createdAt,
        updatedAt: d.updatedAt,
        isSynced: d.isSynced,
        isDeleted: d.isDeleted,
      );

  LibraryDocument toEntity() => LibraryDocument(
        id: id,
        officeId: officeId,
        title: title,
        category: category,
        practiceArea: practiceArea,
        filePath: filePath,
        notes: notes,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory LibraryDocumentModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return LibraryDocumentModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      title: data['title'] as String? ?? '',
      category: LibraryDocCategory.values.firstWhere((e) => e.name == data['category'], orElse: () => LibraryDocCategory.pleadings),
      practiceArea: PracticeArea.values.firstWhere((e) => e.name == data['practiceArea'], orElse: () => PracticeArea.civil),
      filePath: data['filePath'] as String? ?? '',
      notes: data['notes'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'title': title,
        'category': category.name,
        'practiceArea': practiceArea.name,
        'filePath': filePath,
        'notes': notes,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'title': title,
        'category': category.name,
        'practiceArea': practiceArea.name,
        'filePath': filePath,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory LibraryDocumentModel.fromHiveMap(Map<dynamic, dynamic> map) => LibraryDocumentModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        title: map['title'] as String? ?? '',
        category: LibraryDocCategory.values.firstWhere((e) => e.name == map['category'], orElse: () => LibraryDocCategory.pleadings),
        practiceArea: PracticeArea.values.firstWhere((e) => e.name == map['practiceArea'], orElse: () => PracticeArea.civil),
        filePath: map['filePath'] as String? ?? '',
        notes: map['notes'] as String? ?? '',
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  LibraryDocumentModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => LibraryDocumentModel(
        id: id,
        officeId: officeId,
        title: title,
        category: category,
        practiceArea: practiceArea,
        filePath: filePath,
        notes: notes,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class LibraryHiveBox {
  static Box get box => Hive.box(HiveBoxes.documents);
}

class VaultItemModel {
  final String id;
  final String officeId;
  final String clientName;
  final String description;
  final DateTime receivedDate;
  final String physicalLocation;
  final DateTime? returnedDate;
  final String returnNote;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  VaultItemModel({
    required this.id,
    required this.officeId,
    required this.clientName,
    required this.description,
    required this.receivedDate,
    this.physicalLocation = '',
    this.returnedDate,
    this.returnNote = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory VaultItemModel.fromEntity(VaultItem v) => VaultItemModel(
        id: v.id,
        officeId: v.officeId,
        clientName: v.clientName,
        description: v.description,
        receivedDate: v.receivedDate,
        physicalLocation: v.physicalLocation,
        returnedDate: v.returnedDate,
        returnNote: v.returnNote,
        createdAt: v.createdAt,
        updatedAt: v.updatedAt,
        isSynced: v.isSynced,
        isDeleted: v.isDeleted,
      );

  VaultItem toEntity() => VaultItem(
        id: id,
        officeId: officeId,
        clientName: clientName,
        description: description,
        receivedDate: receivedDate,
        physicalLocation: physicalLocation,
        returnedDate: returnedDate,
        returnNote: returnNote,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory VaultItemModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return VaultItemModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      clientName: data['clientName'] as String? ?? '',
      description: data['description'] as String? ?? '',
      receivedDate: (data['receivedDate'] as Timestamp?)?.toDate() ?? DateTime.now(),
      physicalLocation: data['physicalLocation'] as String? ?? '',
      returnedDate: (data['returnedDate'] as Timestamp?)?.toDate(),
      returnNote: data['returnNote'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'clientName': clientName,
        'description': description,
        'receivedDate': Timestamp.fromDate(receivedDate),
        'physicalLocation': physicalLocation,
        'returnedDate': returnedDate != null ? Timestamp.fromDate(returnedDate!) : null,
        'returnNote': returnNote,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'clientName': clientName,
        'description': description,
        'receivedDate': receivedDate.toIso8601String(),
        'physicalLocation': physicalLocation,
        'returnedDate': returnedDate?.toIso8601String(),
        'returnNote': returnNote,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory VaultItemModel.fromHiveMap(Map<dynamic, dynamic> map) => VaultItemModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        clientName: map['clientName'] as String? ?? '',
        description: map['description'] as String? ?? '',
        receivedDate: DateTime.parse(map['receivedDate'] as String),
        physicalLocation: map['physicalLocation'] as String? ?? '',
        returnedDate: map['returnedDate'] != null ? DateTime.parse(map['returnedDate'] as String) : null,
        returnNote: map['returnNote'] as String? ?? '',
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  VaultItemModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => VaultItemModel(
        id: id,
        officeId: officeId,
        clientName: clientName,
        description: description,
        receivedDate: receivedDate,
        physicalLocation: physicalLocation,
        returnedDate: returnedDate,
        returnNote: returnNote,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class VaultHiveBox {
  static Box get box => Hive.box(HiveBoxes.vault);
}
