import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/case.dart';

class CaseModel {
  final String id;
  final String officeId;
  final String clientId;
  final String clientName;
  final String court;
  final String circuit;
  final String caseNumber;
  final String year;
  final String caseType;
  final CaseDegree degree;
  final String opponentName;
  final String opponentLawyer;
  final CaseStatus status;
  final DateTime? nextHearingDate;
  final List<CaseNote> notes;
  final List<CaseTimelineEntry> timeline;
  final List<String> attachmentPaths;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  CaseModel({
    required this.id,
    required this.officeId,
    required this.clientId,
    required this.clientName,
    required this.court,
    required this.circuit,
    required this.caseNumber,
    required this.year,
    required this.caseType,
    required this.degree,
    required this.opponentName,
    required this.opponentLawyer,
    required this.status,
    this.nextHearingDate,
    this.notes = const [],
    this.timeline = const [],
    this.attachmentPaths = const [],
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory CaseModel.fromEntity(LawCase c) => CaseModel(
        id: c.id,
        officeId: c.officeId,
        clientId: c.clientId,
        clientName: c.clientName,
        court: c.court,
        circuit: c.circuit,
        caseNumber: c.caseNumber,
        year: c.year,
        caseType: c.caseType,
        degree: c.degree,
        opponentName: c.opponentName,
        opponentLawyer: c.opponentLawyer,
        status: c.status,
        nextHearingDate: c.nextHearingDate,
        notes: c.notes,
        timeline: c.timeline,
        attachmentPaths: c.attachmentPaths,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
        isSynced: c.isSynced,
        isDeleted: c.isDeleted,
      );

  LawCase toEntity() => LawCase(
        id: id,
        officeId: officeId,
        clientId: clientId,
        clientName: clientName,
        court: court,
        circuit: circuit,
        caseNumber: caseNumber,
        year: year,
        caseType: caseType,
        degree: degree,
        opponentName: opponentName,
        opponentLawyer: opponentLawyer,
        status: status,
        nextHearingDate: nextHearingDate,
        notes: notes,
        timeline: timeline,
        attachmentPaths: attachmentPaths,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory CaseModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return CaseModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      clientId: data['clientId'] as String? ?? '',
      clientName: data['clientName'] as String? ?? '',
      court: data['court'] as String? ?? '',
      circuit: data['circuit'] as String? ?? '',
      caseNumber: data['caseNumber'] as String? ?? '',
      year: data['year'] as String? ?? '',
      caseType: data['caseType'] as String? ?? '',
      degree: CaseDegree.values.firstWhere((e) => e.name == data['degree'], orElse: () => CaseDegree.first),
      opponentName: data['opponentName'] as String? ?? '',
      opponentLawyer: data['opponentLawyer'] as String? ?? '',
      status: CaseStatus.values.firstWhere((e) => e.name == data['status'], orElse: () => CaseStatus.active),
      nextHearingDate: (data['nextHearingDate'] as Timestamp?)?.toDate(),
      notes: ((data['notes'] as List?) ?? []).map((m) => CaseNote.fromMap(Map<String, dynamic>.from(m as Map))).toList(),
      timeline: ((data['timeline'] as List?) ?? []).map((m) => CaseTimelineEntry.fromMap(Map<String, dynamic>.from(m as Map))).toList(),
      attachmentPaths: List<String>.from(data['attachmentPaths'] as List? ?? []),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'clientId': clientId,
        'clientName': clientName,
        'court': court,
        'circuit': circuit,
        'caseNumber': caseNumber,
        'year': year,
        'caseType': caseType,
        'degree': degree.name,
        'opponentName': opponentName,
        'opponentLawyer': opponentLawyer,
        'status': status.name,
        'nextHearingDate': nextHearingDate != null ? Timestamp.fromDate(nextHearingDate!) : null,
        'notes': notes.map((n) => n.toMap()).toList(),
        'timeline': timeline.map((t) => t.toMap()).toList(),
        'attachmentPaths': attachmentPaths,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'clientId': clientId,
        'clientName': clientName,
        'court': court,
        'circuit': circuit,
        'caseNumber': caseNumber,
        'year': year,
        'caseType': caseType,
        'degree': degree.name,
        'opponentName': opponentName,
        'opponentLawyer': opponentLawyer,
        'status': status.name,
        'nextHearingDate': nextHearingDate?.toIso8601String(),
        'notes': notes.map((n) => n.toMap()).toList(),
        'timeline': timeline.map((t) => t.toMap()).toList(),
        'attachmentPaths': attachmentPaths,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory CaseModel.fromHiveMap(Map<dynamic, dynamic> map) => CaseModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        clientId: map['clientId'] as String? ?? '',
        clientName: map['clientName'] as String? ?? '',
        court: map['court'] as String? ?? '',
        circuit: map['circuit'] as String? ?? '',
        caseNumber: map['caseNumber'] as String? ?? '',
        year: map['year'] as String? ?? '',
        caseType: map['caseType'] as String? ?? '',
        degree: CaseDegree.values.firstWhere((e) => e.name == map['degree'], orElse: () => CaseDegree.first),
        opponentName: map['opponentName'] as String? ?? '',
        opponentLawyer: map['opponentLawyer'] as String? ?? '',
        status: CaseStatus.values.firstWhere((e) => e.name == map['status'], orElse: () => CaseStatus.active),
        nextHearingDate: map['nextHearingDate'] != null ? DateTime.parse(map['nextHearingDate'] as String) : null,
        notes: ((map['notes'] as List?) ?? []).map((m) => CaseNote.fromMap(Map<String, dynamic>.from(m as Map))).toList(),
        timeline: ((map['timeline'] as List?) ?? []).map((m) => CaseTimelineEntry.fromMap(Map<String, dynamic>.from(m as Map))).toList(),
        attachmentPaths: List<String>.from(map['attachmentPaths'] as List? ?? []),
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  CaseModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => CaseModel(
        id: id,
        officeId: officeId,
        clientId: clientId,
        clientName: clientName,
        court: court,
        circuit: circuit,
        caseNumber: caseNumber,
        year: year,
        caseType: caseType,
        degree: degree,
        opponentName: opponentName,
        opponentLawyer: opponentLawyer,
        status: status,
        nextHearingDate: nextHearingDate,
        notes: notes,
        timeline: timeline,
        attachmentPaths: attachmentPaths,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class CaseHiveBox {
  static const String boxName = 'cases_box';
  static Box get box => Hive.box(boxName);
}
