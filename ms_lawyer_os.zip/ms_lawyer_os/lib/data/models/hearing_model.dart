import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/hearing.dart';

class HearingModel {
  final String id;
  final String officeId;
  final String? caseId;
  final String caseTitle;
  final String clientName;
  final String court;
  final String location;
  final DateTime date;
  final String notes;
  final String result;
  final String requiredActions;
  final List<PostponementRecord> postponementHistory;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  HearingModel({
    required this.id,
    required this.officeId,
    this.caseId,
    required this.caseTitle,
    required this.clientName,
    required this.court,
    required this.location,
    required this.date,
    this.notes = '',
    this.result = '',
    this.requiredActions = '',
    this.postponementHistory = const [],
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory HearingModel.fromEntity(Hearing h) => HearingModel(
        id: h.id,
        officeId: h.officeId,
        caseId: h.caseId,
        caseTitle: h.caseTitle,
        clientName: h.clientName,
        court: h.court,
        location: h.location,
        date: h.date,
        notes: h.notes,
        result: h.result,
        requiredActions: h.requiredActions,
        postponementHistory: h.postponementHistory,
        createdAt: h.createdAt,
        updatedAt: h.updatedAt,
        isSynced: h.isSynced,
        isDeleted: h.isDeleted,
      );

  Hearing toEntity() => Hearing(
        id: id,
        officeId: officeId,
        caseId: caseId,
        caseTitle: caseTitle,
        clientName: clientName,
        court: court,
        location: location,
        date: date,
        notes: notes,
        result: result,
        requiredActions: requiredActions,
        postponementHistory: postponementHistory,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory HearingModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return HearingModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      caseId: data['caseId'] as String?,
      caseTitle: data['caseTitle'] as String? ?? '',
      clientName: data['clientName'] as String? ?? '',
      court: data['court'] as String? ?? '',
      location: data['location'] as String? ?? '',
      date: (data['date'] as Timestamp).toDate(),
      notes: data['notes'] as String? ?? '',
      result: data['result'] as String? ?? '',
      requiredActions: data['requiredActions'] as String? ?? '',
      postponementHistory: (data['postponementHistory'] as List? ?? [])
          .map((e) => PostponementRecord.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'caseId': caseId,
        'caseTitle': caseTitle,
        'clientName': clientName,
        'court': court,
        'location': location,
        'date': Timestamp.fromDate(date),
        'notes': notes,
        'result': result,
        'requiredActions': requiredActions,
        'postponementHistory': postponementHistory.map((p) => p.toMap()).toList(),
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'caseId': caseId,
        'caseTitle': caseTitle,
        'clientName': clientName,
        'court': court,
        'location': location,
        'date': date.toIso8601String(),
        'notes': notes,
        'result': result,
        'requiredActions': requiredActions,
        'postponementHistory': postponementHistory.map((p) => p.toMap()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory HearingModel.fromHiveMap(Map<dynamic, dynamic> map) => HearingModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        caseId: map['caseId'] as String?,
        caseTitle: map['caseTitle'] as String? ?? '',
        clientName: map['clientName'] as String? ?? '',
        court: map['court'] as String? ?? '',
        location: map['location'] as String? ?? '',
        date: DateTime.parse(map['date'] as String),
        notes: map['notes'] as String? ?? '',
        result: map['result'] as String? ?? '',
        requiredActions: map['requiredActions'] as String? ?? '',
        postponementHistory: (map['postponementHistory'] as List? ?? [])
            .map((e) => PostponementRecord.fromMap(Map<String, dynamic>.from(e as Map)))
            .toList(),
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  HearingModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => HearingModel(
        id: id,
        officeId: officeId,
        caseId: caseId,
        caseTitle: caseTitle,
        clientName: clientName,
        court: court,
        location: location,
        date: date,
        notes: notes,
        result: result,
        requiredActions: requiredActions,
        postponementHistory: postponementHistory,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class HearingHiveBox {
  static const String boxName = 'hearings_box';
  static Box get box => Hive.box(boxName);
}
