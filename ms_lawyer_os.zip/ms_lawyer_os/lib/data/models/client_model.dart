import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/client.dart';

/// نموذج البيانات - يحوّل بين Firestore و Hive وكيان [Client] النطاقي.
class ClientModel {
  final String id;
  final String officeId;
  final String fullName;
  final String nationalId;
  final String phone;
  final String whatsapp;
  final String address;
  final String notes;
  final List<String> attachmentPaths;
  final double totalFees;
  final String poaNumber;
  final DateTime? poaDate;
  final PoaType poaType;
  final NotarizationType notarization;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  ClientModel({
    required this.id,
    required this.officeId,
    required this.fullName,
    required this.nationalId,
    required this.phone,
    required this.whatsapp,
    required this.address,
    required this.notes,
    required this.attachmentPaths,
    this.totalFees = 0,
    this.poaNumber = '',
    this.poaDate,
    this.poaType = PoaType.general,
    this.notarization = NotarizationType.customary,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory ClientModel.fromEntity(Client c) => ClientModel(
        id: c.id,
        officeId: c.officeId,
        fullName: c.fullName,
        nationalId: c.nationalId,
        phone: c.phone,
        whatsapp: c.whatsapp,
        address: c.address,
        notes: c.notes,
        attachmentPaths: c.attachmentPaths,
        totalFees: c.totalFees,
        poaNumber: c.poaNumber,
        poaDate: c.poaDate,
        poaType: c.poaType,
        notarization: c.notarization,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
        isSynced: c.isSynced,
        isDeleted: c.isDeleted,
      );

  Client toEntity() => Client(
        id: id,
        officeId: officeId,
        fullName: fullName,
        nationalId: nationalId,
        phone: phone,
        whatsapp: whatsapp,
        address: address,
        notes: notes,
        attachmentPaths: attachmentPaths,
        totalFees: totalFees,
        poaNumber: poaNumber,
        poaDate: poaDate,
        poaType: poaType,
        notarization: notarization,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory ClientModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return ClientModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      fullName: data['fullName'] as String? ?? '',
      nationalId: data['nationalId'] as String? ?? '',
      phone: data['phone'] as String? ?? '',
      whatsapp: data['whatsapp'] as String? ?? '',
      address: data['address'] as String? ?? '',
      notes: data['notes'] as String? ?? '',
      attachmentPaths: List<String>.from(data['attachmentPaths'] as List? ?? []),
      totalFees: (data['totalFees'] as num?)?.toDouble() ?? 0,
      poaNumber: data['poaNumber'] as String? ?? '',
      poaDate: (data['poaDate'] as Timestamp?)?.toDate(),
      poaType: PoaType.values.firstWhere((e) => e.name == data['poaType'], orElse: () => PoaType.general),
      notarization: NotarizationType.values.firstWhere((e) => e.name == data['notarization'], orElse: () => NotarizationType.customary),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'fullName': fullName,
        'nationalId': nationalId,
        'phone': phone,
        'whatsapp': whatsapp,
        'address': address,
        'notes': notes,
        'attachmentPaths': attachmentPaths,
        'totalFees': totalFees,
        'poaNumber': poaNumber,
        'poaDate': poaDate != null ? Timestamp.fromDate(poaDate!) : null,
        'poaType': poaType.name,
        'notarization': notarization.name,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'fullName': fullName,
        'nationalId': nationalId,
        'phone': phone,
        'whatsapp': whatsapp,
        'address': address,
        'notes': notes,
        'attachmentPaths': attachmentPaths,
        'totalFees': totalFees,
        'poaNumber': poaNumber,
        'poaDate': poaDate?.toIso8601String(),
        'poaType': poaType.name,
        'notarization': notarization.name,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory ClientModel.fromHiveMap(Map<dynamic, dynamic> map) => ClientModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        fullName: map['fullName'] as String? ?? '',
        nationalId: map['nationalId'] as String? ?? '',
        phone: map['phone'] as String? ?? '',
        whatsapp: map['whatsapp'] as String? ?? '',
        address: map['address'] as String? ?? '',
        notes: map['notes'] as String? ?? '',
        attachmentPaths: List<String>.from(map['attachmentPaths'] as List? ?? []),
        totalFees: (map['totalFees'] as num?)?.toDouble() ?? 0,
        poaNumber: map['poaNumber'] as String? ?? '',
        poaDate: map['poaDate'] != null ? DateTime.parse(map['poaDate'] as String) : null,
        poaType: PoaType.values.firstWhere((e) => e.name == map['poaType'], orElse: () => PoaType.general),
        notarization: NotarizationType.values.firstWhere((e) => e.name == map['notarization'], orElse: () => NotarizationType.customary),
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  ClientModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => ClientModel(
        id: id,
        officeId: officeId,
        fullName: fullName,
        nationalId: nationalId,
        phone: phone,
        whatsapp: whatsapp,
        address: address,
        notes: notes,
        attachmentPaths: attachmentPaths,
        totalFees: totalFees,
        poaNumber: poaNumber,
        poaDate: poaDate,
        poaType: poaType,
        notarization: notarization,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

/// صندوق Hive المستخدم لتخزين بيانات العملاء محليًا (مشفّر)
class ClientHiveBox {
  static const String boxName = 'clients_box';
  static Box get box => Hive.box(boxName);
}
