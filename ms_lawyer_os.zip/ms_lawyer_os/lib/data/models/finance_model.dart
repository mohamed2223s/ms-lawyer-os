import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/finance.dart';
import '../local/hive_setup.dart';

class FinancePaymentModel {
  final String id;
  final String officeId;
  final String clientId;
  final double amount;
  final DateTime date;
  final PaymentMethod method;
  final String note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  FinancePaymentModel({
    required this.id,
    required this.officeId,
    required this.clientId,
    required this.amount,
    required this.date,
    required this.method,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory FinancePaymentModel.fromEntity(FinancePayment p) => FinancePaymentModel(
        id: p.id,
        officeId: p.officeId,
        clientId: p.clientId,
        amount: p.amount,
        date: p.date,
        method: p.method,
        note: p.note,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
        isSynced: p.isSynced,
        isDeleted: p.isDeleted,
      );

  FinancePayment toEntity() => FinancePayment(
        id: id,
        officeId: officeId,
        clientId: clientId,
        amount: amount,
        date: date,
        method: method,
        note: note,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory FinancePaymentModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return FinancePaymentModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      clientId: data['clientId'] as String,
      amount: (data['amount'] as num?)?.toDouble() ?? 0,
      date: (data['date'] as Timestamp?)?.toDate() ?? DateTime.now(),
      method: PaymentMethod.values.firstWhere((e) => e.name == data['method'], orElse: () => PaymentMethod.cash),
      note: data['note'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'clientId': clientId,
        'amount': amount,
        'date': Timestamp.fromDate(date),
        'method': method.name,
        'note': note,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'clientId': clientId,
        'amount': amount,
        'date': date.toIso8601String(),
        'method': method.name,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory FinancePaymentModel.fromHiveMap(Map<dynamic, dynamic> map) => FinancePaymentModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        clientId: map['clientId'] as String,
        amount: (map['amount'] as num?)?.toDouble() ?? 0,
        date: DateTime.parse(map['date'] as String),
        method: PaymentMethod.values.firstWhere((e) => e.name == map['method'], orElse: () => PaymentMethod.cash),
        note: map['note'] as String? ?? '',
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  FinancePaymentModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => FinancePaymentModel(
        id: id,
        officeId: officeId,
        clientId: clientId,
        amount: amount,
        date: date,
        method: method,
        note: note,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class CaseExpenseModel {
  final String id;
  final String officeId;
  final String caseId;
  final double amount;
  final DateTime date;
  final String expenseType;
  final String note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  CaseExpenseModel({
    required this.id,
    required this.officeId,
    required this.caseId,
    required this.amount,
    required this.date,
    required this.expenseType,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory CaseExpenseModel.fromEntity(CaseExpense e) => CaseExpenseModel(
        id: e.id,
        officeId: e.officeId,
        caseId: e.caseId,
        amount: e.amount,
        date: e.date,
        expenseType: e.expenseType,
        note: e.note,
        createdAt: e.createdAt,
        updatedAt: e.updatedAt,
        isSynced: e.isSynced,
        isDeleted: e.isDeleted,
      );

  CaseExpense toEntity() => CaseExpense(
        id: id,
        officeId: officeId,
        caseId: caseId,
        amount: amount,
        date: date,
        expenseType: expenseType,
        note: note,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory CaseExpenseModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return CaseExpenseModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      caseId: data['caseId'] as String,
      amount: (data['amount'] as num?)?.toDouble() ?? 0,
      date: (data['date'] as Timestamp?)?.toDate() ?? DateTime.now(),
      expenseType: data['expenseType'] as String? ?? '',
      note: data['note'] as String? ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'caseId': caseId,
        'amount': amount,
        'date': Timestamp.fromDate(date),
        'expenseType': expenseType,
        'note': note,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'caseId': caseId,
        'amount': amount,
        'date': date.toIso8601String(),
        'expenseType': expenseType,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory CaseExpenseModel.fromHiveMap(Map<dynamic, dynamic> map) => CaseExpenseModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        caseId: map['caseId'] as String,
        amount: (map['amount'] as num?)?.toDouble() ?? 0,
        date: DateTime.parse(map['date'] as String),
        expenseType: map['expenseType'] as String? ?? '',
        note: map['note'] as String? ?? '',
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  CaseExpenseModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => CaseExpenseModel(
        id: id,
        officeId: officeId,
        caseId: caseId,
        amount: amount,
        date: date,
        expenseType: expenseType,
        note: note,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class FinancePaymentHiveBox {
  static Box get box => Hive.box(HiveBoxes.financePayments);
}

class CaseExpenseHiveBox {
  static Box get box => Hive.box(HiveBoxes.financeExpenses);
}
