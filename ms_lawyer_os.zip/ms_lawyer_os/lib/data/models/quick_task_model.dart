import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import '../../domain/entities/quick_task.dart';
import '../local/hive_setup.dart';

class QuickTaskModel {
  final String id;
  final String officeId;
  final String title;
  final bool isDone;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  QuickTaskModel({
    required this.id,
    required this.officeId,
    required this.title,
    this.isDone = false,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  factory QuickTaskModel.fromEntity(QuickTask t) => QuickTaskModel(
        id: t.id,
        officeId: t.officeId,
        title: t.title,
        isDone: t.isDone,
        createdAt: t.createdAt,
        updatedAt: t.updatedAt,
        isSynced: t.isSynced,
        isDeleted: t.isDeleted,
      );

  QuickTask toEntity() => QuickTask(
        id: id,
        officeId: officeId,
        title: title,
        isDone: isDone,
        createdAt: createdAt,
        updatedAt: updatedAt,
        isSynced: isSynced,
        isDeleted: isDeleted,
      );

  factory QuickTaskModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return QuickTaskModel(
      id: doc.id,
      officeId: data['officeId'] as String,
      title: data['title'] as String? ?? '',
      isDone: data['isDone'] as bool? ?? false,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isSynced: true,
      isDeleted: data['isDeleted'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'officeId': officeId,
        'title': title,
        'isDone': isDone,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isDeleted': isDeleted,
      };

  Map<String, dynamic> toHiveMap() => {
        'id': id,
        'officeId': officeId,
        'title': title,
        'isDone': isDone,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isSynced': isSynced,
        'isDeleted': isDeleted,
      };

  factory QuickTaskModel.fromHiveMap(Map<dynamic, dynamic> map) => QuickTaskModel(
        id: map['id'] as String,
        officeId: map['officeId'] as String,
        title: map['title'] as String? ?? '',
        isDone: map['isDone'] as bool? ?? false,
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
        isSynced: map['isSynced'] as bool? ?? false,
        isDeleted: map['isDeleted'] as bool? ?? false,
      );

  QuickTaskModel copyWith({bool? isSynced, bool? isDeleted, DateTime? updatedAt}) => QuickTaskModel(
        id: id,
        officeId: officeId,
        title: title,
        isDone: isDone,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isSynced: isSynced ?? this.isSynced,
        isDeleted: isDeleted ?? this.isDeleted,
      );
}

class QuickTaskHiveBox {
  static Box get box => Hive.box(HiveBoxes.tasks);
}
