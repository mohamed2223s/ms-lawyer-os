import 'package:hive_flutter/hive_flutter.dart';
import '../../core/security/encryption_service.dart';
import '../models/client_model.dart';

/// أسماء صناديق Hive الأخرى المستخدمة عبر التطبيق (تُفتح تدريجيًا
/// عند إضافة كل موديول من الموديولات).
class HiveBoxes {
  HiveBoxes._();
  static const String syncQueue = 'sync_queue_box';
  static const String appMeta = 'app_meta_box';
  static const String cases = 'cases_box';
  static const String hearings = 'hearings_box';
  static const String tasks = 'tasks_box';
  static const String financeFees = 'finance_fees_box';
  static const String financeExpenses = 'finance_expenses_box';
  static const String financePayments = 'finance_payments_box';
  static const String documents = 'documents_box';
  static const String notifications = 'notifications_box';
}

/// تهيئة Hive وفتح الصناديق المشفّرة عند بدء التطبيق.
class HiveSetup {
  static Future<void> init() async {
    await Hive.initFlutter();
    final keyBytes = await EncryptionService.instance.getOrCreateHiveKey();
    final cipher = HiveAesCipher(keyBytes);

    await Hive.openBox(ClientHiveBox.boxName, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.syncQueue, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.appMeta, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.cases, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.hearings, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.tasks, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.financeFees, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.financeExpenses, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.financePayments, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.documents, encryptionCipher: cipher);
    await Hive.openBox(HiveBoxes.notifications, encryptionCipher: cipher);
  }
}
