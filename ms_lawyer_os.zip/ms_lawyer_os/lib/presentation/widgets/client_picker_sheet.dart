import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../domain/entities/client.dart';

/// نافذة اختيار عميل موجود لربطه بقضية جديدة.
Future<Client?> showClientPicker(BuildContext context, ClientRepository repository) {
  return showModalBottomSheet<Client>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surfaceDark,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (ctx) => _ClientPickerSheet(repository: repository),
  );
}

class _ClientPickerSheet extends StatefulWidget {
  final ClientRepository repository;
  const _ClientPickerSheet({required this.repository});

  @override
  State<_ClientPickerSheet> createState() => _ClientPickerSheetState();
}

class _ClientPickerSheetState extends State<_ClientPickerSheet> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final clients = widget.repository.search(_query);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: 12),
            const Text('اختر العميل', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.gold)),
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                autofocus: false,
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(hintText: 'ابحث عن عميل...', prefixIcon: Icon(Icons.search)),
              ),
            ),
            Expanded(
              child: clients.isEmpty
                  ? const Center(child: Text('لا يوجد عملاء مطابقين\nأضِف العميل أولًا من شاشة العملاء', textAlign: TextAlign.center))
                  : ListView.builder(
                      itemCount: clients.length,
                      itemBuilder: (context, index) {
                        final c = clients[index];
                        return ListTile(
                          leading: const Icon(Icons.person_outline, color: AppColors.gold),
                          title: Text(c.fullName),
                          subtitle: Text(c.phone, textDirection: TextDirection.ltr),
                          onTap: () => Navigator.pop(context, c),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
