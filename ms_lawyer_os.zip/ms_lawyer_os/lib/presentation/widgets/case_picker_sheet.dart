import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../data/repositories/case_repository.dart';
import '../../domain/entities/case.dart';

Future<LawCase?> showCasePicker(BuildContext context, CaseRepository repository) {
  return showModalBottomSheet<LawCase>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surfaceDark,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (ctx) => _CasePickerSheet(repository: repository),
  );
}

class _CasePickerSheet extends StatefulWidget {
  final CaseRepository repository;
  const _CasePickerSheet({required this.repository});

  @override
  State<_CasePickerSheet> createState() => _CasePickerSheetState();
}

class _CasePickerSheetState extends State<_CasePickerSheet> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final cases = widget.repository.search(_query);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: 12),
            const Text('اختر القضية', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.gold)),
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(hintText: 'ابحث عن قضية...', prefixIcon: Icon(Icons.search)),
              ),
            ),
            Expanded(
              child: cases.isEmpty
                  ? const Center(child: Text('لا توجد قضايا مطابقة', textAlign: TextAlign.center))
                  : ListView.builder(
                      itemCount: cases.length,
                      itemBuilder: (context, index) {
                        final c = cases[index];
                        return ListTile(
                          leading: const Icon(Icons.gavel_outlined, color: AppColors.gold),
                          title: Text(c.title, overflow: TextOverflow.ellipsis),
                          subtitle: Text('${c.clientName} • ${c.court}'),
                          onTap: () => Navigator.pop(context, c),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
