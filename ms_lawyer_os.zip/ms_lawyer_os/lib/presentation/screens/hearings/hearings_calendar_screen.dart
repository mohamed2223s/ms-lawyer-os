import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/hearing_repository.dart';
import '../../../domain/entities/hearing.dart';
import 'hearing_form_screen.dart';

class HearingsCalendarScreen extends StatefulWidget {
  final HearingRepository hearingRepository;
  final CaseRepository caseRepository;
  const HearingsCalendarScreen({super.key, required this.hearingRepository, required this.caseRepository});

  @override
  State<HearingsCalendarScreen> createState() => _HearingsCalendarScreenState();
}

class _HearingsCalendarScreenState extends State<HearingsCalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();
  CalendarFormat _format = CalendarFormat.month;

  @override
  void initState() {
    super.initState();
    widget.hearingRepository.startRemoteSync();
  }

  @override
  void dispose() {
    widget.hearingRepository.stopRemoteSync();
    super.dispose();
  }

  String _fmtTime(DateTime d) {
    final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final period = d.hour >= 12 ? 'م' : 'ص';
    return '$h:${d.minute.toString().padLeft(2, '0')} $period';
  }

  Future<void> _confirmDelete(Hearing h) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الجلسة'),
        content: Text('هل تريد حذف جلسة "${h.caseTitle}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) await widget.hearingRepository.deleteHearing(h.id);
  }

  Future<void> _postponeHearing(Hearing h) async {
    DateTime newDate = h.date.add(const Duration(days: 7));
    TimeOfDay newTime = TimeOfDay(hour: h.date.hour, minute: h.date.minute);
    final reasonCtrl = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('تأجيل الجلسة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('التاريخ الحالي: ${h.date.year}/${h.date.month.toString().padLeft(2, '0')}/${h.date.day.toString().padLeft(2, '0')}',
                  style: const TextStyle(color: AppColors.textSecondaryDark)),
              const SizedBox(height: 12),
              InkWell(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: newDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
                  );
                  if (picked != null) setDialogState(() => newDate = picked);
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'تاريخ الجلسة الجديد'),
                  child: Text('${newDate.year}/${newDate.month.toString().padLeft(2, '0')}/${newDate.day.toString().padLeft(2, '0')}'),
                ),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () async {
                  final picked = await showTimePicker(context: ctx, initialTime: newTime);
                  if (picked != null) setDialogState(() => newTime = picked);
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'الوقت'),
                  child: Text(newTime.format(ctx)),
                ),
              ),
              const SizedBox(height: 10),
              TextField(controller: reasonCtrl, decoration: const InputDecoration(labelText: 'سبب التأجيل')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأجيل')),
          ],
        ),
      ),
    );
    if (result == true) {
      final fullNewDate = DateTime(newDate.year, newDate.month, newDate.day, newTime.hour, newTime.minute);
      await widget.hearingRepository.postponeHearing(
        hearing: h,
        newDate: fullNewDate,
        reason: reasonCtrl.text.trim(),
      );
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الجلسات')),
      body: SafeArea(
        child: StreamBuilder<List<Hearing>>(
          stream: widget.hearingRepository.watchAll(),
          builder: (context, snapshot) {
            final all = snapshot.data ?? widget.hearingRepository.getAllLocal();
            final grouped = <DateTime, List<Hearing>>{};
            for (final h in all) {
              final key = DateTime(h.date.year, h.date.month, h.date.day);
              grouped.putIfAbsent(key, () => []).add(h);
            }
            final selectedKey = DateTime(_selectedDay.year, _selectedDay.month, _selectedDay.day);
            final dayHearings = (grouped[selectedKey] ?? [])..sort((a, b) => a.date.compareTo(b.date));

            return Column(
              children: [
                TableCalendar<Hearing>(
                  locale: 'ar',
                  firstDay: DateTime.now().subtract(const Duration(days: 365 * 2)),
                  lastDay: DateTime.now().add(const Duration(days: 365 * 2)),
                  focusedDay: _focusedDay,
                  selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                  calendarFormat: _format,
                  eventLoader: (day) => grouped[DateTime(day.year, day.month, day.day)] ?? [],
                  onDaySelected: (selected, focused) => setState(() {
                    _selectedDay = selected;
                    _focusedDay = focused;
                  }),
                  onFormatChanged: (format) => setState(() => _format = format),
                  onPageChanged: (focused) => _focusedDay = focused,
                  startingDayOfWeek: StartingDayOfWeek.saturday,
                  calendarStyle: const CalendarStyle(
                    outsideDaysVisible: false,
                    todayDecoration: BoxDecoration(color: AppColors.divider, shape: BoxShape.circle),
                    selectedDecoration: BoxDecoration(color: AppColors.gold, shape: BoxShape.circle),
                    selectedTextStyle: TextStyle(color: AppColors.black, fontWeight: FontWeight.w700),
                    markerDecoration: BoxDecoration(color: AppColors.gold, shape: BoxShape.circle),
                    weekendTextStyle: TextStyle(color: AppColors.textPrimaryDark),
                    defaultTextStyle: TextStyle(color: AppColors.textPrimaryDark),
                  ),
                  headerStyle: const HeaderStyle(
                    formatButtonVisible: true,
                    titleCentered: true,
                    formatButtonDecoration: BoxDecoration(color: AppColors.charcoal, borderRadius: BorderRadius.all(Radius.circular(8))),
                    formatButtonTextStyle: TextStyle(color: AppColors.gold),
                    titleTextStyle: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w700, fontSize: 16),
                    leftChevronIcon: Icon(Icons.chevron_right, color: AppColors.gold),
                    rightChevronIcon: Icon(Icons.chevron_left, color: AppColors.gold),
                  ),
                  daysOfWeekStyle: const DaysOfWeekStyle(weekdayStyle: TextStyle(color: AppColors.textSecondaryDark), weekendStyle: TextStyle(color: AppColors.textSecondaryDark)),
                ),
                const Divider(height: 1),
                Expanded(
                  child: dayHearings.isEmpty
                      ? const Center(
                          child: Text('لا توجد جلسات في هذا اليوم', style: TextStyle(color: AppColors.textSecondaryDark)),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                          itemCount: dayHearings.length,
                          itemBuilder: (context, index) {
                            final h = dayHearings[index];
                            return Card(
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: AppColors.gold.withOpacity(0.15),
                                  child: Text(_fmtTime(h.date).split(' ')[0], style: const TextStyle(fontSize: 11, color: AppColors.gold, fontWeight: FontWeight.w700)),
                                ),
                                title: Text(h.caseTitle, style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                                subtitle: Text('${h.clientName} • ${h.court}${h.location.isNotEmpty ? ' • ${h.location}' : ''}\n${_fmtTime(h.date)}'),
                                isThreeLine: true,
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    if (h.postponementHistory.isNotEmpty)
                                      Padding(
                                        padding: const EdgeInsets.only(left: 4),
                                        child: Tooltip(
                                          message: 'تم تأجيلها ${h.postponementHistory.length} مرة',
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                                            child: Text('${h.postponementHistory.length}', style: const TextStyle(color: AppColors.warning, fontSize: 11, fontWeight: FontWeight.w700)),
                                          ),
                                        ),
                                      ),
                                    IconButton(
                                      icon: const Icon(Icons.event_repeat, color: AppColors.gold, size: 20),
                                      onPressed: () => _postponeHearing(h),
                                      tooltip: 'تأجيل',
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                                      onPressed: () => _confirmDelete(h),
                                    ),
                                  ],
                                ),
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => HearingFormScreen(
                                      hearingRepository: widget.hearingRepository,
                                      caseRepository: widget.caseRepository,
                                      existing: h,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => HearingFormScreen(
              hearingRepository: widget.hearingRepository,
              caseRepository: widget.caseRepository,
              initialDate: _selectedDay,
            ),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('جلسة جديدة'),
      ),
    );
  }
}
