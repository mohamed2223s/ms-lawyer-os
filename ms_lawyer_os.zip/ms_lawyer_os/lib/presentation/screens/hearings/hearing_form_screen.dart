import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/hearing_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/hearing.dart';
import '../../widgets/case_picker_sheet.dart';

class HearingFormScreen extends StatefulWidget {
  final HearingRepository hearingRepository;
  final CaseRepository caseRepository;
  final Hearing? existing;
  final DateTime? initialDate;

  const HearingFormScreen({
    super.key,
    required this.hearingRepository,
    required this.caseRepository,
    this.existing,
    this.initialDate,
  });

  @override
  State<HearingFormScreen> createState() => _HearingFormScreenState();
}

class _HearingFormScreenState extends State<HearingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _clientCtrl;
  late final TextEditingController _courtCtrl;
  late final TextEditingController _locationCtrl;
  late final TextEditingController _notesCtrl;
  late final TextEditingController _caseTitleCtrl;

  LawCase? _linkedCase;
  late DateTime _date;
  late TimeOfDay _time;
  bool _saving = false;

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final h = widget.existing;
    _clientCtrl = TextEditingController(text: h?.clientName ?? '');
    _courtCtrl = TextEditingController(text: h?.court ?? '');
    _locationCtrl = TextEditingController(text: h?.location ?? '');
    _notesCtrl = TextEditingController(text: h?.notes ?? '');
    _caseTitleCtrl = TextEditingController(text: h?.caseTitle ?? '');
    final initial = h?.date ?? widget.initialDate ?? DateTime.now();
    _date = DateTime(initial.year, initial.month, initial.day);
    _time = TimeOfDay(hour: initial.hour == 0 ? 10 : initial.hour, minute: initial.minute);
  }

  @override
  void dispose() {
    _clientCtrl.dispose();
    _courtCtrl.dispose();
    _locationCtrl.dispose();
    _notesCtrl.dispose();
    _caseTitleCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickCase() async {
    final c = await showCasePicker(context, widget.caseRepository);
    if (c != null) {
      setState(() {
        _linkedCase = c;
        _caseTitleCtrl.text = c.title;
        _clientCtrl.text = c.clientName;
        _courtCtrl.text = c.court;
      });
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked != null) setState(() => _time = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final fullDate = DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);
      if (_isEditing) {
        final updated = widget.existing!.copyWith(
          caseId: _linkedCase?.id,
          caseTitle: _caseTitleCtrl.text.trim(),
          clientName: _clientCtrl.text.trim(),
          court: _courtCtrl.text.trim(),
          location: _locationCtrl.text.trim(),
          date: fullDate,
          notes: _notesCtrl.text.trim(),
        );
        await widget.hearingRepository.updateHearing(updated);
      } else {
        await widget.hearingRepository.addHearing(
          caseId: _linkedCase?.id,
          caseTitle: _caseTitleCtrl.text.trim(),
          clientName: _clientCtrl.text.trim(),
          court: _courtCtrl.text.trim(),
          location: _locationCtrl.text.trim(),
          date: fullDate,
          notes: _notesCtrl.text.trim(),
        );
      }
      if (mounted) Navigator.of(context).pop();
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  String _fmtDate(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Widget _postponementHistorySection() {
    final history = widget.existing?.postponementHistory ?? [];
    if (history.isEmpty) return const SizedBox.shrink();
    final sorted = history.toList()..sort((a, b) => b.recordedAt.compareTo(a.recordedAt));
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('سجل التأجيلات (${sorted.length})', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
          const SizedBox(height: 8),
          ...sorted.map((r) => Card(
                child: ListTile(
                  leading: const Icon(Icons.history, color: AppColors.gold),
                  title: Text('من ${_fmtDate(r.previousDate)}'),
                  subtitle: Text(r.reason.isEmpty ? _fmtDate(r.recordedAt) : '${r.reason}\n${_fmtDate(r.recordedAt)}'),
                  isThreeLine: r.reason.isNotEmpty,
                ),
              )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'تعديل الجلسة' : 'جلسة جديدة')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                OutlinedButton.icon(
                  onPressed: _pickCase,
                  icon: const Icon(Icons.gavel_outlined),
                  label: Text(_linkedCase == null ? 'ربط بقضية (اختياري)' : 'مرتبطة بـ: ${_linkedCase!.title}', overflow: TextOverflow.ellipsis),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _caseTitleCtrl,
                  decoration: const InputDecoration(labelText: 'عنوان/موضوع الجلسة *', prefixIcon: Icon(Icons.description_outlined)),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _clientCtrl,
                  decoration: const InputDecoration(labelText: 'اسم الموكل *', prefixIcon: Icon(Icons.person_outline)),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _courtCtrl,
                  decoration: const InputDecoration(labelText: 'المحكمة *', prefixIcon: Icon(Icons.account_balance_outlined)),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _locationCtrl,
                  decoration: const InputDecoration(labelText: 'المكان / العنوان', prefixIcon: Icon(Icons.location_on_outlined)),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _pickDate,
                        borderRadius: BorderRadius.circular(12),
                        child: InputDecorator(
                          decoration: const InputDecoration(labelText: 'التاريخ', prefixIcon: Icon(Icons.event_outlined)),
                          child: Text(_fmtDate(_date)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: InkWell(
                        onTap: _pickTime,
                        borderRadius: BorderRadius.circular(12),
                        child: InputDecorator(
                          decoration: const InputDecoration(labelText: 'الوقت', prefixIcon: Icon(Icons.access_time)),
                          child: Text(_time.format(context)),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _notesCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'ملاحظات / إجراءات مطلوبة', prefixIcon: Icon(Icons.note_outlined)),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: AppColors.black))
                      : Text(_isEditing ? 'حفظ التعديلات' : 'إضافة الجلسة'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
