import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/repositories/case_repository.dart';
import '../../data/repositories/client_repository.dart';
import 'cases/cases_list_screen.dart';
import 'clients/clients_list_screen.dart';
import 'dashboard/dashboard_screen.dart';
import 'settings/settings_screen.dart';

class AppShell extends StatefulWidget {
  final OfficeSession session;
  const AppShell({super.key, required this.session});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  late final ClientRepository _clientRepository;
  late final CaseRepository _caseRepository;

  @override
  void initState() {
    super.initState();
    _clientRepository = ClientRepository(officeId: widget.session.officeId);
    _caseRepository = CaseRepository(officeId: widget.session.officeId);
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(clientRepository: _clientRepository, caseRepository: _caseRepository, session: widget.session),
      ClientsListScreen(repository: _clientRepository, caseRepository: _caseRepository),
      CasesListScreen(caseRepository: _caseRepository, clientRepository: _clientRepository),
      SettingsScreen(session: widget.session),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_outlined), activeIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.people_outline), activeIcon: Icon(Icons.people), label: 'العملاء'),
          BottomNavigationBarItem(icon: Icon(Icons.gavel_outlined), activeIcon: Icon(Icons.gavel), label: 'القضايا'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_outlined), activeIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
        selectedItemColor: AppColors.gold,
      ),
    );
  }
}
