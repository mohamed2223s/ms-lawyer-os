import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/services/sync_queue_service.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../data/repositories/finance_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/client.dart';
import '../cases/case_detail_screen.dart';

/// لوحة التحكم الرئيسية - تعرض بيانات حقيقية من موديولي العملاء والقضايا.
/// عند إضافة موديولات الجلسات/المهام/المالية سيتم ربط بطاقاتها هنا بنفس
/// النمط دون أي بيانات وهمية.
class DashboardScreen extends StatelessWidget {
  final ClientRepository clientRepository;
  final CaseRepository caseRepository;
  final FinanceRepository financeRepository;
  final OfficeSession session;
  const DashboardScreen({
    super.key,
    required this.clientRepository,
    required this.caseRepository,
    required this.financeRepository,
    required this.session,
  });

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.gold,
          onRefresh: () async => SyncQueueService.instance.processQueue(),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: AppColors.gold.withOpacity(0.15),
                        child: const Icon(Icons.gavel_rounded, color: AppColors.gold),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('أهلًا، ${session.displayName}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                            const SizedBox(height: 2),
                            Text(session.role == 'admin' ? 'مدير المكتب' : 'محامي', style: const TextStyle(color: AppColors.textSecondaryDark)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              StreamBuilder<List<Client>>(
                stream: clientRepository.watchAll(),
                builder: (context, clientSnapshot) {
                  return StreamBuilder<List<LawCase>>(
                    stream: caseRepository.watchAll(),
                    builder: (context, caseSnapshot) {
                      final clients = clientSnapshot.data ?? clientRepository.getAllLocal();
                      final cases = caseSnapshot.data ?? caseRepository.getAllLocal();
                      final activeCases = cases.where((c) => c.status == CaseStatus.active).length;
                      final pendingSync = clients.where((c) => !c.isSynced).length + cases.where((c) => !c.isSynced).length;

                      final upcomingHearings = cases
                          .where((c) => c.nextHearingDate != null && c.nextHearingDate!.isAfter(DateTime.now().subtract(const Duration(days: 1))))
                          .toList()
                        ..sort((a, b) => a.nextHearingDate!.compareTo(b.nextHearingDate!));
                      final nextFew = upcomingHearings.take(5).toList();

                      final recentClients = List<Client>.from(clients)..sort((a, b) => b.createdAt.compareTo(a.createdAt));

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          GridView.count(
                            crossAxisCount: 2,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            childAspectRatio: 1.6,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            children: [
                              _StatCard(icon: Icons.people_outline, label: 'إجمالي العملاء', value: '${clients.length}'),
                              _StatCard(icon: Icons.gavel_outlined, label: 'قضايا منظورة', value: '$activeCases'),
                              _StatCard(icon: Icons.folder_outlined, label: 'إجمالي القضايا', value: '${cases.length}'),
                              _StatCard(
                                icon: Icons.cloud_off_outlined,
                                label: 'بانتظار المزامنة',
                                value: '$pendingSync',
                                color: pendingSync > 0 ? AppColors.warning : AppColors.success,
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          const Align(
                            alignment: Alignment.centerRight,
                            child: Text('الجلسات القادمة', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                          ),
                          const SizedBox(height: 8),
                          if (nextFew.isEmpty)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 14),
                              child: Text('لا توجد جلسات قادمة مسجّلة', style: TextStyle(color: AppColors.textSecondaryDark)),
                            )
                          else
                            ...nextFew.map((c) => Card(
                                  child: ListTile(
                                    leading: const Icon(Icons.event_outlined, color: AppColors.gold),
                                    title: Text(c.title, overflow: TextOverflow.ellipsis),
                                    subtitle: Text('${c.clientName} • ${c.court}'),
                                    trailing: Text(_fmt(c.nextHearingDate!), style: const TextStyle(fontWeight: FontWeight.w700)),
                                    onTap: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => CaseDetailScreen(
                                          caseRepository: caseRepository,
                                          clientRepository: clientRepository,
                                          financeRepository: financeRepository,
                                          initialCase: c,
                                        ),
                                      ),
                                    ),
                                  ),
                                )),
                          const SizedBox(height: 20),
                          const Align(
                            alignment: Alignment.centerRight,
                            child: Text('أحدث العملاء المضافين', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                          ),
                          const SizedBox(height: 8),
                          if (recentClients.isEmpty)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 14),
                              child: Text('لم تتم إضافة أي عميل بعد', style: TextStyle(color: AppColors.textSecondaryDark)),
                            )
                          else
                            ...recentClients.take(5).map((c) => Card(
                                  child: ListTile(
                                    leading: const Icon(Icons.person_outline, color: AppColors.gold),
                                    title: Text(c.fullName, style: const TextStyle(fontWeight: FontWeight.w600)),
                                    subtitle: Text(c.phone.isEmpty ? '—' : c.phone, textDirection: TextDirection.ltr),
                                  ),
                                )),
                        ],
                      );
                    },
                  );
                },
              ),
              const SizedBox(height: 8),
              Card(
                color: AppColors.charcoal,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: AppColors.gold, size: 20),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'موديولات الجلسات المستقلة، المهام، والمالية قيد التطوير في المراحل القادمة، وستظهر بياناتها هنا فور تفعيلها.',
                          style: TextStyle(fontSize: 12.5, color: AppColors.textSecondaryDark),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? color;
  const _StatCard({required this.icon, required this.label, required this.value, this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color ?? AppColors.gold),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondaryDark)),
          ],
        ),
      ),
    );
  }
}
