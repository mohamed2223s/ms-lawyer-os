import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/quick_task_repository.dart';
import '../../../domain/entities/quick_task.dart';

class QuickTasksScreen extends StatefulWidget {
  final QuickTaskRepository repository;
  const QuickTasksScreen({super.key, required this.repository});

  @override
  State<QuickTasksScreen> createState() => _QuickTasksScreenState();
}

class _QuickTasksScreenState extends State<QuickTasksScreen> {
  final _inputCtrl = TextEditingController();

  @override
  void dispose() {
    _inputCtrl.dispose();
    super.dispose();
  }

  Future<void> _addTask() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;
    _inputCtrl.clear();
    await widget.repository.addTask(text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المفكرة والمهام')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      decoration: const InputDecoration(hintText: 'اكتب مهمة أو ملاحظة جديدة...'),
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _addTask(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _addTask,
                    icon: const Icon(Icons.add),
                    style: IconButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: AppColors.black),
                  ),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<List<QuickTask>>(
                stream: widget.repository.watchAll(),
                builder: (context, snapshot) {
                  final all = snapshot.data ?? widget.repository.getAllLocal();
                  if (all.isEmpty) {
                    return const Center(child: Text('مفكرتك فاضية دلوقتي', style: TextStyle(color: AppColors.textSecondaryDark)));
                  }
                  final pending = all.where((t) => !t.isDone).toList();
                  final done = all.where((t) => t.isDone).toList();
                  return ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: [
                      ...pending.map((t) => _TaskTile(task: t, repository: widget.repository)),
                      if (done.isNotEmpty) ...[
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Text('تم إنجازها', style: TextStyle(color: AppColors.textSecondaryDark, fontWeight: FontWeight.w700)),
                        ),
                        ...done.map((t) => _TaskTile(task: t, repository: widget.repository)),
                      ],
                      const SizedBox(height: 20),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  final QuickTask task;
  final QuickTaskRepository repository;
  const _TaskTile({required this.task, required this.repository});

  @override
  Widget build(BuildContext context) {
    return Slidable(
      endActionPane: ActionPane(
        motion: const DrawerMotion(),
        extentRatio: 0.22,
        children: [
          SlidableAction(
            onPressed: (_) => repository.deleteTask(task.id),
            backgroundColor: AppColors.danger,
            foregroundColor: Colors.white,
            icon: Icons.delete_outline,
            label: 'حذف',
            borderRadius: BorderRadius.circular(14),
          ),
        ],
      ),
      child: Card(
        child: CheckboxListTile(
          value: task.isDone,
          onChanged: (_) => repository.toggleDone(task),
          controlAffinity: ListTileControlAffinity.leading,
          activeColor: AppColors.gold,
          title: Text(
            task.title,
            style: task.isDone
                ? const TextStyle(decoration: TextDecoration.lineThrough, color: AppColors.textSecondaryDark)
                : null,
          ),
        ),
      ),
    );
  }
}
