import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/registry_repository.dart';
import '../../../domain/entities/registry.dart';

class VaultScreen extends StatefulWidget {
  final VaultRepository repository;
  const VaultScreen({super.key, required this.repository});

  @override
  State<VaultScreen> createState() => _VaultScreenState();
}

class _VaultScreenState extends State<VaultScreen> {
  bool _showReturned = false;

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Future<void> _addItem() async {
    final clientCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final locationCtrl = TextEditingController();
    DateTime receivedDate = DateTime.now();
    final formKey = GlobalKey<FormState>();

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('استلام أمانة جديدة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.gold)),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: clientCtrl,
                    decoration: const InputDecoration(labelText: 'اسم الموكل *'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: descCtrl,
                    decoration: const InputDecoration(labelText: 'وصف الأوراق المستلمة *', hintText: 'مثال: عقد ملكية أصلي، إيصال أمانة'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: receivedDate,
                        firstDate: DateTime.now().subtract(const Duration(days: 3650)),
                        lastDate: DateTime.now().add(const Duration(days: 3650)),
                      );
                      if (picked != null) setDialogState(() => receivedDate = picked);
                    },
                    child: InputDecorator(
                      decoration: const InputDecoration(labelText: 'تاريخ الاستلام'),
                      child: Text(_fmt(receivedDate)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: locationCtrl,
                    decoration: const InputDecoration(
                      labelText: 'الموقع الفيزيائي',
                      hintText: 'مثال: دولاب أ - الرف 3 - حافظة 15',
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
                      },
                      child: const Text('حفظ'),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    if (result == true) {
      await widget.repository.addItem(
        clientName: clientCtrl.text.trim(),
        description: descCtrl.text.trim(),
        receivedDate: receivedDate,
        physicalLocation: locationCtrl.text.trim(),
      );
    }
  }

  Future<void> _markReturned(VaultItem item) async {
    final noteCtrl = TextEditingController();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسليم الأمانة للعميل'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('هل تم رد "${item.description}" للعميل ${item.clientName}؟'),
            const SizedBox(height: 12),
            TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد التسليم')),
        ],
      ),
    );
    if (confirm == true) {
      await widget.repository.markReturned(item, returnNote: noteCtrl.text.trim());
    }
  }

  Future<void> _shareReceipt(VaultItem item) async {
    final buffer = StringBuffer();
    buffer.writeln('إيصال رد أوراق');
    buffer.writeln('الموكل: ${item.clientName}');
    buffer.writeln('الأوراق: ${item.description}');
    buffer.writeln('تاريخ الاستلام: ${_fmt(item.receivedDate)}');
    if (item.returnedDate != null) buffer.writeln('تاريخ الرد: ${_fmt(item.returnedDate!)}');
    buffer.writeln('\nأقر أنا الموقّع أدناه باستلام الأوراق الموضحة أعلاه، وإبراء ذمة المكتب منها.');
    buffer.writeln('\nتوقيع الموكل: ..............................');
    await Share.share(buffer.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سجل الأمانات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addItem,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: const Text('استلام أمانة'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Text('عرض المُسلَّمة أيضًا'),
                  Switch(value: _showReturned, onChanged: (v) => setState(() => _showReturned = v), activeColor: AppColors.gold),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<List<VaultItem>>(
                stream: widget.repository.watchAll(),
                builder: (context, snapshot) {
                  var all = snapshot.data ?? widget.repository.getAllLocal();
                  if (!_showReturned) all = all.where((v) => !v.isReturned).toList();
                  if (all.isEmpty) {
                    return const Center(child: Text('لا توجد أمانات مسجّلة', style: TextStyle(color: AppColors.textSecondaryDark)));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: all.length,
                    itemBuilder: (context, index) {
                      final item = all[index];
                      return Card(
                        child: ListTile(
                          leading: Icon(
                            item.isReturned ? Icons.check_circle_outline : Icons.inventory_2_outlined,
                            color: item.isReturned ? AppColors.success : AppColors.gold,
                          ),
                          title: Text(item.description, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                            '${item.clientName} • استلام ${_fmt(item.receivedDate)}'
                            '${item.physicalLocation.isNotEmpty ? '\n📍 ${item.physicalLocation}' : ''}'
                            '${item.isReturned ? '\n✅ تم الرد ${_fmt(item.returnedDate!)}' : ''}',
                          ),
                          isThreeLine: true,
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(icon: const Icon(Icons.receipt_long_outlined, size: 20), onPressed: () => _shareReceipt(item)),
                              if (!item.isReturned)
                                IconButton(
                                  icon: const Icon(Icons.assignment_turned_in_outlined, size: 20, color: AppColors.success),
                                  onPressed: () => _markReturned(item),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
