import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/registry_repository.dart';
import '../../../domain/entities/registry.dart';

class LibraryScreen extends StatefulWidget {
  final LibraryRepository repository;
  const LibraryScreen({super.key, required this.repository});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  PracticeArea? _areaFilter;
  LibraryDocCategory? _categoryFilter;

  Future<void> _addDocument() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: false);
    if (result == null || result.files.single.path == null) return;

    final titleCtrl = TextEditingController(text: p.basenameWithoutExtension(result.files.single.name));
    LibraryDocCategory category = LibraryDocCategory.pleadings;
    PracticeArea area = PracticeArea.civil;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة مستند للمكتبة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'عنوان المستند')),
              const SizedBox(height: 12),
              DropdownButtonFormField<LibraryDocCategory>(
                value: category,
                decoration: const InputDecoration(labelText: 'نوع المستند'),
                items: LibraryDocCategory.values.map((c) => DropdownMenuItem(value: c, child: Text(c.labelAr))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<PracticeArea>(
                value: area,
                decoration: const InputDecoration(labelText: 'التخصص'),
                items: PracticeArea.values.map((a) => DropdownMenuItem(value: a, child: Text(a.labelAr))).toList(),
                onChanged: (v) => setDialogState(() => area = v ?? area),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (confirm != true) return;

    final appDir = await getApplicationDocumentsDirectory();
    final libDir = Directory(p.join(appDir.path, 'office_library'));
    if (!await libDir.exists()) await libDir.create(recursive: true);
    final fileName = '${DateTime.now().microsecondsSinceEpoch}_${result.files.single.name}';
    final savedPath = p.join(libDir.path, fileName);
    await File(result.files.single.path!).copy(savedPath);

    await widget.repository.addDocument(
      title: titleCtrl.text.trim().isEmpty ? result.files.single.name : titleCtrl.text.trim(),
      category: category,
      practiceArea: area,
      filePath: savedPath,
    );
  }

  Future<void> _confirmDelete(LibraryDocument d) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف المستند'),
        content: Text('هل تريد حذف "${d.title}" من المكتبة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) await widget.repository.deleteDocument(d.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مكتبة المكتب')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addDocument,
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: const Text('إضافة مستند'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  const SizedBox(width: 4),
                  ChoiceChip(
                    label: const Text('كل التخصصات'),
                    selected: _areaFilter == null,
                    onSelected: (_) => setState(() => _areaFilter = null),
                  ),
                  const SizedBox(width: 8),
                  ...PracticeArea.values.map((a) => Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: ChoiceChip(
                          label: Text(a.labelAr),
                          selected: _areaFilter == a,
                          onSelected: (_) => setState(() => _areaFilter = _areaFilter == a ? null : a),
                        ),
                      )),
                ],
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  const SizedBox(width: 4),
                  ChoiceChip(
                    label: const Text('كل الأنواع'),
                    selected: _categoryFilter == null,
                    onSelected: (_) => setState(() => _categoryFilter = null),
                  ),
                  const SizedBox(width: 8),
                  ...LibraryDocCategory.values.map((c) => Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: ChoiceChip(
                          label: Text(c.labelAr),
                          selected: _categoryFilter == c,
                          onSelected: (_) => setState(() => _categoryFilter = _categoryFilter == c ? null : c),
                        ),
                      )),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: StreamBuilder<List<LibraryDocument>>(
                stream: widget.repository.watchAll(),
                builder: (context, snapshot) {
                  var all = snapshot.data ?? widget.repository.getAllLocal();
                  if (_areaFilter != null) all = all.where((d) => d.practiceArea == _areaFilter).toList();
                  if (_categoryFilter != null) all = all.where((d) => d.category == _categoryFilter).toList();
                  if (all.isEmpty) {
                    return const Center(child: Text('لا توجد مستندات مطابقة', style: TextStyle(color: AppColors.textSecondaryDark)));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: all.length,
                    itemBuilder: (context, index) {
                      final d = all[index];
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.menu_book_outlined, color: AppColors.gold),
                          title: Text(d.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text('${d.category.labelAr} • ${d.practiceArea.labelAr}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.share_outlined, size: 20),
                                onPressed: () {
                                  if (File(d.filePath).existsSync()) {
                                    Share.shareXFiles([XFile(d.filePath)], text: d.title);
                                  }
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 20, color: AppColors.danger),
                                onPressed: () => _confirmDelete(d),
                              ),
                            ],
                          ),
                          onTap: () {
                            if (File(d.filePath).existsSync()) OpenFilex.open(d.filePath);
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
