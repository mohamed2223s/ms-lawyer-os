import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/registry_repository.dart';
import '../../../domain/entities/registry.dart';

class OpponentsListScreen extends StatefulWidget {
  final OpponentRepository repository;
  final String? clientIdFilter;
  final String? clientNameForNew;
  const OpponentsListScreen({super.key, required this.repository, this.clientIdFilter, this.clientNameForNew});

  @override
  State<OpponentsListScreen> createState() => _OpponentsListScreenState();
}

class _OpponentsListScreenState extends State<OpponentsListScreen> {
  String _query = '';

  Future<void> _openForm({Opponent? existing}) async {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final addressCtrl = TextEditingController(text: existing?.address ?? '');
    final nationalIdCtrl = TextEditingController(text: existing?.nationalId ?? '');
    final lawyerNameCtrl = TextEditingController(text: existing?.lawyerName ?? '');
    final lawyerPhoneCtrl = TextEditingController(text: existing?.lawyerPhone ?? '');
    final notesCtrl = TextEditingController(text: existing?.notes ?? '');
    final formKey = GlobalKey<FormState>();

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(existing == null ? 'خصم جديد' : 'تعديل بيانات الخصم',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.gold)),
                const SizedBox(height: 16),
                TextFormField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'اسم الخصم *'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(controller: addressCtrl, decoration: const InputDecoration(labelText: 'العنوان (للإعلانات القانونية)')),
                const SizedBox(height: 12),
                TextFormField(controller: nationalIdCtrl, decoration: const InputDecoration(labelText: 'الرقم القومي')),
                const SizedBox(height: 12),
                TextFormField(controller: lawyerNameCtrl, decoration: const InputDecoration(labelText: 'اسم محامي الخصم')),
                const SizedBox(height: 12),
                TextFormField(
                  controller: lawyerPhoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'هاتف محامي الخصم'),
                ),
                const SizedBox(height: 12),
                TextFormField(controller: notesCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      if (formKey.currentState!.validate()) Navigator.pop(ctx, true);
                    },
                    child: const Text('حفظ'),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );

    if (result == true) {
      if (existing == null) {
        await widget.repository.addOpponent(
          name: nameCtrl.text.trim(),
          clientId: widget.clientIdFilter,
          address: addressCtrl.text.trim(),
          nationalId: nationalIdCtrl.text.trim(),
          lawyerName: lawyerNameCtrl.text.trim(),
          lawyerPhone: lawyerPhoneCtrl.text.trim(),
          notes: notesCtrl.text.trim(),
        );
      } else {
        await widget.repository.updateOpponent(existing.copyWith(
          name: nameCtrl.text.trim(),
          address: addressCtrl.text.trim(),
          nationalId: nationalIdCtrl.text.trim(),
          lawyerName: lawyerNameCtrl.text.trim(),
          lawyerPhone: lawyerPhoneCtrl.text.trim(),
          notes: notesCtrl.text.trim(),
        ));
      }
    }
  }

  Future<void> _confirmDelete(Opponent o) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الخصم'),
        content: Text('هل تريد حذف "${o.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) await widget.repository.deleteOpponent(o.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.clientIdFilter != null ? 'خصوم ${widget.clientNameForNew ?? ''}' : 'قاعدة بيانات الخصوم')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.black,
        icon: const Icon(Icons.add),
        label: const Text('خصم جديد'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'ابحث بالاسم أو اسم محاميه...',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (v) => setState(() => _query = v.trim()),
              ),
            ),
            Expanded(
              child: StreamBuilder<List<Opponent>>(
                stream: widget.repository.watchAll(),
                builder: (context, snapshot) {
                  var all = snapshot.data ?? widget.repository.getAllLocal();
                  if (widget.clientIdFilter != null) {
                    all = all.where((o) => o.clientId == widget.clientIdFilter).toList();
                  }
                  final filtered = _query.isEmpty
                      ? all
                      : all
                          .where((o) =>
                              o.name.contains(_query) ||
                              o.lawyerName.contains(_query) ||
                              o.nationalId.contains(_query))
                          .toList();
                  if (filtered.isEmpty) {
                    return const Center(child: Text('لا يوجد خصوم مسجّلون بعد', style: TextStyle(color: AppColors.textSecondaryDark)));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final o = filtered[index];
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(child: Icon(Icons.gavel_outlined)),
                          title: Text(o.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                            [
                              if (o.lawyerName.isNotEmpty) 'محاميه: ${o.lawyerName}',
                              if (o.lawyerPhone.isNotEmpty) o.lawyerPhone,
                            ].join(' • '),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (o.lawyerPhone.isNotEmpty)
                                IconButton(
                                  icon: const Icon(Icons.call_outlined, size: 20),
                                  onPressed: () => launchUrl(Uri.parse('tel:${o.lawyerPhone}')),
                                ),
                              IconButton(icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _openForm(existing: o)),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 20, color: AppColors.danger),
                                onPressed: () => _confirmDelete(o),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
