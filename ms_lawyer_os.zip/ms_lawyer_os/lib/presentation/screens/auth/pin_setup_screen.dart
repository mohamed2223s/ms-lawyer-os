import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/security/auth_lock_service.dart';

class PinSetupScreen extends StatefulWidget {
  final VoidCallback onCompleted;
  const PinSetupScreen({super.key, required this.onCompleted});

  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  String _firstPin = '';
  String _currentInput = '';
  bool _confirming = false;
  String? _error;

  void _onDigit(String digit) {
    if (_currentInput.length >= 6) return;
    setState(() {
      _currentInput += digit;
      _error = null;
    });
    if (_currentInput.length == 6) _handleComplete();
  }

  void _onBackspace() {
    if (_currentInput.isEmpty) return;
    setState(() => _currentInput = _currentInput.substring(0, _currentInput.length - 1));
  }

  Future<void> _handleComplete() async {
    if (!_confirming) {
      setState(() {
        _firstPin = _currentInput;
        _currentInput = '';
        _confirming = true;
      });
      return;
    }
    if (_currentInput == _firstPin) {
      await AuthLockService.instance.setPin(_firstPin);
      final biometricAvailable = await AuthLockService.instance.isBiometricAvailable();
      if (biometricAvailable && mounted) {
        final enable = await _askEnableBiometric();
        if (enable) await AuthLockService.instance.setBiometricEnabled(true);
      }
      widget.onCompleted();
    } else {
      setState(() {
        _error = 'الرقمان غير متطابقين، حاول مرة أخرى';
        _firstPin = '';
        _currentInput = '';
        _confirming = false;
      });
    }
  }

  Future<bool> _askEnableBiometric() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: const Text('تفعيل البصمة'),
            content: const Text('هل تريد استخدام بصمة الإصبع/الوجه لفتح التطبيق بجانب رمز PIN؟'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لاحقًا')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تفعيل')),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_outline, color: AppColors.gold, size: 56),
              const SizedBox(height: 16),
              Text(
                _confirming ? 'أعد إدخال رمز PIN للتأكيد' : 'إنشاء رمز PIN لحماية التطبيق',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimaryDark),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              _PinDots(length: _currentInput.length),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: AppColors.danger)),
              ],
              const SizedBox(height: 32),
              _NumPad(onDigit: _onDigit, onBackspace: _onBackspace),
            ],
          ),
        ),
      ),
    );
  }
}

class _PinDots extends StatelessWidget {
  final int length;
  const _PinDots({required this.length});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(6, (i) {
        final filled = i < length;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 6),
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? AppColors.gold : Colors.transparent,
            border: Border.all(color: AppColors.gold, width: 1.6),
          ),
        );
      }),
    );
  }
}

class _NumPad extends StatelessWidget {
  final void Function(String) onDigit;
  final VoidCallback onBackspace;
  const _NumPad({required this.onDigit, required this.onBackspace});

  @override
  Widget build(BuildContext context) {
    final keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'];
    return SizedBox(
      width: 280,
      child: GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        children: keys.map((k) {
          if (k.isEmpty) return const SizedBox.shrink();
          return InkWell(
            borderRadius: BorderRadius.circular(40),
            onTap: () => k == '⌫' ? onBackspace() : onDigit(k),
            child: Container(
              decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.charcoal),
              alignment: Alignment.center,
              child: k == '⌫'
                  ? const Icon(Icons.backspace_outlined, color: AppColors.gold)
                  : Text(k, style: const TextStyle(fontSize: 22, color: AppColors.textPrimaryDark, fontWeight: FontWeight.w600)),
            ),
          );
        }).toList(),
      ),
    );
  }
}
