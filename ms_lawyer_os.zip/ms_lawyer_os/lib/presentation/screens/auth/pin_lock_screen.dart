import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/security/auth_lock_service.dart';
import '../../../data/repositories/auth_repository.dart';
import 'pin_setup_screen.dart';

class PinLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const PinLockScreen({super.key, required this.onUnlocked});

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  String _input = '';
  String? _error;
  bool _checking = false;

  @override
  void initState() {
    super.initState();
    _tryBiometricOnStart();
  }

  Future<void> _tryBiometricOnStart() async {
    final enabled = await AuthLockService.instance.isBiometricEnabled();
    if (enabled) {
      final ok = await AuthLockService.instance.authenticateWithBiometrics();
      if (ok && mounted) widget.onUnlocked();
    }
  }

  Future<void> _onDigit(String d) async {
    if (_input.length >= 6 || _checking) return;
    setState(() {
      _input += d;
      _error = null;
    });
    if (_input.length == 6) {
      setState(() => _checking = true);
      final ok = await AuthLockService.instance.verifyPin(_input);
      if (ok) {
        widget.onUnlocked();
      } else {
        setState(() {
          _error = 'رمز PIN غير صحيح';
          _input = '';
          _checking = false;
        });
      }
    }
  }

  void _onBackspace() {
    if (_input.isEmpty) return;
    setState(() => _input = _input.substring(0, _input.length - 1));
  }

  Future<void> _signOutInstead() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج من الحساب بدلًا من إدخال الرمز؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تسجيل الخروج')),
        ],
      ),
    );
    if (confirm == true) {
      await AuthRepository.instance.signOut();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.shield_moon_outlined, color: AppColors.gold, size: 56),
              const SizedBox(height: 12),
              const Text('أدخل رمز PIN لفتح التطبيق',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimaryDark)),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, (i) {
                  final filled = i < _input.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? AppColors.gold : Colors.transparent,
                      border: Border.all(color: AppColors.gold, width: 1.6),
                    ),
                  );
                }),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: AppColors.danger)),
              ],
              const SizedBox(height: 32),
              SizedBox(
                width: 280,
                child: GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  children: ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'bio', '0', '⌫'].map((k) {
                    if (k == 'bio') {
                      return InkWell(
                        borderRadius: BorderRadius.circular(40),
                        onTap: () async {
                          final enabled = await AuthLockService.instance.isBiometricEnabled();
                          if (!enabled) return;
                          final ok = await AuthLockService.instance.authenticateWithBiometrics();
                          if (ok && mounted) widget.onUnlocked();
                        },
                        child: Container(
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.charcoal),
                          alignment: Alignment.center,
                          child: const Icon(Icons.fingerprint, color: AppColors.gold),
                        ),
                      );
                    }
                    return InkWell(
                      borderRadius: BorderRadius.circular(40),
                      onTap: () => k == '⌫' ? _onBackspace() : _onDigit(k),
                      child: Container(
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.charcoal),
                        alignment: Alignment.center,
                        child: k == '⌫'
                            ? const Icon(Icons.backspace_outlined, color: AppColors.gold)
                            : Text(k, style: const TextStyle(fontSize: 22, color: AppColors.textPrimaryDark, fontWeight: FontWeight.w600)),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 16),
              TextButton(onPressed: _signOutInstead, child: const Text('تسجيل الخروج')),
            ],
          ),
        ),
      ),
    );
  }
}

/// يُستخدم عند أول تسجيل دخول: يتحقق إن كان PIN مُعد مسبقًا، وإلا يعرض شاشة الإعداد.
class SecurityGate extends StatefulWidget {
  final Widget child;
  const SecurityGate({super.key, required this.child});

  @override
  State<SecurityGate> createState() => _SecurityGateState();
}

class _SecurityGateState extends State<SecurityGate> {
  bool? _hasPin;
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final has = await AuthLockService.instance.hasPinConfigured();
    setState(() => _hasPin = has);
  }

  @override
  Widget build(BuildContext context) {
    if (_hasPin == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.gold)));
    }
    if (!_hasPin!) {
      return PinSetupScreen(onCompleted: () => setState(() {
            _hasPin = true;
            _unlocked = true;
          }));
    }
    if (!_unlocked) {
      return PinLockScreen(onUnlocked: () => setState(() => _unlocked = true));
    }
    return widget.child;
  }
}
