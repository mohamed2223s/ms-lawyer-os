import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/client.dart';
import '../../widgets/client_picker_sheet.dart';

class CaseFormScreen extends StatefulWidget {
  final CaseRepository caseRepository;
  final ClientRepository clientRepository;
  final LawCase? existing;
  final Client? preselectedClient;

  const CaseFormScreen({
    super.key,
    required this.caseRepository,
    required this.clientRepository,
    this.existing,
    this.preselectedClient,
  });

  @override
  State<CaseFormScreen> createState() => _CaseFormScreenState();
}

class _CaseFormScreenState extends State<CaseFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _courtCtrl;
  late final TextEditingController _circuitCtrl;
  late final TextEditingController _caseNumberCtrl;
  late final TextEditingController _yearCtrl;
  late final TextEditingController _caseTypeCtrl;
  late final TextEditingController _opponentCtrl;
  late final TextEditingController _opponentLawyerCtrl;

  Client? _selectedClient;
  CaseDegree _degree = CaseDegree.first;
  CaseStatus _status = CaseStatus.active;
  DateTime? _nextHearingDate;
  bool _saving = false;

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final c = widget.existing;
    _courtCtrl = TextEditingController(text: c?.court ?? '');
    _circuitCtrl = TextEditingController(text: c?.circuit ?? '');
    _caseNumberCtrl = TextEditingController(text: c?.caseNumber ?? '');
    _yearCtrl = TextEditingController(text: c?.year ?? DateTime.now().year.toString());
    _caseTypeCtrl = TextEditingController(text: c?.caseType ?? '');
    _opponentCtrl = TextEditingController(text: c?.opponentName ?? '');
    _opponentLawyerCtrl = TextEditingController(text: c?.opponentLawyer ?? '');
    _degree = c?.degree ?? CaseDegree.first;
    _status = c?.status ?? CaseStatus.active;
    _nextHearingDate = c?.nextHearingDate;

    if (widget.preselectedClient != null) {
      _selectedClient = widget.preselectedClient;
    } else if (c != null) {
      _selectedClient = widget.clientRepository.getById(c.clientId) ??
          Client(
            id: c.clientId,
            officeId: c.officeId,
            fullName: c.clientName,
            nationalId: '',
            phone: '',
            whatsapp: '',
            address: '',
            notes: '',
            attachmentPaths: const [],
            createdAt: c.createdAt,
            updatedAt: c.updatedAt,
          );
    }
  }

  @override
  void dispose() {
    _courtCtrl.dispose();
    _circuitCtrl.dispose();
    _caseNumberCtrl.dispose();
    _yearCtrl.dispose();
    _caseTypeCtrl.dispose();
    _opponentCtrl.dispose();
    _opponentLawyerCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickClient() async {
    final client = await showClientPicker(context, widget.clientRepository);
    if (client != null) setState(() => _selectedClient = client);
  }

  Future<void> _pickNextHearingDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _nextHearingDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
    );
    if (date != null) setState(() => _nextHearingDate = date);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedClient == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى اختيار العميل المرتبط بالقضية')));
      return;
    }
    setState(() => _saving = true);
    try {
      if (_isEditing) {
        final updated = widget.existing!.copyWith(
          clientId: _selectedClient!.id,
          clientName: _selectedClient!.fullName,
          court: _courtCtrl.text.trim(),
          circuit: _circuitCtrl.text.trim(),
          caseNumber: _caseNumberCtrl.text.trim(),
          year: _yearCtrl.text.trim(),
          caseType: _caseTypeCtrl.text.trim(),
          degree: _degree,
          opponentName: _opponentCtrl.text.trim(),
          opponentLawyer: _opponentLawyerCtrl.text.trim(),
          status: _status,
          nextHearingDate: _nextHearingDate,
          clearNextHearing: _nextHearingDate == null,
        );
        await widget.caseRepository.updateCase(updated);
      } else {
        await widget.caseRepository.addCase(
          clientId: _selectedClient!.id,
          clientName: _selectedClient!.fullName,
          court: _courtCtrl.text.trim(),
          circuit: _circuitCtrl.text.trim(),
          caseNumber: _caseNumberCtrl.text.trim(),
          year: _yearCtrl.text.trim(),
          caseType: _caseTypeCtrl.text.trim(),
          degree: _degree,
          opponentName: _opponentCtrl.text.trim(),
          opponentLawyer: _opponentLawyerCtrl.text.trim(),
          status: _status,
          nextHearingDate: _nextHearingDate,
        );
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Row(children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 10),
              Text('تم تسجيل القضية بنجاح'),
            ]),
            backgroundColor: AppColors.success,
          ),
        );
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('حصل خطأ أثناء الحفظ: $e'), backgroundColor: AppColors.danger),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'تعديل القضية' : 'قضية جديدة')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                InkWell(
                  onTap: _pickClient,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'العميل *', prefixIcon: Icon(Icons.person_outline)),
                    child: Text(
                      _selectedClient?.fullName ?? 'اضغط لاختيار العميل',
                      style: TextStyle(color: _selectedClient == null ? AppColors.textSecondaryDark : AppColors.textPrimaryDark),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _caseTypeCtrl,
                        decoration: const InputDecoration(labelText: 'نوع القضية *'),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: DropdownButtonFormField<CaseDegree>(
                        value: _degree,
                        decoration: const InputDecoration(labelText: 'الدرجة'),
                        items: CaseDegree.values
                            .map((d) => DropdownMenuItem(value: d, child: Text(d.labelAr)))
                            .toList(),
                        onChanged: (v) => setState(() => _degree = v!),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _courtCtrl,
                  decoration: const InputDecoration(labelText: 'المحكمة *', prefixIcon: Icon(Icons.account_balance_outlined)),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _circuitCtrl,
                  decoration: const InputDecoration(labelText: 'الدائرة', prefixIcon: Icon(Icons.meeting_room_outlined)),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _caseNumberCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'رقم القضية *'),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _yearCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'السنة *'),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _opponentCtrl,
                  decoration: const InputDecoration(labelText: 'الخصم', prefixIcon: Icon(Icons.person_off_outlined)),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _opponentLawyerCtrl,
                  decoration: const InputDecoration(labelText: 'محامي الخصم', prefixIcon: Icon(Icons.balance_outlined)),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<CaseStatus>(
                  value: _status,
                  decoration: const InputDecoration(labelText: 'حالة القضية'),
                  items: CaseStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(s.labelAr))).toList(),
                  onChanged: (v) => setState(() => _status = v!),
                ),
                const SizedBox(height: 14),
                InkWell(
                  onTap: _pickNextHearingDate,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'الجلسة القادمة', prefixIcon: Icon(Icons.event_outlined)),
                    child: Row(
                      children: [
                        Text(
                          _nextHearingDate == null
                              ? 'غير محدد'
                              : '${_nextHearingDate!.year}/${_nextHearingDate!.month}/${_nextHearingDate!.day}',
                        ),
                        const Spacer(),
                        if (_nextHearingDate != null)
                          IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => _nextHearingDate = null)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: AppColors.black))
                      : Text(_isEditing ? 'حفظ التعديلات' : 'إضافة القضية'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
