import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../data/repositories/finance_repository.dart';
import '../../../domain/entities/case.dart';
import 'case_detail_screen.dart';
import 'case_form_screen.dart';

class CasesListScreen extends StatefulWidget {
  final CaseRepository caseRepository;
  final ClientRepository clientRepository;
  final FinanceRepository financeRepository;
  const CasesListScreen({super.key, required this.caseRepository, required this.clientRepository, required this.financeRepository});

  @override
  State<CasesListScreen> createState() => _CasesListScreenState();
}

class _CasesListScreenState extends State<CasesListScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  CaseStatus? _statusFilter;

  @override
  void initState() {
    super.initState();
    widget.caseRepository.startRemoteSync();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    widget.caseRepository.stopRemoteSync();
    super.dispose();
  }

  Color _statusColor(CaseStatus s) {
    switch (s) {
      case CaseStatus.active:
        return AppColors.success;
      case CaseStatus.adjourned:
        return AppColors.warning;
      case CaseStatus.closed:
        return AppColors.textSecondaryDark;
      case CaseStatus.appeal:
        return AppColors.info;
    }
  }

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Future<void> _confirmDelete(LawCase c) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف القضية'),
        content: Text('هل تريد حذف "${c.title}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) await widget.caseRepository.deleteCase(c.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('القضايا')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  hintText: 'ابحث برقم القضية، العميل، المحكمة...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(icon: const Icon(Icons.close), onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _query = '');
                        }),
                ),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                children: [
                  _filterChip('الكل', _statusFilter == null, () => setState(() => _statusFilter = null)),
                  ...CaseStatus.values.map((s) => _filterChip(s.labelAr, _statusFilter == s, () => setState(() => _statusFilter = s))),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<List<LawCase>>(
                stream: widget.caseRepository.watchAll(),
                builder: (context, snapshot) {
                  var cases = snapshot.data ?? widget.caseRepository.getAllLocal();
                  if (_query.isNotEmpty) cases = widget.caseRepository.search(_query);
                  if (_statusFilter != null) cases = cases.where((c) => c.status == _statusFilter).toList();

                  if (cases.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.folder_open_outlined, size: 64, color: AppColors.textSecondaryDark),
                          const SizedBox(height: 12),
                          Text(
                            _query.isEmpty && _statusFilter == null ? 'لا توجد قضايا بعد\nاضغط + لإضافة قضية جديدة' : 'لا توجد نتائج مطابقة',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: AppColors.textSecondaryDark),
                          ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.only(bottom: 90, top: 8),
                    itemCount: cases.length,
                    itemBuilder: (context, index) {
                      final c = cases[index];
                      return Slidable(
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              onPressed: (_) => _confirmDelete(c),
                              backgroundColor: AppColors.danger,
                              foregroundColor: Colors.white,
                              icon: Icons.delete_outline,
                              label: 'حذف',
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ],
                        ),
                        child: Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: _statusColor(c.status).withOpacity(0.15),
                              child: Icon(Icons.gavel_outlined, color: _statusColor(c.status), size: 20),
                            ),
                            title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                            subtitle: Text(
                              '${c.clientName} • ${c.court}${c.nextHearingDate != null ? ' • جلسة ${_fmt(c.nextHearingDate!)}' : ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: !c.isSynced
                                ? const Icon(Icons.cloud_off_outlined, color: AppColors.warning, size: 18)
                                : const Icon(Icons.chevron_left),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CaseDetailScreen(
                                  caseRepository: widget.caseRepository,
                                  clientRepository: widget.clientRepository,
                                  financeRepository: widget.financeRepository,
                                  initialCase: c,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CaseFormScreen(caseRepository: widget.caseRepository, clientRepository: widget.clientRepository),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('قضية جديدة'),
      ),
    );
  }

  Widget _filterChip(String label, bool selected, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: AppColors.gold,
        labelStyle: TextStyle(color: selected ? AppColors.black : AppColors.textPrimaryDark, fontWeight: FontWeight.w600),
        backgroundColor: AppColors.charcoal,
      ),
    );
  }
}
