import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/utils/share_helpers.dart';
import '../../../core/utils/ui_feedback.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../data/repositories/finance_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/finance.dart';
import 'case_form_screen.dart';

class CaseDetailScreen extends StatefulWidget {
  final CaseRepository caseRepository;
  final ClientRepository clientRepository;
  final FinanceRepository financeRepository;
  final LawCase initialCase;

  const CaseDetailScreen({
    super.key,
    required this.caseRepository,
    required this.clientRepository,
    required this.financeRepository,
    required this.initialCase,
  });

  @override
  State<CaseDetailScreen> createState() => _CaseDetailScreenState();
}

class _CaseDetailScreenState extends State<CaseDetailScreen> {
  late LawCase _case;

  @override
  void initState() {
    super.initState();
    _case = widget.initialCase;
  }

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Color _statusColor(CaseStatus s) {
    switch (s) {
      case CaseStatus.active:
        return AppColors.success;
      case CaseStatus.adjourned:
        return AppColors.warning;
      case CaseStatus.closed:
        return AppColors.textSecondaryDark;
      case CaseStatus.appeal:
        return AppColors.info;
    }
  }

  Future<void> _addNote() async {
    final controller = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة ملاحظة'),
        content: TextField(controller: controller, maxLines: 4, decoration: const InputDecoration(hintText: 'اكتب ملاحظتك هنا...')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('إضافة')),
        ],
      ),
    );
    if (text != null && text.trim().isNotEmpty) {
      final updated = await widget.caseRepository.addNote(_case, text.trim());
      setState(() => _case = updated);
    }
  }

  Future<void> _addTimelineEntry() async {
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    DateTime date = DateTime.now();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة حدث للجدول الزمني'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'العنوان')),
              const SizedBox(height: 10),
              TextField(controller: descCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'تفاصيل')),
              const SizedBox(height: 10),
              InkWell(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: date,
                    firstDate: DateTime.now().subtract(const Duration(days: 3650)),
                    lastDate: DateTime.now().add(const Duration(days: 3650)),
                  );
                  if (picked != null) setDialogState(() => date = picked);
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'التاريخ'),
                  child: Text(_fmt(date)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (result == true && titleCtrl.text.trim().isNotEmpty) {
      final updated = await widget.caseRepository.addTimelineEntry(_case, titleCtrl.text.trim(), descCtrl.text.trim(), date);
      setState(() => _case = updated);
    }
  }

  String _money(double v) => v.toStringAsFixed(v.truncateToDouble() == v ? 0 : 2);

  Future<void> _addExpense() async {
    final amountCtrl = TextEditingController();
    final typeCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    DateTime date = DateTime.now();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة مصروف'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: typeCtrl, decoration: const InputDecoration(labelText: 'نوع المصروف (مثال: رسوم محكمة)')),
              const SizedBox(height: 10),
              TextField(
                controller: amountCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ'),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: date,
                    firstDate: DateTime.now().subtract(const Duration(days: 3650)),
                    lastDate: DateTime.now().add(const Duration(days: 3650)),
                  );
                  if (picked != null) setDialogState(() => date = picked);
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'التاريخ'),
                  child: Text(_fmt(date)),
                ),
              ),
              const SizedBox(height: 10),
              TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    final amount = double.tryParse(amountCtrl.text.trim());
    if (result == true && amount != null && amount > 0) {
      await widget.financeRepository.addExpense(
        caseId: _case.id,
        amount: amount,
        date: date,
        expenseType: typeCtrl.text.trim().isEmpty ? 'مصروف عام' : typeCtrl.text.trim(),
        note: noteCtrl.text.trim(),
      );
      setState(() {});
    }
  }

  String _displayName(String path) {
    final name = p.basename(path);
    return name.replaceFirst(RegExp(r'^\d+_'), '');
  }

  Future<void> _shareCase() async {
    final buffer = StringBuffer();
    buffer.writeln('📋 بيانات القضية');
    buffer.writeln('العميل: ${_case.clientName}');
    buffer.writeln('نوع القضية: ${_case.caseType}');
    buffer.writeln('الدرجة: ${_case.degree.labelAr}');
    buffer.writeln('رقم القضية: ${_case.caseNumber} لسنة ${_case.year}');
    buffer.writeln('المحكمة: ${_case.court}${_case.circuit.isNotEmpty ? ' - الدائرة ${_case.circuit}' : ''}');
    buffer.writeln('الحالة: ${_case.status.labelAr}');
    if (_case.opponentName.isNotEmpty) buffer.writeln('الخصم: ${_case.opponentName}');
    if (_case.nextHearingDate != null) buffer.writeln('الجلسة القادمة: ${_fmt(_case.nextHearingDate!)}');
    if (_case.notes.isNotEmpty) {
      buffer.writeln('\nالملاحظات:');
      for (final n in _case.notes) {
        buffer.writeln('- ${n.text}');
      }
    }
    if (_case.timeline.isNotEmpty) {
      buffer.writeln('\nسجل الإجراءات:');
      for (final t in _case.timeline) {
        buffer.writeln('- ${_fmt(t.date)}: ${t.title}${t.description.isNotEmpty ? ' (${t.description})' : ''}');
      }
    }
    await shareTextWithAttachments(
      context,
      text: buffer.toString(),
      attachmentPaths: _case.attachmentPaths,
      zipBaseName: 'قضية_${_case.caseNumber}_${_case.year}',
    );
  }

  Future<void> _shareAttachment(String path) async {
    if (!File(path).existsSync()) return;
    await Share.shareXFiles([XFile(path)], text: 'مستند من قضية ${_case.clientName} - ${_case.caseNumber}/${_case.year}');
  }

  Future<void> _addAttachment() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    final appDir = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(appDir.path, 'case_attachments'));
    if (!await dir.exists()) await dir.create(recursive: true);
    final paths = <String>[];
    for (final file in result.files) {
      if (file.path == null) continue;
      final fileName = '${DateTime.now().microsecondsSinceEpoch}_${file.name}';
      final savedPath = p.join(dir.path, fileName);
      await File(file.path!).copy(savedPath);
      paths.add(savedPath);
    }
    if (paths.isNotEmpty) {
      final updated = await widget.caseRepository.addAttachments(_case, paths);
      setState(() => _case = updated);
    }
  }

  Future<void> _deleteCase() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف القضية'),
        content: Text('هل أنت متأكد من حذف "${_case.title}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await widget.caseRepository.deleteCase(_case.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_case.title, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(icon: const Icon(Icons.share_outlined), onPressed: _shareCase),
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () async {
              final saved = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CaseFormScreen(
                    caseRepository: widget.caseRepository,
                    clientRepository: widget.clientRepository,
                    existing: _case,
                  ),
                ),
              );
              final refreshed = widget.caseRepository.getAllLocal().where((c) => c.id == _case.id).toList();
              if (refreshed.isNotEmpty) setState(() => _case = refreshed.first);
              if (saved == true && context.mounted) {
                showSuccessSnackBar(context, 'تم تسجيل القضية بنجاح');
              }
            },
          ),
          IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.danger), onPressed: _deleteCase),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(_case.clientName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: _statusColor(_case.status).withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                          child: Text(_case.status.labelAr, style: TextStyle(color: _statusColor(_case.status), fontSize: 12, fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                    const Divider(height: 24),
                    _row('المحكمة', _case.court),
                    _row('الدائرة', _case.circuit.isEmpty ? '—' : _case.circuit),
                    _row('الدرجة', _case.degree.labelAr),
                    _row('الخصم', _case.opponentName.isEmpty ? '—' : _case.opponentName),
                    _row('محامي الخصم', _case.opponentLawyer.isEmpty ? '—' : _case.opponentLawyer),
                    _row('الجلسة القادمة', _case.nextHearingDate == null ? 'غير محدد' : _fmt(_case.nextHearingDate!)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            _sectionHeader('الجدول الزمني', Icons.timeline_outlined, _addTimelineEntry),
            if (_case.timeline.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد أحداث بعد', style: TextStyle(color: AppColors.textSecondaryDark)))
            else
              ...(_case.timeline.toList()..sort((a, b) => b.date.compareTo(a.date))).map((e) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.circle, size: 10, color: AppColors.gold),
                      title: Text(e.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: e.description.isEmpty ? Text(_fmt(e.date)) : Text('${e.description}\n${_fmt(e.date)}'),
                      isThreeLine: e.description.isNotEmpty,
                    ),
                  )),
            const SizedBox(height: 20),
            _sectionHeader('الملاحظات', Icons.note_outlined, _addNote),
            if (_case.notes.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد ملاحظات بعد', style: TextStyle(color: AppColors.textSecondaryDark)))
            else
              ...(_case.notes.toList()..sort((a, b) => b.createdAt.compareTo(a.createdAt))).map((n) => Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(n.text),
                          const SizedBox(height: 6),
                          Text(_fmt(n.createdAt), style: const TextStyle(fontSize: 11, color: AppColors.textSecondaryDark)),
                        ],
                      ),
                    ),
                  )),
            const SizedBox(height: 20),
            _sectionHeader('مصاريف القضية', Icons.receipt_long_outlined, _addExpense),
            Builder(builder: (context) {
              final expenses = widget.financeRepository.getExpensesForCase(_case.id);
              final total = widget.financeRepository.totalExpensesForCase(_case.id);
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: _row('إجمالي المصروف على القضية', '${_money(total)} جنيه'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (expenses.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('لا توجد مصاريف مسجّلة بعد', style: TextStyle(color: AppColors.textSecondaryDark)),
                    )
                  else
                    ...expenses.map((ex) => Card(
                          child: ListTile(
                            leading: const Icon(Icons.arrow_upward, color: AppColors.danger),
                            title: Text('${_money(ex.amount)} جنيه — ${ex.expenseType}'),
                            subtitle: Text(ex.note.isEmpty ? _fmt(ex.date) : '${ex.note}\n${_fmt(ex.date)}'),
                            isThreeLine: ex.note.isNotEmpty,
                          ),
                        )),
                ],
              );
            }),
            const SizedBox(height: 20),
            _sectionHeader('المستندات (${_case.attachmentPaths.length})', Icons.attach_file, _addAttachment),
            if (_case.attachmentPaths.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد مستندات بعد', style: TextStyle(color: AppColors.textSecondaryDark)))
            else
              ..._case.attachmentPaths.map((path) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.gold),
                      title: Text(_displayName(path), overflow: TextOverflow.ellipsis),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(icon: const Icon(Icons.share_outlined, size: 18), onPressed: () => _shareAttachment(path)),
                          const Icon(Icons.open_in_new, size: 18),
                        ],
                      ),
                      onTap: () {
                        if (File(path).existsSync()) OpenFilex.open(path);
                      },
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondaryDark)),
          const Spacer(),
          Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title, IconData addIcon, VoidCallback onAdd) {
    return Row(
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
        const Spacer(),
        IconButton(icon: Icon(addIcon, size: 20), onPressed: onAdd),
      ],
    );
  }
}
