import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/share_helpers.dart';
import '../../../core/utils/ui_feedback.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../data/repositories/finance_repository.dart';
import '../../../data/repositories/registry_repository.dart';
import '../../../domain/entities/client.dart';
import 'client_detail_screen.dart';
import 'client_form_screen.dart';

class ClientsListScreen extends StatefulWidget {
  final ClientRepository repository;
  final CaseRepository caseRepository;
  final FinanceRepository financeRepository;
  final OpponentRepository opponentRepository;
  const ClientsListScreen({
    super.key,
    required this.repository,
    required this.caseRepository,
    required this.financeRepository,
    required this.opponentRepository,
  });

  @override
  State<ClientsListScreen> createState() => _ClientsListScreenState();
}

class _ClientsListScreenState extends State<ClientsListScreen> {
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    widget.repository.startRemoteSync();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    widget.repository.stopRemoteSync();
    super.dispose();
  }

  Future<void> _shareClientQuick(Client client) async {
    final buffer = StringBuffer();
    buffer.writeln('👤 بيانات العميل');
    buffer.writeln('الاسم: ${client.fullName}');
    if (client.phone.isNotEmpty) buffer.writeln('الهاتف: ${client.phone}');
    if (client.nationalId.isNotEmpty) buffer.writeln('الرقم القومي: ${client.nationalId}');
    if (client.address.isNotEmpty) buffer.writeln('العنوان: ${client.address}');
    if (client.poaNumber.isNotEmpty) buffer.writeln('رقم التوكيل: ${client.poaNumber}');
    buffer.writeln('نوع التوكيل: ${client.poaType.labelAr}');
    buffer.writeln('نوع التوثيق: ${client.notarization.labelAr}');
    if (client.notes.isNotEmpty) buffer.writeln('\nملاحظات:\n${client.notes}');
    await shareTextWithAttachments(
      context,
      text: buffer.toString(),
      attachmentPaths: client.attachmentPaths,
      zipBaseName: 'عميل_${client.fullName}',
    );
  }

  Future<void> _confirmDelete(Client client) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العميل'),
        content: Text('هل تريد حذف "${client.fullName}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await widget.repository.deleteClient(client.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('العملاء'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  hintText: 'ابحث بالاسم، الرقم القومي أو الهاتف...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() => _query = '');
                          },
                        ),
                ),
              ),
            ),
            Expanded(
              child: StreamBuilder<List<Client>>(
                stream: widget.repository.watchAll(),
                builder: (context, snapshot) {
                  final all = snapshot.data ?? widget.repository.getAllLocal();
                  final clients = _query.isEmpty ? all : widget.repository.search(_query);

                  if (clients.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.people_outline, size: 64, color: AppColors.textSecondaryDark),
                          const SizedBox(height: 12),
                          Text(
                            _query.isEmpty ? 'لا يوجد عملاء بعد\nاضغط + لإضافة عميل جديد' : 'لا توجد نتائج مطابقة',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: AppColors.textSecondaryDark),
                          ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.only(bottom: 90),
                    itemCount: clients.length,
                    itemBuilder: (context, index) {
                      final client = clients[index];
                      return Slidable(
                        startActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              onPressed: (_) => _shareClientQuick(client),
                              backgroundColor: AppColors.gold,
                              foregroundColor: AppColors.black,
                              icon: Icons.share_outlined,
                              label: 'مشاركة',
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ],
                        ),
                        endActionPane: ActionPane(
                          motion: const DrawerMotion(),
                          extentRatio: 0.25,
                          children: [
                            SlidableAction(
                              onPressed: (_) => _confirmDelete(client),
                              backgroundColor: AppColors.danger,
                              foregroundColor: Colors.white,
                              icon: Icons.delete_outline,
                              label: 'حذف',
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ],
                        ),
                        child: Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: AppColors.gold.withOpacity(0.15),
                              child: Text(
                                client.fullName.isNotEmpty ? client.fullName.substring(0, 1) : '?',
                                style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w700),
                              ),
                            ),
                            title: Text(client.fullName, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(client.phone.isEmpty ? 'لا يوجد رقم هاتف' : client.phone, textDirection: TextDirection.ltr),
                            trailing: !client.isSynced
                                ? const Icon(Icons.cloud_off_outlined, color: AppColors.warning, size: 18)
                                : const Icon(Icons.chevron_left),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ClientDetailScreen(
                                  repository: widget.repository,
                                  caseRepository: widget.caseRepository,
                                  financeRepository: widget.financeRepository,
                                  opponentRepository: widget.opponentRepository,
                                  client: client,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final saved = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ClientFormScreen(repository: widget.repository)),
          );
          if (saved == true && context.mounted) {
            showSuccessSnackBar(context, 'تم حفظ بيانات العميل بنجاح');
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('عميل جديد'),
      ),
    );
  }
}
