import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../domain/entities/client.dart';

class ClientFormScreen extends StatefulWidget {
  final ClientRepository repository;
  final Client? existing;
  const ClientFormScreen({super.key, required this.repository, this.existing});

  @override
  State<ClientFormScreen> createState() => _ClientFormScreenState();
}

class _ClientFormScreenState extends State<ClientFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameCtrl;
  late final TextEditingController _nationalIdCtrl;
  late final TextEditingController _phoneCtrl;
  late final TextEditingController _whatsappCtrl;
  late final TextEditingController _addressCtrl;
  late final TextEditingController _notesCtrl;
  late final TextEditingController _totalFeesCtrl;
  late final TextEditingController _poaNumberCtrl;
  List<String> _attachments = [];
  DateTime? _poaDate;
  PoaType _poaType = PoaType.general;
  NotarizationType _notarization = NotarizationType.customary;
  bool _saving = false;

  bool get _isEditing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final c = widget.existing;
    _nameCtrl = TextEditingController(text: c?.fullName ?? '');
    _nationalIdCtrl = TextEditingController(text: c?.nationalId ?? '');
    _phoneCtrl = TextEditingController(text: c?.phone ?? '');
    _whatsappCtrl = TextEditingController(text: c?.whatsapp ?? '');
    _addressCtrl = TextEditingController(text: c?.address ?? '');
    _notesCtrl = TextEditingController(text: c?.notes ?? '');
    _totalFeesCtrl = TextEditingController(text: c != null && c.totalFees > 0 ? c.totalFees.toString() : '');
    _poaNumberCtrl = TextEditingController(text: c?.poaNumber ?? '');
    _poaDate = c?.poaDate;
    _poaType = c?.poaType ?? PoaType.general;
    _notarization = c?.notarization ?? NotarizationType.customary;
    _attachments = List.from(c?.attachmentPaths ?? []);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _nationalIdCtrl.dispose();
    _phoneCtrl.dispose();
    _whatsappCtrl.dispose();
    _addressCtrl.dispose();
    _notesCtrl.dispose();
    _totalFeesCtrl.dispose();
    _poaNumberCtrl.dispose();
    super.dispose();
  }

  String _fmtDate(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickAttachment() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    final appDir = await getApplicationDocumentsDirectory();
    final clientsDir = Directory(p.join(appDir.path, 'clients_attachments'));
    if (!await clientsDir.exists()) await clientsDir.create(recursive: true);

    for (final file in result.files) {
      if (file.path == null) continue;
      final fileName = '${DateTime.now().microsecondsSinceEpoch}_${file.name}';
      final savedPath = p.join(clientsDir.path, fileName);
      await File(file.path!).copy(savedPath);
      setState(() => _attachments.add(savedPath));
    }
  }

  void _removeAttachment(String path) {
    setState(() => _attachments.remove(path));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final fees = double.tryParse(_totalFeesCtrl.text.trim()) ?? 0;
      if (_isEditing) {
        final updated = widget.existing!.copyWith(
          fullName: _nameCtrl.text.trim(),
          nationalId: _nationalIdCtrl.text.trim(),
          phone: _phoneCtrl.text.trim(),
          whatsapp: _whatsappCtrl.text.trim(),
          address: _addressCtrl.text.trim(),
          notes: _notesCtrl.text.trim(),
          attachmentPaths: _attachments,
          totalFees: fees,
          poaNumber: _poaNumberCtrl.text.trim(),
          poaDate: _poaDate,
          clearPoaDate: _poaDate == null,
          poaType: _poaType,
          notarization: _notarization,
        );
        await widget.repository.updateClient(updated);
      } else {
        await widget.repository.addClient(
          fullName: _nameCtrl.text.trim(),
          nationalId: _nationalIdCtrl.text.trim(),
          phone: _phoneCtrl.text.trim(),
          whatsapp: _whatsappCtrl.text.trim(),
          address: _addressCtrl.text.trim(),
          notes: _notesCtrl.text.trim(),
          attachmentPaths: _attachments,
          totalFees: fees,
          poaNumber: _poaNumberCtrl.text.trim(),
          poaDate: _poaDate,
          poaType: _poaType,
          notarization: _notarization,
        );
      }
      if (mounted) Navigator.of(context).pop();
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'تعديل بيانات العميل' : 'إضافة عميل جديد')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(labelText: 'الاسم الكامل *', prefixIcon: Icon(Icons.person_outline)),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسم العميل' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _nationalIdCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'الرقم القومي', prefixIcon: Icon(Icons.badge_outlined)),
                  validator: (v) {
                    if (v == null || v.isEmpty) return null;
                    if (v.length != 14) return 'الرقم القومي يجب أن يكون 14 رقمًا';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'رقم الهاتف', prefixIcon: Icon(Icons.phone_outlined)),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _whatsappCtrl,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'رقم واتساب', prefixIcon: Icon(Icons.chat_outlined)),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _addressCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'العنوان', prefixIcon: Icon(Icons.location_on_outlined)),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _notesCtrl,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'ملاحظات', prefixIcon: Icon(Icons.note_outlined)),
                ),
                const SizedBox(height: 24),
                const Text('بيانات التوكيل', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _poaNumberCtrl,
                  decoration: const InputDecoration(labelText: 'رقم التوكيل', prefixIcon: Icon(Icons.article_outlined)),
                ),
                const SizedBox(height: 14),
                InkWell(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _poaDate ?? DateTime.now(),
                      firstDate: DateTime.now().subtract(const Duration(days: 3650)),
                      lastDate: DateTime.now().add(const Duration(days: 3650)),
                    );
                    if (picked != null) setState(() => _poaDate = picked);
                  },
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'تاريخ التوكيل', prefixIcon: Icon(Icons.calendar_today_outlined)),
                    child: Text(_poaDate == null ? 'غير محدد' : _fmtDate(_poaDate!)),
                  ),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<PoaType>(
                  value: _poaType,
                  decoration: const InputDecoration(labelText: 'نوع التوكيل', prefixIcon: Icon(Icons.category_outlined)),
                  items: PoaType.values.map((t) => DropdownMenuItem(value: t, child: Text(t.labelAr))).toList(),
                  onChanged: (v) => setState(() => _poaType = v ?? _poaType),
                ),
                const SizedBox(height: 14),
                DropdownButtonFormField<NotarizationType>(
                  value: _notarization,
                  decoration: const InputDecoration(labelText: 'نوع التوثيق', prefixIcon: Icon(Icons.verified_outlined)),
                  items: NotarizationType.values.map((t) => DropdownMenuItem(value: t, child: Text(t.labelAr))).toList(),
                  onChanged: (v) => setState(() => _notarization = v ?? _notarization),
                ),
                const SizedBox(height: 24),
                const Text('الحساب المالي', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _totalFeesCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'إجمالي الأتعاب المتفق عليها', prefixIcon: Icon(Icons.payments_outlined)),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    const Text('المرفقات', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: _pickAttachment,
                      icon: const Icon(Icons.attach_file),
                      label: const Text('إضافة ملف'),
                    ),
                  ],
                ),
                if (_attachments.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('لا توجد مرفقات بعد', style: TextStyle(color: AppColors.textSecondaryDark)),
                  )
                else
                  ..._attachments.map((path) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.gold),
                          title: Text(p.basename(path), overflow: TextOverflow.ellipsis),
                          trailing: IconButton(
                            icon: const Icon(Icons.close, color: AppColors.danger),
                            onPressed: () => _removeAttachment(path),
                          ),
                        ),
                      )),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: AppColors.black))
                      : Text(_isEditing ? 'حفظ التعديلات' : 'إضافة العميل'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
