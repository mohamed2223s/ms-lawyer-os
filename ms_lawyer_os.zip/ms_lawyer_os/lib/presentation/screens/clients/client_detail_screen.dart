import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../data/repositories/finance_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/client.dart';
import '../../../domain/entities/finance.dart';
import '../cases/case_detail_screen.dart';
import '../cases/case_form_screen.dart';
import 'client_form_screen.dart';

class ClientDetailScreen extends StatefulWidget {
  final ClientRepository repository;
  final CaseRepository caseRepository;
  final FinanceRepository financeRepository;
  final Client client;
  const ClientDetailScreen({
    super.key,
    required this.repository,
    required this.caseRepository,
    required this.financeRepository,
    required this.client,
  });

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen> {
  late Client _client;

  @override
  void initState() {
    super.initState();
    _client = widget.client;
  }

  Future<void> _call(String phone) async {
    if (phone.isEmpty) return;
    await launchUrl(Uri.parse('tel:$phone'));
  }

  Future<void> _whatsapp(String number) async {
    if (number.isEmpty) return;
    final clean = number.replaceAll(RegExp(r'[^0-9]'), '');
    await launchUrl(Uri.parse('https://wa.me/$clean'), mode: LaunchMode.externalApplication);
  }

  Future<void> _deleteClient(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العميل'),
        content: Text('هل أنت متأكد من حذف "${_client.fullName}"؟ لا يمكن التراجع عن هذا الإجراء.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await widget.repository.deleteClient(_client.id);
      if (context.mounted) Navigator.pop(context);
    }
  }

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  String _money(double v) => v.toStringAsFixed(v.truncateToDouble() == v ? 0 : 2);

  Future<void> _shareFinanceStatement() async {
    final payments = widget.financeRepository.getPaymentsForClient(_client.id);
    final paid = widget.financeRepository.totalPaidByClient(_client.id);
    final remaining = _client.totalFees - paid;
    final buffer = StringBuffer();
    buffer.writeln('💰 كشف حساب - ${_client.fullName}');
    buffer.writeln('إجمالي الأتعاب: ${_money(_client.totalFees)} جنيه');
    buffer.writeln('المدفوع: ${_money(paid)} جنيه');
    buffer.writeln('المتبقي: ${_money(remaining)} جنيه');
    if (payments.isNotEmpty) {
      buffer.writeln('\nسجل الدفعات:');
      for (final pmt in payments) {
        buffer.writeln('- ${_fmt(pmt.date)}: ${_money(pmt.amount)} جنيه (${pmt.method.labelAr})${pmt.note.isNotEmpty ? ' - ${pmt.note}' : ''}');
      }
    }
    if (_client.attachmentPaths.isEmpty) {
      await Share.share(buffer.toString());
      return;
    }

    final selected = <String>{};
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('اختر المرفقات اللي عايز تشاركها (اختياري)'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView(
              shrinkWrap: true,
              children: _client.attachmentPaths
                  .map((path) => CheckboxListTile(
                        value: selected.contains(path),
                        title: Text(p.basename(path), overflow: TextOverflow.ellipsis),
                        onChanged: (v) => setDialogState(() {
                          if (v == true) {
                            selected.add(path);
                          } else {
                            selected.remove(path);
                          }
                        }),
                      ))
                  .toList(),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('مشاركة')),
          ],
        ),
      ),
    );
    if (confirm != true) return;

    if (selected.isEmpty) {
      await Share.share(buffer.toString());
    } else {
      final files = selected.where((path) => File(path).existsSync()).map((path) => XFile(path)).toList();
      await Share.shareXFiles(files, text: buffer.toString());
    }
  }

  Future<void> _addPayment() async {
    final amountCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    DateTime date = DateTime.now();
    PaymentMethod method = PaymentMethod.cash;
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('إضافة دفعة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: amountCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ'),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: ctx,
                    initialDate: date,
                    firstDate: DateTime.now().subtract(const Duration(days: 3650)),
                    lastDate: DateTime.now().add(const Duration(days: 3650)),
                  );
                  if (picked != null) setDialogState(() => date = picked);
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'التاريخ'),
                  child: Text(_fmt(date)),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<PaymentMethod>(
                value: method,
                decoration: const InputDecoration(labelText: 'طريقة الدفع'),
                items: PaymentMethod.values.map((m) => DropdownMenuItem(value: m, child: Text(m.labelAr))).toList(),
                onChanged: (v) => setDialogState(() => method = v ?? method),
              ),
              const SizedBox(height: 10),
              TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    final amount = double.tryParse(amountCtrl.text.trim());
    if (result == true && amount != null && amount > 0) {
      await widget.financeRepository.addPayment(
        clientId: _client.id,
        amount: amount,
        date: date,
        method: method,
        note: noteCtrl.text.trim(),
      );
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final clientCases = widget.caseRepository.getByClient(_client.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(_client.fullName),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ClientFormScreen(repository: widget.repository, existing: _client)),
              );
              final refreshed = widget.repository.getById(_client.id);
              if (refreshed != null) setState(() => _client = refreshed);
            },
          ),
          IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.danger), onPressed: () => _deleteClient(context)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _infoRow(Icons.badge_outlined, 'الرقم القومي', _client.nationalId.isEmpty ? '—' : _client.nationalId),
                    const Divider(),
                    _infoRow(Icons.phone_outlined, 'الهاتف', _client.phone.isEmpty ? '—' : _client.phone),
                    const Divider(),
                    _infoRow(Icons.chat_outlined, 'واتساب', _client.whatsapp.isEmpty ? '—' : _client.whatsapp),
                    const Divider(),
                    _infoRow(Icons.location_on_outlined, 'العنوان', _client.address.isEmpty ? '—' : _client.address),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _call(_client.phone),
                    icon: const Icon(Icons.call_outlined),
                    label: const Text('اتصال'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _whatsapp(_client.whatsapp.isEmpty ? _client.phone : _client.whatsapp),
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: const Text('واتساب'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('بيانات التوكيل', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _infoRow(Icons.article_outlined, 'رقم التوكيل', _client.poaNumber.isEmpty ? '—' : _client.poaNumber),
                    const Divider(),
                    _infoRow(Icons.calendar_today_outlined, 'تاريخ التوكيل', _client.poaDate == null ? '—' : _fmt(_client.poaDate!)),
                    const Divider(),
                    _infoRow(Icons.category_outlined, 'نوع التوكيل', _client.poaType.labelAr),
                    const Divider(),
                    _infoRow(Icons.verified_outlined, 'نوع التوثيق', _client.notarization.labelAr),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Text('الحساب المالي', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                const Spacer(),
                IconButton(icon: const Icon(Icons.share_outlined, size: 20), onPressed: _shareFinanceStatement),
                IconButton(icon: const Icon(Icons.add_circle_outline, size: 20), onPressed: _addPayment),
              ],
            ),
            const SizedBox(height: 8),
            Builder(builder: (context) {
              final payments = widget.financeRepository.getPaymentsForClient(_client.id);
              final paid = widget.financeRepository.totalPaidByClient(_client.id);
              final remaining = _client.totalFees - paid;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _infoRow(Icons.payments_outlined, 'إجمالي الأتعاب', '${_money(_client.totalFees)} جنيه'),
                          const Divider(),
                          _infoRow(Icons.check_circle_outline, 'المدفوع', '${_money(paid)} جنيه'),
                          const Divider(),
                          _infoRow(
                            Icons.hourglass_bottom_outlined,
                            'المتبقي',
                            '${_money(remaining)} جنيه',
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (payments.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('لا توجد دفعات مسجّلة بعد', style: TextStyle(color: AppColors.textSecondaryDark)),
                    )
                  else
                    ...payments.map((pmt) => Card(
                          child: ListTile(
                            leading: const Icon(Icons.arrow_downward, color: AppColors.success),
                            title: Text('${_money(pmt.amount)} جنيه — ${pmt.method.labelAr}'),
                            subtitle: Text(pmt.note.isEmpty ? _fmt(pmt.date) : '${pmt.note}\n${_fmt(pmt.date)}'),
                            isThreeLine: pmt.note.isNotEmpty,
                          ),
                        )),
                ],
              );
            }),
            const SizedBox(height: 20),
            if (_client.notes.isNotEmpty) ...[
              const Text('ملاحظات', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
              const SizedBox(height: 8),
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(_client.notes))),
              const SizedBox(height: 20),
            ],
            Row(
              children: [
                Text('قضايا العميل (${clientCases.length})', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline, size: 20),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CaseFormScreen(
                        caseRepository: widget.caseRepository,
                        clientRepository: widget.repository,
                        preselectedClient: _client,
                      ),
                    ),
                  ).then((_) => setState(() {})),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (clientCases.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد قضايا مسجّلة لهذا العميل', style: TextStyle(color: AppColors.textSecondaryDark)))
            else
              ...clientCases.map((c) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.gavel_outlined, color: AppColors.gold),
                      title: Text(c.title, overflow: TextOverflow.ellipsis),
                      subtitle: Text(c.court),
                      trailing: c.nextHearingDate != null ? Text(_fmt(c.nextHearingDate!), style: const TextStyle(fontSize: 12)) : null,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CaseDetailScreen(
                            caseRepository: widget.caseRepository,
                            clientRepository: widget.repository,
                            financeRepository: widget.financeRepository,
                            initialCase: c,
                          ),
                        ),
                      ).then((_) => setState(() {})),
                    ),
                  )),
            const SizedBox(height: 20),
            Row(
              children: [
                Text('المرفقات (${_client.attachmentPaths.length})', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
              ],
            ),
            const SizedBox(height: 8),
            if (_client.attachmentPaths.isEmpty)
              const Text('لا توجد مرفقات', style: TextStyle(color: AppColors.textSecondaryDark))
            else
              ..._client.attachmentPaths.map((path) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.gold),
                      title: Text(p.basename(path), overflow: TextOverflow.ellipsis),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.share_outlined, size: 18),
                            onPressed: () {
                              if (File(path).existsSync()) {
                                Share.shareXFiles([XFile(path)], text: 'مستند خاص بـ ${_client.fullName}');
                              }
                            },
                          ),
                          const Icon(Icons.open_in_new, size: 18),
                        ],
                      ),
                      onTap: () {
                        if (File(path).existsSync()) OpenFilex.open(path);
                      },
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: AppColors.gold, size: 20),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(color: AppColors.textSecondaryDark)),
        const Spacer(),
        Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600))),
      ],
    );
  }
}
