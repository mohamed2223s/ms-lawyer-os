import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/case_repository.dart';
import '../../../data/repositories/client_repository.dart';
import '../../../domain/entities/case.dart';
import '../../../domain/entities/client.dart';
import '../cases/case_detail_screen.dart';
import '../cases/case_form_screen.dart';
import 'client_form_screen.dart';

class ClientDetailScreen extends StatefulWidget {
  final ClientRepository repository;
  final CaseRepository caseRepository;
  final Client client;
  const ClientDetailScreen({super.key, required this.repository, required this.caseRepository, required this.client});

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen> {
  late Client _client;

  @override
  void initState() {
    super.initState();
    _client = widget.client;
  }

  Future<void> _call(String phone) async {
    if (phone.isEmpty) return;
    await launchUrl(Uri.parse('tel:$phone'));
  }

  Future<void> _whatsapp(String number) async {
    if (number.isEmpty) return;
    final clean = number.replaceAll(RegExp(r'[^0-9]'), '');
    await launchUrl(Uri.parse('https://wa.me/$clean'), mode: LaunchMode.externalApplication);
  }

  Future<void> _deleteClient(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العميل'),
        content: Text('هل أنت متأكد من حذف "${_client.fullName}"؟ لا يمكن التراجع عن هذا الإجراء.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await widget.repository.deleteClient(_client.id);
      if (context.mounted) Navigator.pop(context);
    }
  }

  String _fmt(DateTime d) => '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final clientCases = widget.caseRepository.getByClient(_client.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(_client.fullName),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ClientFormScreen(repository: widget.repository, existing: _client)),
              );
              final refreshed = widget.repository.getById(_client.id);
              if (refreshed != null) setState(() => _client = refreshed);
            },
          ),
          IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.danger), onPressed: () => _deleteClient(context)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _infoRow(Icons.badge_outlined, 'الرقم القومي', _client.nationalId.isEmpty ? '—' : _client.nationalId),
                    const Divider(),
                    _infoRow(Icons.phone_outlined, 'الهاتف', _client.phone.isEmpty ? '—' : _client.phone),
                    const Divider(),
                    _infoRow(Icons.chat_outlined, 'واتساب', _client.whatsapp.isEmpty ? '—' : _client.whatsapp),
                    const Divider(),
                    _infoRow(Icons.location_on_outlined, 'العنوان', _client.address.isEmpty ? '—' : _client.address),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _call(_client.phone),
                    icon: const Icon(Icons.call_outlined),
                    label: const Text('اتصال'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _whatsapp(_client.whatsapp.isEmpty ? _client.phone : _client.whatsapp),
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: const Text('واتساب'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (_client.notes.isNotEmpty) ...[
              const Text('ملاحظات', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
              const SizedBox(height: 8),
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(_client.notes))),
              const SizedBox(height: 20),
            ],
            Row(
              children: [
                Text('قضايا العميل (${clientCases.length})', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline, size: 20),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CaseFormScreen(
                        caseRepository: widget.caseRepository,
                        clientRepository: widget.repository,
                        preselectedClient: _client,
                      ),
                    ),
                  ).then((_) => setState(() {})),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (clientCases.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('لا توجد قضايا مسجّلة لهذا العميل', style: TextStyle(color: AppColors.textSecondaryDark)))
            else
              ...clientCases.map((c) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.gavel_outlined, color: AppColors.gold),
                      title: Text(c.title, overflow: TextOverflow.ellipsis),
                      subtitle: Text(c.court),
                      trailing: c.nextHearingDate != null ? Text(_fmt(c.nextHearingDate!), style: const TextStyle(fontSize: 12)) : null,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CaseDetailScreen(
                            caseRepository: widget.caseRepository,
                            clientRepository: widget.repository,
                            initialCase: c,
                          ),
                        ),
                      ).then((_) => setState(() {})),
                    ),
                  )),
            const SizedBox(height: 20),
            Row(
              children: [
                Text('المرفقات (${_client.attachmentPaths.length})', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold)),
              ],
            ),
            const SizedBox(height: 8),
            if (_client.attachmentPaths.isEmpty)
              const Text('لا توجد مرفقات', style: TextStyle(color: AppColors.textSecondaryDark))
            else
              ..._client.attachmentPaths.map((path) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.gold),
                      title: Text(p.basename(path), overflow: TextOverflow.ellipsis),
                      trailing: const Icon(Icons.open_in_new, size: 18),
                      onTap: () {
                        if (File(path).existsSync()) OpenFilex.open(path);
                      },
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: AppColors.gold, size: 20),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(color: AppColors.textSecondaryDark)),
        const Spacer(),
        Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600))),
      ],
    );
  }
}
