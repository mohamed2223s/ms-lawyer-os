import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/security/auth_lock_service.dart';
import '../../../core/services/sync_queue_service.dart';
import '../../../data/repositories/auth_repository.dart';

class SettingsScreen extends StatefulWidget {
  final OfficeSession session;
  const SettingsScreen({super.key, required this.session});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _biometricEnabled = false;
  bool _biometricAvailable = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final available = await AuthLockService.instance.isBiometricAvailable();
    final enabled = await AuthLockService.instance.isBiometricEnabled();
    setState(() {
      _biometricAvailable = available;
      _biometricEnabled = enabled;
    });
  }

  Future<void> _toggleBiometric(bool value) async {
    if (value) {
      final ok = await AuthLockService.instance.authenticateWithBiometrics();
      if (!ok) return;
    }
    await AuthLockService.instance.setBiometricEnabled(value);
    setState(() => _biometricEnabled = value);
  }

  Future<void> _changePin() async {
    final controller = TextEditingController();
    final newPin = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تغيير رمز PIN'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          maxLength: 6,
          obscureText: true,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(hintText: 'أدخل رمز جديد من 6 أرقام'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('حفظ')),
        ],
      ),
    );
    if (newPin != null && newPin.length == 6) {
      await AuthLockService.instance.setPin(newPin);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تحديث رمز PIN بنجاح')));
      }
    } else if (newPin != null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يجب أن يتكون الرمز من 6 أرقام')));
      }
    }
  }

  Future<void> _signOut() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل أنت متأكد من رغبتك في تسجيل الخروج؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تسجيل الخروج')),
        ],
      ),
    );
    if (confirm == true) {
      await AuthRepository.instance.signOut();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const CircleAvatar(backgroundColor: AppColors.gold, child: Icon(Icons.person, color: AppColors.black)),
                title: Text(widget.session.displayName),
                subtitle: Text(widget.session.email, textDirection: TextDirection.ltr),
              ),
            ),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerRight, child: Text('الأمان', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold))),
            const SizedBox(height: 8),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.pin_outlined, color: AppColors.gold),
                    title: const Text('تغيير رمز PIN'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: _changePin,
                  ),
                  if (_biometricAvailable) ...[
                    const Divider(height: 1),
                    SwitchListTile(
                      secondary: const Icon(Icons.fingerprint, color: AppColors.gold),
                      title: const Text('الدخول بالبصمة'),
                      value: _biometricEnabled,
                      onChanged: _toggleBiometric,
                      activeColor: AppColors.gold,
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Align(alignment: Alignment.centerRight, child: Text('البيانات والمزامنة', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.gold))),
            const SizedBox(height: 8),
            Card(
              child: ListTile(
                leading: const Icon(Icons.sync, color: AppColors.gold),
                title: const Text('مزامنة الآن'),
                subtitle: Text('${SyncQueueService.instance.pendingCount} عنصر بانتظار المزامنة'),
                trailing: const Icon(Icons.chevron_left),
                onTap: () async {
                  await SyncQueueService.instance.processQueue();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت محاولة المزامنة')));
                  }
                },
              ),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: _signOut,
              icon: const Icon(Icons.logout, color: AppColors.danger),
              label: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.danger)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.danger)),
            ),
          ],
        ),
      ),
    );
  }
}
