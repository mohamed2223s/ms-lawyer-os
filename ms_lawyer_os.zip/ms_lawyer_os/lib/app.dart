import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/providers/session_providers.dart';
import 'core/theme/app_theme.dart';
import 'core/widgets/activity_detector.dart';
import 'data/repositories/auth_repository.dart';
import 'presentation/screens/app_shell.dart';
import 'presentation/screens/auth/login_screen.dart';
import 'presentation/screens/auth/pin_lock_screen.dart';
import 'presentation/screens/splash/splash_screen.dart';

class MsLawyerApp extends ConsumerWidget {
  const MsLawyerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'MS Lawyer OS',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark,
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const _RootGate(),
    );
  }
}

class _RootGate extends ConsumerWidget {
  const _RootGate();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return authState.when(
      loading: () => const SplashScreen(),
      error: (_, __) => const LoginScreen(),
      data: (user) {
        if (user == null) return const LoginScreen();

        final sessionAsync = ref.watch(officeSessionProvider);
        return sessionAsync.when(
          loading: () => const SplashScreen(),
          error: (_, __) => const LoginScreen(),
          data: (session) {
            if (session == null) return const SplashScreen();
            return SecurityGate(
              child: _LockAwareShell(session: session),
            );
          },
        );
      },
    );
  }
}

/// يلف الواجهة الرئيسية بمراقب النشاط: عند الخمول لفترة طويلة يُعاد
/// عرض شاشة قفل PIN فوق التطبيق حتى يُدخل المستخدم الرمز مجددًا.
class _LockAwareShell extends StatefulWidget {
  final OfficeSession session;
  const _LockAwareShell({required this.session});

  @override
  State<_LockAwareShell> createState() => _LockAwareShellState();
}

class _LockAwareShellState extends State<_LockAwareShell> {
  bool _locked = false;

  @override
  Widget build(BuildContext context) {
    return ActivityDetector(
      onLock: () {
        if (!_locked) setState(() => _locked = true);
      },
      child: _locked
          ? PinLockScreen(onUnlocked: () => setState(() => _locked = false))
          : AppShell(session: widget.session),
    );
  }
}
