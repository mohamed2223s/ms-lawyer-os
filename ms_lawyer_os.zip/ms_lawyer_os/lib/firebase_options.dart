// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('نسخة الويب غير مفعّلة في هذا المشروع - التطبيق مخصص لأندرويد.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        throw UnsupportedError('نسخة iOS تحتاج إعداد منفصل عبر flutterfire configure.');
      default:
        throw UnsupportedError('هذه المنصة غير مدعومة حاليًا.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDplUfIL2NmgWM9M-nuAEsfmQZcFXZx3h0',
    appId: '1:212704239688:android:c012c0522667c7d2e8b87d',
    messagingSenderId: '212704239688',
    projectId: 'flutter-ai-playground-247fe',
    storageBucket: 'flutter-ai-playground-247fe.firebasestorage.app',
  );
}