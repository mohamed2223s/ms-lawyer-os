/// أسماء المجموعات (Collections) في Firestore
/// كل بيانات المكتب مخزنة تحت: offices/{officeId}/...
/// هذا يضمن عزل بيانات كل مكتب محاماة وسهولة تطبيق قواعد الأمان.
class FirestorePaths {
  FirestorePaths._();

  static const String offices = 'offices';
  static const String users = 'users';

  // Sub-collections under offices/{officeId}/
  static const String clients = 'clients';
  static const String cases = 'cases';
  static const String hearings = 'hearings';
  static const String documents = 'documents';
  static const String tasks = 'tasks';
  static const String financeFees = 'finance_fees';
  static const String financeExpenses = 'finance_expenses';
  static const String financePayments = 'finance_payments';
  static const String notifications = 'notifications';
  static const String caseNotes = 'case_notes';
  static const String caseTimeline = 'case_timeline';
  static const String backups = 'backups';
  static const String activityLog = 'activity_log';
  static const String opponents = 'opponents';
  static const String vault = 'vault';

  static String officeDoc(String officeId) => '$offices/$officeId';
  static String clientsCol(String officeId) => '$offices/$officeId/$clients';
  static String casesCol(String officeId) => '$offices/$officeId/$cases';
  static String hearingsCol(String officeId) => '$offices/$officeId/$hearings';
  static String documentsCol(String officeId) => '$offices/$officeId/$documents';
  static String tasksCol(String officeId) => '$offices/$officeId/$tasks';
  static String financeFeesCol(String officeId) => '$offices/$officeId/$financeFees';
  static String financeExpensesCol(String officeId) => '$offices/$officeId/$financeExpenses';
  static String financePaymentsCol(String officeId) => '$offices/$officeId/$financePayments';
  static String notificationsCol(String officeId) => '$offices/$officeId/$notifications';
  static String activityLogCol(String officeId) => '$offices/$officeId/$activityLog';
  static String opponentsCol(String officeId) => '$offices/$officeId/$opponents';
  static String vaultCol(String officeId) => '$offices/$officeId/$vault';
}
