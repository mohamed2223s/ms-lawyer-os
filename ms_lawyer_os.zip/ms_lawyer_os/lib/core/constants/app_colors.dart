import 'package:flutter/material.dart';

/// لوحة ألوان تطبيق MS Lawyer OS - أسود / ذهبي / أبيض
class AppColors {
  AppColors._();

  // الأساسي
  static const Color black = Color(0xFF0A0A0A);
  static const Color richBlack = Color(0xFF121212);
  static const Color charcoal = Color(0xFF1E1E1E);
  static const Color surfaceDark = Color(0xFF232323);

  // الذهبي
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFE9CE6B);
  static const Color goldDark = Color(0xFFB08D1E);

  // الأبيض
  static const Color white = Color(0xFFFFFFFF);
  static const Color offWhite = Color(0xFFF7F5F0);
  static const Color paleGold = Color(0xFFFBF8EF);

  // حالة
  static const Color success = Color(0xFF2E7D32);
  static const Color danger = Color(0xFFC62828);
  static const Color warning = Color(0xFFEF6C00);
  static const Color info = Color(0xFF1565C0);

  // نصوص
  static const Color textPrimaryDark = Color(0xFFF5F5F5);
  static const Color textSecondaryDark = Color(0xFFB8B8B8);
  static const Color textPrimaryLight = Color(0xFF161616);
  static const Color textSecondaryLight = Color(0xFF5C5C5C);

  static const Color divider = Color(0xFF2E2A20);

  static const LinearGradient goldGradient = LinearGradient(
    colors: [goldDark, gold, goldLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient blackGradient = LinearGradient(
    colors: [black, richBlack, charcoal],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}
