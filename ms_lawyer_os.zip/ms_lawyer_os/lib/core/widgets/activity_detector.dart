import 'package:flutter/material.dart';
import '../security/auth_lock_service.dart';

/// يلف شجرة التطبيق بالكامل، ويعيد تشغيل مؤقت الخمول عند أي لمسة
/// أو حركة، وعند انتهاء المهلة يستدعي [onLock] لإعادة توجيه المستخدم
/// إلى شاشة القفل.
class ActivityDetector extends StatefulWidget {
  final Widget child;
  final VoidCallback onLock;

  const ActivityDetector({super.key, required this.child, required this.onLock});

  @override
  State<ActivityDetector> createState() => _ActivityDetectorState();
}

class _ActivityDetectorState extends State<ActivityDetector> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _restartTimer();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AuthLockService.instance.disposeTimer();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      AuthLockService.instance.lockNow();
    } else if (state == AppLifecycleState.resumed) {
      if (AuthLockService.instance.isLocked) {
        widget.onLock();
      } else {
        _restartTimer();
      }
    }
  }

  void _restartTimer() {
    AuthLockService.instance.resetInactivityTimer(widget.onLock);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => _restartTimer(),
      onPointerMove: (_) => _restartTimer(),
      child: widget.child,
    );
  }
}
