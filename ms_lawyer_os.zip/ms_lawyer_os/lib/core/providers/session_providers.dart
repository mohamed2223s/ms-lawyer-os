import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/repositories/client_repository.dart';

/// حالة الجلسة الحالية (المستخدم + المكتب) بعد تسجيل الدخول
final authStateProvider = StreamProvider<User?>((ref) {
  return AuthRepository.instance.authStateChanges;
});

final officeSessionProvider = FutureProvider<OfficeSession?>((ref) async {
  final authState = ref.watch(authStateProvider);
  return authState.when(
    data: (user) async {
      if (user == null) return null;
      return AuthRepository.instance.loadSession(user.uid);
    },
    loading: () async => null,
    error: (_, __) async => null,
  );
});

/// مستودع العملاء - يُعاد إنشاؤه تلقائيًا عند تغيّر جلسة المكتب
final clientRepositoryProvider = Provider<ClientRepository?>((ref) {
  final sessionAsync = ref.watch(officeSessionProvider);
  return sessionAsync.maybeWhen(
    data: (session) => session == null ? null : ClientRepository(officeId: session.officeId),
    orElse: () => null,
  );
});
