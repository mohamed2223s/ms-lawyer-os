import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// خدمة تشفير البيانات المحلية (AES-256) وتوليد/تخزين مفتاح
/// التشفير داخل Secure Storage الخاص بنظام التشغيل (Keystore / Keychain).
class EncryptionService {
  EncryptionService._internal();
  static final EncryptionService instance = EncryptionService._internal();

  static const _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const String _keyStorageKey = 'ms_lawyer_hive_encryption_key';

  enc.Key? _cachedKey;

  /// يُرجع مفتاح تشفير Hive كـ Uint8List (256-bit)
  /// إن لم يوجد مفتاح مخزّن، يتم توليد مفتاح عشوائي آمن وتخزينه مرة واحدة.
  Future<List<int>> getOrCreateHiveKey() async {
    final existing = await _secureStorage.read(key: _keyStorageKey);
    if (existing != null) {
      return base64Url.decode(existing);
    }
    final rand = Random.secure();
    final keyBytes = List<int>.generate(32, (_) => rand.nextInt(256));
    await _secureStorage.write(key: _keyStorageKey, value: base64UrlEncode(keyBytes));
    return keyBytes;
  }

  Future<enc.Key> _getKey() async {
    if (_cachedKey != null) return _cachedKey!;
    final bytes = await getOrCreateHiveKey();
    _cachedKey = enc.Key(Uint8List.fromList(bytes));
    return _cachedKey!;
  }

  /// تشفير نص عام (يُستخدم لبيانات حساسة إضافية خارج Hive، مثل نسخ احتياطية محلية)
  Future<String> encryptText(String plainText) async {
    final key = await _getKey();
    final iv = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    return '${iv.base64}:${encrypted.base64}';
  }

  Future<String> decryptText(String cipherPayload) async {
    final key = await _getKey();
    final parts = cipherPayload.split(':');
    final iv = enc.IV.fromBase64(parts[0]);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    return encrypter.decrypt64(parts[1], iv: iv);
  }
}
