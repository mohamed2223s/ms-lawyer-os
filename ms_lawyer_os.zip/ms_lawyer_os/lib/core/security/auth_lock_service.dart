import 'dart:async';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

/// خدمة الأمان: قفل PIN + بصمة/وجه + قفل تلقائي بعد فترة خمول.
class AuthLockService {
  AuthLockService._internal();
  static final AuthLockService instance = AuthLockService._internal();

  static const _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const String _pinHashKey = 'ms_lawyer_pin_hash';
  static const String _pinSaltKey = 'ms_lawyer_pin_salt';
  static const String _biometricEnabledKey = 'ms_lawyer_biometric_enabled';

  final LocalAuthentication _localAuth = LocalAuthentication();

  /// مدة الخمول قبل القفل التلقائي (بالثواني)
  static const Duration inactivityTimeout = Duration(minutes: 3);

  Timer? _inactivityTimer;
  bool _isLocked = true;

  bool get isLocked => _isLocked;

  Future<bool> hasPinConfigured() async {
    final hash = await _secureStorage.read(key: _pinHashKey);
    return hash != null;
  }

  String _hashPin(String pin, String salt) {
    final bytes = utf8.encode('$salt::$pin::ms_lawyer_os');
    return sha256.convert(bytes).toString();
  }

  Future<void> setPin(String pin) async {
    final salt = DateTime.now().microsecondsSinceEpoch.toString();
    final hash = _hashPin(pin, salt);
    await _secureStorage.write(key: _pinSaltKey, value: salt);
    await _secureStorage.write(key: _pinHashKey, value: hash);
  }

  Future<bool> verifyPin(String pin) async {
    final salt = await _secureStorage.read(key: _pinSaltKey);
    final storedHash = await _secureStorage.read(key: _pinHashKey);
    if (salt == null || storedHash == null) return false;
    final computed = _hashPin(pin, salt);
    final matches = computed == storedHash;
    if (matches) _isLocked = false;
    return matches;
  }

  Future<bool> isBiometricAvailable() async {
    try {
      final supported = await _localAuth.isDeviceSupported();
      final canCheck = await _localAuth.canCheckBiometrics;
      return supported && canCheck;
    } catch (_) {
      return false;
    }
  }

  Future<void> setBiometricEnabled(bool enabled) async {
    await _secureStorage.write(key: _biometricEnabledKey, value: enabled.toString());
  }

  Future<bool> isBiometricEnabled() async {
    final value = await _secureStorage.read(key: _biometricEnabledKey);
    return value == 'true';
  }

  Future<bool> authenticateWithBiometrics() async {
    try {
      final result = await _localAuth.authenticate(
        localizedReason: 'يرجى التحقق من هويتك لفتح التطبيق',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
      if (result) _isLocked = false;
      return result;
    } catch (_) {
      return false;
    }
  }

  void lockNow() {
    _isLocked = true;
  }

  /// إعادة تشغيل مؤقت الخمول - يُستدعى عند أي تفاعل مستخدم
  void resetInactivityTimer(void Function() onTimeout) {
    _inactivityTimer?.cancel();
    _inactivityTimer = Timer(inactivityTimeout, () {
      lockNow();
      onTimeout();
    });
  }

  void disposeTimer() {
    _inactivityTimer?.cancel();
  }

  Future<void> clearAllSecurityData() async {
    await _secureStorage.delete(key: _pinHashKey);
    await _secureStorage.delete(key: _pinSaltKey);
    await _secureStorage.delete(key: _biometricEnabledKey);
  }
}
