import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// يعرض شريط أخضر بعلامة صح أسفل الشاشة لتأكيد نجاح عملية حفظ.
void showSuccessSnackBar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(children: [
        const Icon(Icons.check_circle, color: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Text(message)),
      ]),
      backgroundColor: AppColors.success,
    ),
  );
}
