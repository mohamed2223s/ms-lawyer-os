import 'dart:convert';
import 'dart:io';

import 'package:archive/archive_io.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// يشيل الرقم المميز اللي بيتحط قبل اسم الملف وقت الرفع (لمنع تكرار الأسماء)
/// عشان اسم الملف يبان نضيف زي ما المستخدم رفعه بالظبط.
String displayFileName(String path) {
  final name = p.basename(path);
  return name.replaceFirst(RegExp(r'^\d+_'), '');
}

/// يعرض للمستخدم اختيار طريقة المشاركة:
/// - النص بس
/// - اختيار مرفقات معينة يشاركها كل واحد لوحده
/// - ضغط كل حاجة (النص + كل المرفقات) في ملف واحد مضغوط ومشاركته كملف واحد
Future<void> shareTextWithAttachments(
  BuildContext context, {
  required String text,
  required List<String> attachmentPaths,
  String zipBaseName = 'ملف',
}) async {
  if (attachmentPaths.isEmpty) {
    await Share.share(text);
    return;
  }

  final mode = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('طريقة المشاركة'),
      content: const Text('عايز تشارك المستندات إزاي؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, 'text'), child: const Text('النص بس')),
        TextButton(onPressed: () => Navigator.pop(ctx, 'pick'), child: const Text('اختار مرفقات')),
        ElevatedButton(onPressed: () => Navigator.pop(ctx, 'zip'), child: const Text('ملف واحد مضغوط')),
      ],
    ),
  );
  if (mode == null) return;

  if (mode == 'text') {
    await Share.share(text);
    return;
  }

  if (mode == 'pick') {
    final selected = <String>{};
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('اختر المرفقات اللي عايز تشاركها'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView(
              shrinkWrap: true,
              children: attachmentPaths
                  .map((path) => CheckboxListTile(
                        value: selected.contains(path),
                        title: Text(displayFileName(path), overflow: TextOverflow.ellipsis),
                        onChanged: (v) => setDialogState(() {
                          if (v == true) {
                            selected.add(path);
                          } else {
                            selected.remove(path);
                          }
                        }),
                      ))
                  .toList(),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('مشاركة')),
          ],
        ),
      ),
    );
    if (confirm != true) return;
    if (selected.isEmpty) {
      await Share.share(text);
    } else {
      final files = selected.where((path) => File(path).existsSync()).map((path) => XFile(path)).toList();
      await Share.shareXFiles(files, text: text);
    }
    return;
  }

  if (mode == 'zip') {
    final tempDir = await getTemporaryDirectory();
    final zipPath = p.join(tempDir.path, '${zipBaseName}_${DateTime.now().millisecondsSinceEpoch}.zip');
    final summaryFile = File(p.join(tempDir.path, 'بيانات_${DateTime.now().millisecondsSinceEpoch}.txt'));
    await summaryFile.writeAsString(text, encoding: utf8);

    final encoder = ZipFileEncoder();
    encoder.create(zipPath);
    encoder.addFile(summaryFile, 'بيانات.txt');
    for (final path in attachmentPaths) {
      final f = File(path);
      if (f.existsSync()) {
        encoder.addFile(f, displayFileName(path));
      }
    }
    encoder.close();
    await summaryFile.delete();

    await Share.shareXFiles([XFile(zipPath)]);
  }
}
