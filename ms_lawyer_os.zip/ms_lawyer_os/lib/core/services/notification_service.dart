import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz_data;

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // معالجة الإشعارات الواردة والتطبيق في الخلفية أو مغلق
}

/// خدمة الإشعارات: تهيئة Firebase Cloud Messaging والإشعارات المحلية،
/// وطلب الأذونات، وعرض الإشعارات الواردة أثناء فتح التطبيق.
class NotificationService {
  NotificationService._internal();
  static final NotificationService instance = NotificationService._internal();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz_data.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Africa/Cairo'));
    } catch (_) {
      // fallback: يبقى بالتوقيت المحلي الافتراضي (UTC) لو الموقع غير متاح
    }

    await _messaging.requestPermission(alert: true, badge: true, sound: true);

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _localNotifications.initialize(initSettings);

    const channel = AndroidNotificationChannel(
      'ms_lawyer_high_importance',
      'إشعارات مكتب المحاماة',
      description: 'إشعارات الجلسات والمهام والتنبيهات الهامة',
      importance: Importance.high,
    );
    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    FirebaseMessaging.onMessage.listen((message) {
      final notification = message.notification;
      if (notification != null) {
        _localNotifications.show(
          notification.hashCode,
          notification.title,
          notification.body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'ms_lawyer_high_importance',
              'إشعارات مكتب المحاماة',
              importance: Importance.high,
              priority: Priority.high,
            ),
          ),
        );
      }
    });
  }

  Future<String?> getDeviceToken() => _messaging.getToken();

  Future<void> subscribeToOfficeTopic(String officeId) {
    return _messaging.subscribeToTopic('office_$officeId');
  }

  /// جدولة إشعار محلي فوري (تُستخدم لاحقًا في موديول الجلسات والمهام
  /// لإرسال تذكيرات بموعد الجلسة القادمة)
  Future<void> showLocalNotification({required int id, required String title, required String body}) {
    return _localNotifications.show(
      id,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails('ms_lawyer_high_importance', 'إشعارات مكتب المحاماة', importance: Importance.high),
      ),
    );
  }

  int _dayBeforeNotifId(String hearingId) => hearingId.hashCode & 0x7fffffff;
  int _twoHoursBeforeNotifId(String hearingId) => (hearingId.hashCode ^ 0x5a5a5a5a) & 0x7fffffff;

  Future<void> _scheduleAt({required int id, required DateTime when, required String title, required String body}) async {
    await _localNotifications.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(when, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'ms_lawyer_high_importance',
          'إشعارات مكتب المحاماة',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UiLocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// يجدول تذكيرين لجلسة: قبلها بيوم كامل، وقبلها بساعتين.
  /// يلغي أي تذكيرات قديمة لنفس الجلسة أولاً (مفيد عند التأجيل أو التعديل).
  Future<void> scheduleHearingReminders({
    required String hearingId,
    required DateTime hearingDate,
    required String title,
    required String body,
  }) async {
    await cancelHearingReminders(hearingId);
    final now = DateTime.now();
    final dayBefore = hearingDate.subtract(const Duration(days: 1));
    final twoHoursBefore = hearingDate.subtract(const Duration(hours: 2));
    if (dayBefore.isAfter(now)) {
      await _scheduleAt(id: _dayBeforeNotifId(hearingId), when: dayBefore, title: title, body: body);
    }
    if (twoHoursBefore.isAfter(now)) {
      await _scheduleAt(id: _twoHoursBeforeNotifId(hearingId), when: twoHoursBefore, title: title, body: body);
    }
  }

  Future<void> cancelHearingReminders(String hearingId) async {
    await _localNotifications.cancel(_dayBeforeNotifId(hearingId));
    await _localNotifications.cancel(_twoHoursBeforeNotifId(hearingId));
  }
}
