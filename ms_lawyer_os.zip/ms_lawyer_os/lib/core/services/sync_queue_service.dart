import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../../data/local/hive_setup.dart';
import 'connectivity_service.dart';

enum SyncOperation { create, update, delete }

/// عنصر واحد في طابور المزامنة - يمثل عملية معلّقة يجب تنفيذها على
/// Firestore بمجرد توفر اتصال بالإنترنت.
/// يحوّل القيم اللي مش قادر Hive يخزنها (زي Timestamp بتاع Firestore)
/// لصيغة نصية آمنة، والعكس وقت إرسالها فعليًا لـ Firestore.
dynamic _encodeForHive(dynamic value) {
  if (value is Timestamp) {
    return {'__ts__': value.toDate().toIso8601String()};
  } else if (value is Map) {
    return value.map((k, v) => MapEntry(k, _encodeForHive(v)));
  } else if (value is List) {
    return value.map(_encodeForHive).toList();
  }
  return value;
}

dynamic _decodeForFirestore(dynamic value) {
  if (value is Map) {
    final map = Map<String, dynamic>.from(value);
    if (map.length == 1 && map.containsKey('__ts__')) {
      return Timestamp.fromDate(DateTime.parse(map['__ts__'] as String));
    }
    return map.map((k, v) => MapEntry(k, _decodeForFirestore(v)));
  } else if (value is List) {
    return value.map(_decodeForFirestore).toList();
  }
  return value;
}

class SyncQueueItem {
  final String queueId;
  final String collectionPath; // e.g. offices/{id}/clients
  final String docId;
  final SyncOperation operation;
  final Map<String, dynamic> payload;
  final DateTime queuedAt;

  SyncQueueItem({
    required this.queueId,
    required this.collectionPath,
    required this.docId,
    required this.operation,
    required this.payload,
    required this.queuedAt,
  });

  Map<String, dynamic> toMap() => {
        'queueId': queueId,
        'collectionPath': collectionPath,
        'docId': docId,
        'operation': operation.name,
        'payload': _encodeForHive(payload),
        'queuedAt': queuedAt.toIso8601String(),
      };

  factory SyncQueueItem.fromMap(Map map) => SyncQueueItem(
        queueId: map['queueId'] as String,
        collectionPath: map['collectionPath'] as String,
        docId: map['docId'] as String,
        operation: SyncOperation.values.firstWhere((e) => e.name == map['operation']),
        payload: Map<String, dynamic>.from(_decodeForFirestore(map['payload'] ?? {}) as Map),
        queuedAt: DateTime.parse(map['queuedAt'] as String),
      );
}

/// خدمة طابور المزامنة: تُخزّن كل عملية كتابة محليًا فورًا، ثم تحاول
/// دفعها إلى Firestore عند توفر الإنترنت. تدعم المزامنة التلقائية
/// التي تعمل في الخلفية عند استعادة الاتصال.
class SyncQueueService {
  SyncQueueService._internal();
  static final SyncQueueService instance = SyncQueueService._internal();

  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;
  bool _isProcessing = false;

  Box get _queueBox => Hive.box(HiveBoxes.syncQueue);

  Future<void> enqueue({
    required String collectionPath,
    required String docId,
    required SyncOperation operation,
    required Map<String, dynamic> payload,
  }) async {
    final item = SyncQueueItem(
      queueId: _uuid.v4(),
      collectionPath: collectionPath,
      docId: docId,
      operation: operation,
      payload: payload,
      queuedAt: DateTime.now(),
    );
    await _queueBox.put(item.queueId, item.toMap());
    // محاولة مزامنة فورية إن كان هناك اتصال
    unawaited(processQueue());
  }

  Future<void> processQueue() async {
    if (_isProcessing) return;
    final online = await ConnectivityService.instance.isOnline();
    if (!online) return;

    _isProcessing = true;
    try {
      final keys = _queueBox.keys.toList();
      for (final key in keys) {
        final raw = _queueBox.get(key);
        if (raw == null) continue;
        final item = SyncQueueItem.fromMap(Map<String, dynamic>.from(raw as Map));
        try {
          final docRef = _firestore.doc('${item.collectionPath}/${item.docId}');
          switch (item.operation) {
            case SyncOperation.create:
            case SyncOperation.update:
              await docRef.set(item.payload, SetOptions(merge: true));
              break;
            case SyncOperation.delete:
              await docRef.set({'isDeleted': true, ...item.payload}, SetOptions(merge: true));
              break;
          }
          await _queueBox.delete(key);
        } catch (_) {
          // فشل هذا العنصر - سيُعاد المحاولة في الدورة القادمة
          continue;
        }
      }
    } finally {
      _isProcessing = false;
    }
  }

  int get pendingCount => _queueBox.length;

  void startAutoSync() {
    ConnectivityService.instance.onStatusChange.listen((online) {
      if (online) processQueue();
    });
  }
}

void unawaited(Future<void> future) {}
