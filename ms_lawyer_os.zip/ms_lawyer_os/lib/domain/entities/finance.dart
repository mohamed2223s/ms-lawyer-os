import 'package:equatable/equatable.dart';

/// طريقة الدفع
enum PaymentMethod { cash, bankTransfer, check }

extension PaymentMethodLabel on PaymentMethod {
  String get labelAr {
    switch (this) {
      case PaymentMethod.cash:
        return 'نقدًا';
      case PaymentMethod.bankTransfer:
        return 'تحويل بنكي';
      case PaymentMethod.check:
        return 'شيك';
    }
  }
}

/// دفعة من العميل (ضمن حساب الأتعاب الخاص به - لا تخص قضية بعينها بالضرورة)
class FinancePayment extends Equatable {
  final String id;
  final String officeId;
  final String clientId;
  final double amount;
  final DateTime date;
  final PaymentMethod method;
  final String note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const FinancePayment({
    required this.id,
    required this.officeId,
    required this.clientId,
    required this.amount,
    required this.date,
    required this.method,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  FinancePayment copyWith({
    double? amount,
    DateTime? date,
    PaymentMethod? method,
    String? note,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return FinancePayment(
      id: id,
      officeId: officeId,
      clientId: clientId,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      method: method ?? this.method,
      note: note ?? this.note,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props =>
      [id, officeId, clientId, amount, date, method, note, createdAt, updatedAt, isSynced, isDeleted];
}

/// مصروف على قضية بعينها (منفصل تمامًا عن حساب أتعاب العميل)
class CaseExpense extends Equatable {
  final String id;
  final String officeId;
  final String caseId;
  final double amount;
  final DateTime date;
  final String expenseType; // مثال: رسوم محكمة، خبير، انتقالات
  final String note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const CaseExpense({
    required this.id,
    required this.officeId,
    required this.caseId,
    required this.amount,
    required this.date,
    required this.expenseType,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  CaseExpense copyWith({
    double? amount,
    DateTime? date,
    String? expenseType,
    String? note,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return CaseExpense(
      id: id,
      officeId: officeId,
      caseId: caseId,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      expenseType: expenseType ?? this.expenseType,
      note: note ?? this.note,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props =>
      [id, officeId, caseId, amount, date, expenseType, note, createdAt, updatedAt, isSynced, isDeleted];
}
