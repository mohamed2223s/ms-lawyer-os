import 'package:equatable/equatable.dart';

/// كيان الخصم - يمثل الطرف الآخر في قضية، مع بيانات محاميه
class Opponent extends Equatable {
  final String id;
  final String officeId;
  final String name;
  final String address;
  final String nationalId;
  final String lawyerName;
  final String lawyerPhone;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const Opponent({
    required this.id,
    required this.officeId,
    required this.name,
    this.address = '',
    this.nationalId = '',
    this.lawyerName = '',
    this.lawyerPhone = '',
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  Opponent copyWith({
    String? name,
    String? address,
    String? nationalId,
    String? lawyerName,
    String? lawyerPhone,
    String? notes,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return Opponent(
      id: id,
      officeId: officeId,
      name: name ?? this.name,
      address: address ?? this.address,
      nationalId: nationalId ?? this.nationalId,
      lawyerName: lawyerName ?? this.lawyerName,
      lawyerPhone: lawyerPhone ?? this.lawyerPhone,
      notes: notes ?? this.notes,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props =>
      [id, officeId, name, address, nationalId, lawyerName, lawyerPhone, notes, createdAt, updatedAt, isSynced, isDeleted];
}

/// نوع مستند مكتبة المكتب العامة
enum LibraryDocCategory { cassationRulings, claimTemplates, appeals, pleadings }

extension LibraryDocCategoryLabel on LibraryDocCategory {
  String get labelAr {
    switch (this) {
      case LibraryDocCategory.cassationRulings:
        return 'أحكام نقض';
      case LibraryDocCategory.claimTemplates:
        return 'صيغ دعاوى وعقود';
      case LibraryDocCategory.appeals:
        return 'طعون';
      case LibraryDocCategory.pleadings:
        return 'مذكرات مرافعات';
    }
  }
}

/// التخصص القانوني لمستند المكتبة
enum PracticeArea { criminal, family, civil, administrative, procedures }

extension PracticeAreaLabel on PracticeArea {
  String get labelAr {
    switch (this) {
      case PracticeArea.criminal:
        return 'جنائي';
      case PracticeArea.family:
        return 'أسرة';
      case PracticeArea.civil:
        return 'مدني';
      case PracticeArea.administrative:
        return 'إداري';
      case PracticeArea.procedures:
        return 'إجراءات ومرافعات';
    }
  }
}

/// كيان مستند في مكتبة المكتب العامة (منفصل عن مرفقات القضايا)
class LibraryDocument extends Equatable {
  final String id;
  final String officeId;
  final String title;
  final LibraryDocCategory category;
  final PracticeArea practiceArea;
  final String filePath;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const LibraryDocument({
    required this.id,
    required this.officeId,
    required this.title,
    required this.category,
    required this.practiceArea,
    required this.filePath,
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  LibraryDocument copyWith({
    String? title,
    LibraryDocCategory? category,
    PracticeArea? practiceArea,
    String? filePath,
    String? notes,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return LibraryDocument(
      id: id,
      officeId: officeId,
      title: title ?? this.title,
      category: category ?? this.category,
      practiceArea: practiceArea ?? this.practiceArea,
      filePath: filePath ?? this.filePath,
      notes: notes ?? this.notes,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props =>
      [id, officeId, title, category, practiceArea, filePath, notes, createdAt, updatedAt, isSynced, isDeleted];
}

/// كيان عنصر في سجل الأمانات (الأوراق الأصلية المستلمة من العملاء)
class VaultItem extends Equatable {
  final String id;
  final String officeId;
  final String clientName;
  final String description; // نوع الورقة الأصلية (عقد، إيصال أمانة...)
  final DateTime receivedDate;
  final String physicalLocation; // دولاب أ - الرف 3 - حافظة 15
  final DateTime? returnedDate;
  final String returnNote;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const VaultItem({
    required this.id,
    required this.officeId,
    required this.clientName,
    required this.description,
    required this.receivedDate,
    this.physicalLocation = '',
    this.returnedDate,
    this.returnNote = '',
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  bool get isReturned => returnedDate != null;

  VaultItem copyWith({
    String? clientName,
    String? description,
    DateTime? receivedDate,
    String? physicalLocation,
    DateTime? returnedDate,
    bool clearReturnedDate = false,
    String? returnNote,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return VaultItem(
      id: id,
      officeId: officeId,
      clientName: clientName ?? this.clientName,
      description: description ?? this.description,
      receivedDate: receivedDate ?? this.receivedDate,
      physicalLocation: physicalLocation ?? this.physicalLocation,
      returnedDate: clearReturnedDate ? null : (returnedDate ?? this.returnedDate),
      returnNote: returnNote ?? this.returnNote,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [
        id,
        officeId,
        clientName,
        description,
        receivedDate,
        physicalLocation,
        returnedDate,
        returnNote,
        createdAt,
        updatedAt,
        isSynced,
        isDeleted,
      ];
}
