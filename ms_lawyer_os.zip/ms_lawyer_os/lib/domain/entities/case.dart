import 'package:equatable/equatable.dart';

enum CaseStatus { active, adjourned, closed, appeal }

extension CaseStatusLabel on CaseStatus {
  String get labelAr {
    switch (this) {
      case CaseStatus.active:
        return 'منظورة';
      case CaseStatus.adjourned:
        return 'مؤجلة';
      case CaseStatus.closed:
        return 'مغلقة';
      case CaseStatus.appeal:
        return 'استئناف';
    }
  }
}

enum CaseDegree { partial, first, appeal, cassation }

extension CaseDegreeLabel on CaseDegree {
  String get labelAr {
    switch (this) {
      case CaseDegree.partial:
        return 'جزئي';
      case CaseDegree.first:
        return 'ابتدائي';
      case CaseDegree.appeal:
        return 'استئناف';
      case CaseDegree.cassation:
        return 'نقض';
    }
  }
}

class CaseNote extends Equatable {
  final String id;
  final String text;
  final DateTime createdAt;

  const CaseNote({required this.id, required this.text, required this.createdAt});

  Map<String, dynamic> toMap() => {'id': id, 'text': text, 'createdAt': createdAt.toIso8601String()};

  factory CaseNote.fromMap(Map map) => CaseNote(
        id: map['id'] as String,
        text: map['text'] as String,
        createdAt: DateTime.parse(map['createdAt'] as String),
      );

  @override
  List<Object?> get props => [id, text, createdAt];
}

class CaseTimelineEntry extends Equatable {
  final String id;
  final String title;
  final String description;
  final DateTime date;

  const CaseTimelineEntry({required this.id, required this.title, required this.description, required this.date});

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'date': date.toIso8601String(),
      };

  factory CaseTimelineEntry.fromMap(Map map) => CaseTimelineEntry(
        id: map['id'] as String,
        title: map['title'] as String,
        description: map['description'] as String? ?? '',
        date: DateTime.parse(map['date'] as String),
      );

  @override
  List<Object?> get props => [id, title, description, date];
}

/// كيان القضية - يمثل قضية مرتبطة بعميل
class LawCase extends Equatable {
  final String id;
  final String officeId;
  final String clientId;
  final String clientName;
  final String court;
  final String circuit;
  final String caseNumber;
  final String year;
  final String caseType;
  final CaseDegree degree;
  final String opponentName;
  final String opponentLawyer;
  final CaseStatus status;
  final DateTime? nextHearingDate;
  final List<CaseNote> notes;
  final List<CaseTimelineEntry> timeline;
  final List<String> attachmentPaths;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const LawCase({
    required this.id,
    required this.officeId,
    required this.clientId,
    required this.clientName,
    required this.court,
    required this.circuit,
    required this.caseNumber,
    required this.year,
    required this.caseType,
    required this.degree,
    required this.opponentName,
    required this.opponentLawyer,
    required this.status,
    this.nextHearingDate,
    this.notes = const [],
    this.timeline = const [],
    this.attachmentPaths = const [],
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  String get title => '$caseType رقم $caseNumber لسنة $year';

  LawCase copyWith({
    String? clientId,
    String? clientName,
    String? court,
    String? circuit,
    String? caseNumber,
    String? year,
    String? caseType,
    CaseDegree? degree,
    String? opponentName,
    String? opponentLawyer,
    CaseStatus? status,
    DateTime? nextHearingDate,
    bool clearNextHearing = false,
    List<CaseNote>? notes,
    List<CaseTimelineEntry>? timeline,
    List<String>? attachmentPaths,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return LawCase(
      id: id,
      officeId: officeId,
      clientId: clientId ?? this.clientId,
      clientName: clientName ?? this.clientName,
      court: court ?? this.court,
      circuit: circuit ?? this.circuit,
      caseNumber: caseNumber ?? this.caseNumber,
      year: year ?? this.year,
      caseType: caseType ?? this.caseType,
      degree: degree ?? this.degree,
      opponentName: opponentName ?? this.opponentName,
      opponentLawyer: opponentLawyer ?? this.opponentLawyer,
      status: status ?? this.status,
      nextHearingDate: clearNextHearing ? null : (nextHearingDate ?? this.nextHearingDate),
      notes: notes ?? this.notes,
      timeline: timeline ?? this.timeline,
      attachmentPaths: attachmentPaths ?? this.attachmentPaths,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [
        id,
        officeId,
        clientId,
        clientName,
        court,
        circuit,
        caseNumber,
        year,
        caseType,
        degree,
        opponentName,
        opponentLawyer,
        status,
        nextHearingDate,
        notes,
        timeline,
        attachmentPaths,
        createdAt,
        updatedAt,
        isSynced,
        isDeleted,
      ];
}
