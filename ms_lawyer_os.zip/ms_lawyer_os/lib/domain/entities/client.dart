import 'package:equatable/equatable.dart';

/// نوع التوكيل
enum PoaType { general, special }

extension PoaTypeLabel on PoaType {
  String get labelAr {
    switch (this) {
      case PoaType.general:
        return 'عام';
      case PoaType.special:
        return 'خاص';
    }
  }
}

/// نوع توثيق التوكيل
enum NotarizationType { notarized, customary }

extension NotarizationTypeLabel on NotarizationType {
  String get labelAr {
    switch (this) {
      case NotarizationType.notarized:
        return 'موثّق';
      case NotarizationType.customary:
        return 'عرفي';
    }
  }
}

/// كيان العميل - يمثل موكل مكتب المحاماة
class Client extends Equatable {
  final String id;
  final String officeId;
  final String fullName;
  final String nationalId;
  final String phone;
  final String whatsapp;
  final String address;
  final String notes;
  final List<String> attachmentPaths; // مسارات محلية أو روابط سحابية للمرفقات
  final double totalFees; // الأتعاب المتفق عليها مع العميل
  final String poaNumber; // رقم التوكيل
  final DateTime? poaDate; // تاريخ التوكيل
  final PoaType poaType; // عام / خاص
  final NotarizationType notarization; // موثّق / عرفي
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const Client({
    required this.id,
    required this.officeId,
    required this.fullName,
    required this.nationalId,
    required this.phone,
    required this.whatsapp,
    required this.address,
    required this.notes,
    required this.attachmentPaths,
    this.totalFees = 0,
    this.poaNumber = '',
    this.poaDate,
    this.poaType = PoaType.general,
    this.notarization = NotarizationType.customary,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  Client copyWith({
    String? fullName,
    String? nationalId,
    String? phone,
    String? whatsapp,
    String? address,
    String? notes,
    List<String>? attachmentPaths,
    double? totalFees,
    String? poaNumber,
    DateTime? poaDate,
    bool clearPoaDate = false,
    PoaType? poaType,
    NotarizationType? notarization,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return Client(
      id: id,
      officeId: officeId,
      fullName: fullName ?? this.fullName,
      nationalId: nationalId ?? this.nationalId,
      phone: phone ?? this.phone,
      whatsapp: whatsapp ?? this.whatsapp,
      address: address ?? this.address,
      notes: notes ?? this.notes,
      attachmentPaths: attachmentPaths ?? this.attachmentPaths,
      totalFees: totalFees ?? this.totalFees,
      poaNumber: poaNumber ?? this.poaNumber,
      poaDate: clearPoaDate ? null : (poaDate ?? this.poaDate),
      poaType: poaType ?? this.poaType,
      notarization: notarization ?? this.notarization,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [
        id,
        officeId,
        fullName,
        nationalId,
        phone,
        whatsapp,
        address,
        notes,
        attachmentPaths,
        totalFees,
        poaNumber,
        poaDate,
        poaType,
        notarization,
        createdAt,
        updatedAt,
        isSynced,
        isDeleted,
      ];
}
