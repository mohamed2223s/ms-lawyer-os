import 'package:equatable/equatable.dart';

/// كيان العميل - يمثل موكل مكتب المحاماة
class Client extends Equatable {
  final String id;
  final String officeId;
  final String fullName;
  final String nationalId;
  final String phone;
  final String whatsapp;
  final String address;
  final String notes;
  final List<String> attachmentPaths; // مسارات محلية أو روابط سحابية للمرفقات
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const Client({
    required this.id,
    required this.officeId,
    required this.fullName,
    required this.nationalId,
    required this.phone,
    required this.whatsapp,
    required this.address,
    required this.notes,
    required this.attachmentPaths,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  Client copyWith({
    String? fullName,
    String? nationalId,
    String? phone,
    String? whatsapp,
    String? address,
    String? notes,
    List<String>? attachmentPaths,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return Client(
      id: id,
      officeId: officeId,
      fullName: fullName ?? this.fullName,
      nationalId: nationalId ?? this.nationalId,
      phone: phone ?? this.phone,
      whatsapp: whatsapp ?? this.whatsapp,
      address: address ?? this.address,
      notes: notes ?? this.notes,
      attachmentPaths: attachmentPaths ?? this.attachmentPaths,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [
        id,
        officeId,
        fullName,
        nationalId,
        phone,
        whatsapp,
        address,
        notes,
        attachmentPaths,
        createdAt,
        updatedAt,
        isSynced,
        isDeleted,
      ];
}
