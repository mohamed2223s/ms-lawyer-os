import 'package:equatable/equatable.dart';

/// سجل تأجيل واحد - يحفظ التاريخ القديم قبل التأجيل وسبب التأجيل
class PostponementRecord extends Equatable {
  final String id;
  final DateTime previousDate;
  final String reason;
  final DateTime recordedAt;

  const PostponementRecord({
    required this.id,
    required this.previousDate,
    required this.reason,
    required this.recordedAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'previousDate': previousDate.toIso8601String(),
        'reason': reason,
        'recordedAt': recordedAt.toIso8601String(),
      };

  factory PostponementRecord.fromMap(Map map) => PostponementRecord(
        id: map['id'] as String,
        previousDate: DateTime.parse(map['previousDate'] as String),
        reason: map['reason'] as String? ?? '',
        recordedAt: DateTime.parse(map['recordedAt'] as String),
      );

  @override
  List<Object?> get props => [id, previousDate, reason, recordedAt];
}

/// كيان الجلسة - يمثل جلسة محكمة مرتبطة (اختياريًا) بقضية
class Hearing extends Equatable {
  final String id;
  final String officeId;
  final String? caseId;
  final String caseTitle;
  final String clientName;
  final String court;
  final String location;
  final DateTime date;
  final String notes;
  final String result;
  final String requiredActions;
  final List<PostponementRecord> postponementHistory;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const Hearing({
    required this.id,
    required this.officeId,
    this.caseId,
    required this.caseTitle,
    required this.clientName,
    required this.court,
    required this.location,
    required this.date,
    this.notes = '',
    this.result = '',
    this.requiredActions = '',
    this.postponementHistory = const [],
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  Hearing copyWith({
    String? caseId,
    String? caseTitle,
    String? clientName,
    String? court,
    String? location,
    DateTime? date,
    String? notes,
    String? result,
    String? requiredActions,
    List<PostponementRecord>? postponementHistory,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return Hearing(
      id: id,
      officeId: officeId,
      caseId: caseId ?? this.caseId,
      caseTitle: caseTitle ?? this.caseTitle,
      clientName: clientName ?? this.clientName,
      court: court ?? this.court,
      location: location ?? this.location,
      date: date ?? this.date,
      notes: notes ?? this.notes,
      result: result ?? this.result,
      requiredActions: requiredActions ?? this.requiredActions,
      postponementHistory: postponementHistory ?? this.postponementHistory,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [
        id,
        officeId,
        caseId,
        caseTitle,
        clientName,
        court,
        location,
        date,
        notes,
        result,
        requiredActions,
        postponementHistory,
        createdAt,
        updatedAt,
        isSynced,
        isDeleted,
      ];
}
