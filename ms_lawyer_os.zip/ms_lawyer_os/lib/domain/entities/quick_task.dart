import 'package:equatable/equatable.dart';

/// بند في المفكرة/قائمة المهام السريعة - نص بسيط تقدر تعلّم عليه لما يخلص
class QuickTask extends Equatable {
  final String id;
  final String officeId;
  final String title;
  final bool isDone;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSynced;
  final bool isDeleted;

  const QuickTask({
    required this.id,
    required this.officeId,
    required this.title,
    this.isDone = false,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
    this.isDeleted = false,
  });

  QuickTask copyWith({
    String? title,
    bool? isDone,
    DateTime? updatedAt,
    bool? isSynced,
    bool? isDeleted,
  }) {
    return QuickTask(
      id: id,
      officeId: officeId,
      title: title ?? this.title,
      isDone: isDone ?? this.isDone,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isSynced: isSynced ?? this.isSynced,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }

  @override
  List<Object?> get props => [id, officeId, title, isDone, createdAt, updatedAt, isSynced, isDeleted];
}
