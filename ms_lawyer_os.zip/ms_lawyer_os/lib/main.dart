import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app.dart';
import 'core/services/notification_service.dart';
import 'core/services/sync_queue_service.dart';
import 'data/local/hive_setup.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await HiveSetup.init();
  await NotificationService.instance.init();

  SyncQueueService.instance.startAutoSync();

  runApp(const ProviderScope(child: MsLawyerApp()));
}
